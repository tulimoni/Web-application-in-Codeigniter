<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Non_Bank_Finance_Super_Admin_Model extends CI_Model {
    
    /*
        * ------- Save Non Bank Finance Category All Database Information Start form Line 9 to 62--------- *
    */

    public function save_non_bank_finance_category_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_category',$data);
    }

    public function select_all_non_bank_finance_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_category');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_id($non_bank_finance_category_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_category_id',$non_bank_finance_category_id);
        $this->db->update('tbl_non_bank_finance_category');
          
    }
    public function update_unpublication_status_by_id($non_bank_finance_category_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_category_id',$non_bank_finance_category_id);
        $this->db->update('tbl_non_bank_finance_category');
           
    }

    public function select_non_bank_finance_category_info_by_id($non_bank_finance_category_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_category');
        $this->db->where('non_bank_finance_category_id', $non_bank_finance_category_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_category_info($data, $non_bank_finance_category_id) 
    {
        $this->db->where('non_bank_finance_category_id', $non_bank_finance_category_id);
        $this->db->update('tbl_non_bank_finance_category', $data);
    }

    public function delete_category_by_id($non_bank_finance_category_id)
    {
        $this->db->where('non_bank_finance_category_id',$non_bank_finance_category_id);
        $this->db->delete('tbl_non_bank_finance_category');
    }

    /*
        * ------- Save Non Bank Finance Category All Database Information End--------- *
    */

    /*
        * ------- Save Non Bank Finance Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_non_bank_finance_name_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_name',$data);
    }

    public function select_all_non_bank_finance_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_name');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_non_bank_finance_id($non_bank_finance_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_id',$non_bank_finance_id);
        $this->db->update('tbl_non_bank_finance_name');
          
    }
    public function update_unpublication_status_by_non_bank_finance_id($non_bank_finance_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_id',$non_bank_finance_id);
        $this->db->update('tbl_non_bank_finance_name');
           
    }

    public function select_non_bank_finance_name_info_by_id($non_bank_finance_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_name');
        $this->db->where('non_bank_finance_id', $non_bank_finance_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_name_info($data, $non_bank_finance_id) 
    {
        $this->db->where('non_bank_finance_id', $non_bank_finance_id);
        $this->db->update('tbl_non_bank_finance_name', $data);
    }

    public function delete_non_bank_finance_logo_by_id($non_bank_finance_id)
    {
        $sql="SELECT * FROM tbl_non_bank_finance_name WHERE non_bank_finance_id='$non_bank_finance_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->non_bank_finance_logo");
        
        $this->db->set('non_bank_finance_logo', '');
        $this->db->where('non_bank_finance_id', $non_bank_finance_id);
        $this->db->update('tbl_non_bank_finance_name');
        
        return $result;
    }

    public function delete_category_by_non_bank_finance_id($non_bank_finance_id)
    {
        $this->db->where('non_bank_finance_id',$non_bank_finance_id);
        $this->db->delete('tbl_non_bank_finance_name');
    }

    /*
        * ------- Save Non Bank Finance Name All Database Information End--------- *
    */

    /*
        * ---- Save Non Bank Finance Deposit Information All Database Information Start form Line 150 to 203 ------ *
    */

    public function save_non_bank_finance_deposit_information_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_diposit',$data);
    }

    public function select_all_non_bank_finance_deposit_information()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_diposit');
        $this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_diposit_id',$non_bank_finance_diposit_id);
        $this->db->update('tbl_non_bank_finance_diposit');
          
    }
    public function update_unpublication_status_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_diposit_id',$non_bank_finance_diposit_id);
        $this->db->update('tbl_non_bank_finance_diposit');
           
    }

    public function select_non_bank_finance_deposit_information_info_by_id($non_bank_finance_diposit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_diposit');
        $this->db->where('non_bank_finance_diposit_id', $non_bank_finance_diposit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_deposit_information_info($data, $non_bank_finance_diposit_id) 
    {
        $this->db->where('non_bank_finance_diposit_id', $non_bank_finance_diposit_id);
        $this->db->update('tbl_non_bank_finance_diposit', $data);
    }

    public function delete_category_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        $this->db->where('non_bank_finance_diposit_id',$non_bank_finance_diposit_id);
        $this->db->delete('tbl_non_bank_finance_diposit');
    }

    /*
        * ------- Save Non Bank Finance Deposit Information All Database Information End --------- *
    */

    /*
        * ---- Save Non Bank Finance Loan Categogy All Database Information Start From 213 to 266 ----- *
    */

    public function save_non_bank_finance_loan_category_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_loan_category',$data);
    }

    public function select_all_non_bank_finance_loan_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_loan_category');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_loan_status_by_id($non_bank_finance_loan_category_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_loan_category_id',$non_bank_finance_loan_category_id);
        $this->db->update('tbl_non_bank_finance_loan_category');
          
    }
    public function update_unpublication_loan_status_by_id($non_bank_finance_loan_category_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_loan_category_id',$non_bank_finance_loan_category_id);
        $this->db->update('tbl_non_bank_finance_loan_category');
           
    }

    public function select_non_bank_finance_loan_category_info_by_id($non_bank_finance_loan_category_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_loan_category');
        $this->db->where('non_bank_finance_loan_category_id', $non_bank_finance_loan_category_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_loan_category_info($data, $non_bank_finance_loan_category_id) 
    {
        $this->db->where('non_bank_finance_loan_category_id', $non_bank_finance_loan_category_id);
        $this->db->update('tbl_non_bank_finance_loan_category', $data);
    }

    public function delete_non_bank_finance_loan_category_by_id($non_bank_finance_loan_category_id)
    {
        $this->db->where('non_bank_finance_loan_category_id',$non_bank_finance_loan_category_id);
        $this->db->delete('tbl_non_bank_finance_loan_category');
    }

    /*
        * ------ Save Non Bank Finance Loan Categogy All Database Information End ------- *
    */

    /*
        * ---- Save Non Bank Finance Loan Information All Database Information Start From 276 to 329 ----- *
    */

    public function save_non_bank_finance_loan_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_loan_info',$data);
    }

    public function select_all_non_bank_finance_loan_information()
    {
        $sql="SELECT l.*,c.non_bank_finance_loan_category_name,b.non_bank_finance_name 
                FROM tbl_non_bank_finance_loan_info as l,tbl_non_bank_finance_loan_category as c, tbl_non_bank_finance_name as b 
                WHERE  (l.non_bank_finance_id=b.non_bank_finance_id AND l.non_bank_finance_loan_category_id=c.non_bank_finance_loan_category_id)";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();

        return $result;
    }
    public function update_publication_loan_info_by_id($non_bank_finance_loan_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_loan_id',$non_bank_finance_loan_id);
        $this->db->update('tbl_non_bank_finance_loan_info');
          
    }
    public function update_unpublication_loan_info_by_id($non_bank_finance_loan_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_loan_id',$non_bank_finance_loan_id);
        $this->db->update('tbl_non_bank_finance_loan_info');
           
    }

    public function select_non_bank_finance_loan_info_by_id($non_bank_finance_loan_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_loan_info');
        $this->db->where('non_bank_finance_loan_id', $non_bank_finance_loan_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_loan_information_info($data, $non_bank_finance_loan_id) 
    {
        $this->db->where('non_bank_finance_loan_id', $non_bank_finance_loan_id);
        $this->db->update('tbl_non_bank_finance_loan_info', $data);
    }

    public function delete_non_bank_finance_loan_info_by_id($non_bank_finance_loan_id)
    {
        $this->db->where('non_bank_finance_loan_id',$non_bank_finance_loan_id);
        $this->db->delete('tbl_non_bank_finance_loan_info');
    }

    /*
        * ------- Save Non Bank Finance Loan Information All Database Information End --------- *
    */


    public function save_non_bank_finance_double_benefit_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_double_benefit',$data);
    }

    public function select_non_bank_finance_double_benefit_info()
    {
        
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_double_benefit');
        $this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_double_benefit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_double_benefit_info_by_id($non_bank_finance_double_benefit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_double_benefit_id',$non_bank_finance_double_benefit_id);
        $this->db->update('tbl_non_bank_finance_double_benefit');
          
    }
    public function update_unpublication_double_benefit_info_by_id($non_bank_finance_double_benefit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_double_benefit_id',$non_bank_finance_double_benefit_id);
        $this->db->update('tbl_non_bank_finance_double_benefit');
           
    }

    public function select_non_bank_finance_double_benefit_info_by_id($non_bank_finance_double_benefit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_double_benefit');
        $this->db->where('non_bank_finance_double_benefit_id', $non_bank_finance_double_benefit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_double_benefit_information_info($data, $non_bank_finance_double_benefit_id) 
    {
        $this->db->where('non_bank_finance_double_benefit_id', $non_bank_finance_double_benefit_id);
        $this->db->update('tbl_non_bank_finance_double_benefit', $data);
    }

    public function delete_non_bank_finance_double_benefit_info_by_id($non_bank_finance_double_benefit_id)
    {
        $this->db->where('non_bank_finance_double_benefit_id',$non_bank_finance_double_benefit_id);
        $this->db->delete('tbl_non_bank_finance_double_benefit');
    }

    /** ------- -------------------------------------------------------------- --------- **/

    public function save_non_bank_finance_triple_benefit_info($data)
    {
        $this->db->insert('tbl_non_bank_finance_triple_benefit_info',$data);
    }

    public function select_all_non_bank_finance_triple_benefit_information()
     {
        
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_triple_benefit_info');
        $this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_triple_benefit_info.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('non_bank_finance_triple_benefit_id',$non_bank_finance_triple_benefit_id);
        $this->db->update('tbl_non_bank_finance_triple_benefit_info');
          
    }
    public function update_unpublication_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('non_bank_finance_triple_benefit_id',$non_bank_finance_triple_benefit_id);
        $this->db->update('tbl_non_bank_finance_triple_benefit_info');
           
    }

    public function select_non_bank_finance_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_triple_benefit_info');
        $this->db->where('non_bank_finance_triple_benefit_id', $non_bank_finance_triple_benefit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_non_bank_finance_triple_benefit_information_info($data, $non_bank_finance_triple_benefit_id) 
    {
        $this->db->where('non_bank_finance_triple_benefit_id', $non_bank_finance_triple_benefit_id);
        $this->db->update('tbl_non_bank_finance_triple_benefit_info', $data);
    }

    public function delete_non_bank_finance_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id)
    {
        $this->db->where('non_bank_finance_triple_benefit_id',$non_bank_finance_triple_benefit_id);
        $this->db->delete('tbl_non_bank_finance_triple_benefit_info');
    }

    

    public function select_all_published_non_bank_finance_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_non_bank_finance_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_name');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_non_bank_finance_loan_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_loan_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

}