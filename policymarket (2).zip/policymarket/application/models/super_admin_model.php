<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Super_Admin_Model extends CI_Model {
    
    /*
        * ------- Save Bank Category All Database Information Start form Line 9 to 62--------- *
    */

    public function save_bank_category_info($data)
    {
        $this->db->insert('tbl_bank_category',$data);
    }

    public function select_all_bank_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_category');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_id($bank_category_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_category_id',$bank_category_id);
        $this->db->update('tbl_bank_category');
          
    }
    public function update_unpublication_status_by_id($bank_category_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_category_id',$bank_category_id);
        $this->db->update('tbl_bank_category');
           
    }

    public function select_bank_category_info_by_id($bank_category_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_category');
        $this->db->where('bank_category_id', $bank_category_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_category_info($data, $bank_category_id) 
    {
        $this->db->where('bank_category_id', $bank_category_id);
        $this->db->update('tbl_bank_category', $data);
    }

    public function delete_category_by_id($bank_category_id)
    {
        $this->db->where('bank_category_id',$bank_category_id);
        $this->db->delete('tbl_bank_category');
    }

    /*
        * ------- Save Bank Category All Database Information End--------- *
    */

    /*
        * ------- Save Bank Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_bank_name_info($data)
    {
        $this->db->insert('tbl_bank_name',$data);
    }

    public function select_all_bank_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_name');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_bank_id($bank_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_id',$bank_id);
        $this->db->update('tbl_bank_name');
          
    }
    public function update_unpublication_status_by_bank_id($bank_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_id',$bank_id);
        $this->db->update('tbl_bank_name');
           
    }

    public function select_bank_name_info_by_id($bank_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_name');
        $this->db->where('bank_id', $bank_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_name_info($data, $bank_id) 
    {
        $this->db->where('bank_id', $bank_id);
        $this->db->update('tbl_bank_name', $data);
    }

    public function delete_bank_logo_by_id($bank_id)
    {
        $sql="SELECT * FROM tbl_bank_name WHERE bank_id='$bank_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->bank_logo");
        
        $this->db->set('bank_logo', '');
        $this->db->where('bank_id', $bank_id);
        $this->db->update('tbl_bank_name');
        
        return $result;
    }

    public function delete_category_by_bank_id($bank_id)
    {
        $this->db->where('bank_id',$bank_id);
        $this->db->delete('tbl_bank_name');
    }

    /*
        * ------- Save Bank Name All Database Information End--------- *
    */

    /*
        * ---- Save Bank Deposit Information All Database Information Start form Line 150 to 203 ------ *
    */

    public function save_bank_deposit_information_info($data)
    {
        $this->db->insert('tbl_bank_diposit',$data);
    }

    public function select_all_bank_deposit_information()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_diposit');
        $this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_bank_deposit_information($bank_diposit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_diposit_id',$bank_diposit_id);
        $this->db->update('tbl_bank_diposit');
          
    }
    public function update_unpublication_status_by_bank_deposit_information($bank_diposit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_diposit_id',$bank_diposit_id);
        $this->db->update('tbl_bank_diposit');
           
    }

    public function select_bank_deposit_information_info_by_id($bank_diposit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_diposit');
        $this->db->where('bank_diposit_id', $bank_diposit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_deposit_information_info($data, $bank_diposit_id) 
    {
        $this->db->where('bank_diposit_id', $bank_diposit_id);
        $this->db->update('tbl_bank_diposit', $data);
    }

    public function delete_category_by_bank_deposit_information($bank_diposit_id)
    {
        $this->db->where('bank_diposit_id',$bank_diposit_id);
        $this->db->delete('tbl_bank_diposit');
    }

    /*
        * ------- Save Bank Deposit Information All Database Information End --------- *
    */

    /*
        * ---- Save Bank Loan Categogy All Database Information Start From 213 to 266 ----- *
    */

    public function save_bank_loan_category_info($data)
    {
        $this->db->insert('tbl_bank_loan_category',$data);
    }

    public function select_all_bank_loan_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_loan_category');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_loan_status_by_id($bank_loan_category_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_loan_category_id',$bank_loan_category_id);
        $this->db->update('tbl_bank_loan_category');
          
    }
    public function update_unpublication_loan_status_by_id($bank_loan_category_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_loan_category_id',$bank_loan_category_id);
        $this->db->update('tbl_bank_loan_category');
           
    }

    public function select_bank_loan_category_info_by_id($bank_loan_category_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_loan_category');
        $this->db->where('bank_loan_category_id', $bank_loan_category_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_loan_category_info($data, $bank_loan_category_id) 
    {
        $this->db->where('bank_loan_category_id', $bank_loan_category_id);
        $this->db->update('tbl_bank_loan_category', $data);
    }

    public function delete_bank_loan_category_by_id($bank_loan_category_id)
    {
        $this->db->where('bank_loan_category_id',$bank_loan_category_id);
        $this->db->delete('tbl_bank_loan_category');
    }

    /*
        * ------ Save Bank Loan Categogy All Database Information End ------- *
    */

    /*
        * ---- Save Bank Loan Information All Database Information Start From 276 to 329 ----- *
    */

    public function save_bank_loan_info($data)
    {
        $this->db->insert('tbl_bank_loan_info',$data);
    }

    public function select_all_bank_loan_information()
    {
        $sql="SELECT l.*,c.bank_loan_category_name,b.bank_name 
                FROM tbl_bank_loan_info as l,tbl_bank_loan_category as c, tbl_bank_name as b 
                WHERE  (l.bank_id=b.bank_id AND l.bank_loan_category_id=c.bank_loan_category_id)";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();

        return $result;
    }

    public function update_publication_loan_info_by_id($bank_loan_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_loan_id',$bank_loan_id);
        $this->db->update('tbl_bank_loan_info');
          
    }
    public function update_unpublication_loan_info_by_id($bank_loan_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_loan_id',$bank_loan_id);
        $this->db->update('tbl_bank_loan_info');
           
    }

    public function select_bank_loan_info_by_id($bank_loan_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_loan_info');
        $this->db->where('bank_loan_id', $bank_loan_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_loan_information_info($data, $bank_loan_id) 
    {
        $this->db->where('bank_loan_id', $bank_loan_id);
        $this->db->update('tbl_bank_loan_info', $data);
    }

    public function delete_bank_loan_info_by_id($bank_loan_id)
    {
        $this->db->where('bank_loan_id',$bank_loan_id);
        $this->db->delete('tbl_bank_loan_info');
    }

    /*
        * ------- Save Bank Loan Information All Database Information End --------- *
    */

    /*
        * ------- Save Bank Exchange Rates Information All Database Information Start --------- *
    */

    public function save_bank_exchange_rates_info($data)
    {
        $this->db->insert('tbl_bank_exchange_rates',$data);
    }

    public function select_all_bank_exchange_rates_information()
    {
        
        $this->db->select('*');
        $this->db->from('tbl_bank_exchange_rates');
        $this->db->join('tbl_bank_name', 'tbl_bank_exchange_rates.bank_id = tbl_bank_name.bank_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_exchange_rates_info_by_id($bank_exchange_rates_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_exchange_rates_id',$bank_exchange_rates_id);
        $this->db->update('tbl_bank_exchange_rates');
          
    }
    public function update_unpublication_exchange_rates_info_by_id($bank_exchange_rates_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_exchange_rates_id',$bank_exchange_rates_id);
        $this->db->update('tbl_bank_exchange_rates');
           
    }

    public function select_bank_exchange_rates_info_by_id($bank_exchange_rates_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_exchange_rates');
        $this->db->where('bank_exchange_rates_id', $bank_exchange_rates_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_exchange_rates_information_info($data, $bank_exchange_rates_id) 
    {
        $this->db->where('bank_exchange_rates_id', $bank_exchange_rates_id);
        $this->db->update('tbl_bank_exchange_rates', $data);
    }

    public function delete_bank_exchange_rates_info_by_id($bank_exchange_rates_id)
    {
        $this->db->where('bank_exchange_rates_id',$bank_exchange_rates_id);
        $this->db->delete('tbl_bank_exchange_rates');
    }

    /*
        * ------- Save Bank Exchange Rates Information All Database Information End --------- *
    */

    public function save_bank_double_benefit_info($data)
    {
        $this->db->insert('tbl_bank_double_benefit',$data);
    }

    public function select_bank_double_benefit_info()
    {
        
        $this->db->select('*');
        $this->db->from('tbl_bank_double_benefit');
        $this->db->join('tbl_bank_name', 'tbl_bank_double_benefit.bank_id = tbl_bank_name.bank_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_double_benefit_info_by_id($bank_double_benefit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_double_benefit_id',$bank_double_benefit_id);
        $this->db->update('tbl_bank_double_benefit');
          
    }
    public function update_unpublication_double_benefit_info_by_id($bank_double_benefit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_double_benefit_id',$bank_double_benefit_id);
        $this->db->update('tbl_bank_double_benefit');
           
    }

    public function select_bank_double_benefit_info_by_id($bank_double_benefit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_double_benefit');
        $this->db->where('bank_double_benefit_id', $bank_double_benefit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_double_benefit_information_info($data, $bank_double_benefit_id) 
    {
        $this->db->where('bank_double_benefit_id', $bank_double_benefit_id);
        $this->db->update('tbl_bank_double_benefit', $data);
    }

    public function delete_bank_double_benefit_info_by_id($bank_double_benefit_id)
    {
        $this->db->where('bank_double_benefit_id',$bank_double_benefit_id);
        $this->db->delete('tbl_bank_double_benefit');
    }

    /** ------- -------------------------------------------------------------- --------- **/

    public function save_bank_triple_benefit_info($data)
    {
        $this->db->insert('tbl_bank_triple_benefit_info',$data);
    }

    public function select_all_bank_triple_benefit_information()
     {
        
        $this->db->select('*');
        $this->db->from('tbl_bank_triple_benefit_info');
        $this->db->join('tbl_bank_name', 'tbl_bank_triple_benefit_info.bank_id = tbl_bank_name.bank_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_triple_benefit_info_by_id($bank_triple_benefit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('bank_triple_benefit_id',$bank_triple_benefit_id);
        $this->db->update('tbl_bank_triple_benefit_info');
          
    }
    public function update_unpublication_triple_benefit_info_by_id($bank_triple_benefit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('bank_triple_benefit_id',$bank_triple_benefit_id);
        $this->db->update('tbl_bank_triple_benefit_info');
           
    }

    public function select_bank_triple_benefit_info_by_id($bank_triple_benefit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_triple_benefit_info');
        $this->db->where('bank_triple_benefit_id', $bank_triple_benefit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_bank_triple_benefit_information_info($data, $bank_triple_benefit_id) 
    {
        $this->db->where('bank_triple_benefit_id', $bank_triple_benefit_id);
        $this->db->update('tbl_bank_triple_benefit_info', $data);
    }

    public function delete_bank_triple_benefit_info_by_id($bank_triple_benefit_id)
    {
        $this->db->where('bank_triple_benefit_id',$bank_triple_benefit_id);
        $this->db->delete('tbl_bank_triple_benefit_info');
    }

    /** ------- -------------------------------------------------------------- --------- **/

    public function select_all_published_bank_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_bank_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_name');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_bank_loan_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_bank_loan_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

}