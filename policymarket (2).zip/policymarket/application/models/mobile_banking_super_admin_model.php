<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Mobile_Banking_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_mobile_banking_name_info($data)
    {
        $this->db->insert('tbl_mobile_banking',$data);
    }

    public function select_all_mobile_banking_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_mobile_banking');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_mobile_banking_id($mobile_banking_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('mobile_banking_id',$mobile_banking_id);
        $this->db->update('tbl_mobile_banking');
          
    }
    public function update_unpublication_status_by_mobile_banking_id($mobile_banking_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('mobile_banking_id',$mobile_banking_id);
        $this->db->update('tbl_mobile_banking');
           
    }

    public function select_mobile_banking_name_info_by_id($mobile_banking_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_mobile_banking');
        $this->db->where('mobile_banking_id', $mobile_banking_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_mobile_banking_name_info($data, $mobile_banking_id) 
    {
        $this->db->where('mobile_banking_id', $mobile_banking_id);
        $this->db->update('tbl_mobile_banking', $data);
    }

    public function delete_mobile_banking_logo_by_id($mobile_banking_id)
    {
        $sql="SELECT * FROM tbl_mobile_banking WHERE mobile_banking_id='$mobile_banking_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->mobile_banking_logo");
        
        $this->db->set('mobile_banking_logo', '');
        $this->db->where('mobile_banking_id', $mobile_banking_id);
        $this->db->update('tbl_mobile_banking');
        
        return $result;
    }

    public function delete_category_by_mobile_banking_id($mobile_banking_id)
    {
        $this->db->where('mobile_banking_id',$mobile_banking_id);
        $this->db->delete('tbl_mobile_banking');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

}