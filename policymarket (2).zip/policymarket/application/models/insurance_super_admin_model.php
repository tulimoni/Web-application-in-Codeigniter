<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Insurance_Super_Admin_Model extends CI_Model {
    
    /*
        * ------- Save Insurance Category All Database Information Start form Line 9 to 62--------- *
    */

    public function save_insurance_category_info($data)
    {
        $this->db->insert('tbl_insurance_category',$data);
    }

    public function select_all_insurance_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_category');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_id($insurance_category_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('insurance_category_id',$insurance_category_id);
        $this->db->update('tbl_insurance_category');
          
    }
    public function update_unpublication_status_by_id($insurance_category_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('insurance_category_id',$insurance_category_id);
        $this->db->update('tbl_insurance_category');
           
    }

    public function select_insurance_category_info_by_id($insurance_category_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_category');
        $this->db->where('insurance_category_id', $insurance_category_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_insurance_category_info($data, $insurance_category_id) 
    {
        $this->db->where('insurance_category_id', $insurance_category_id);
        $this->db->update('tbl_insurance_category', $data);
    }

    public function delete_category_by_id($insurance_category_id)
    {
        $this->db->where('insurance_category_id',$insurance_category_id);
        $this->db->delete('tbl_insurance_category');
    }

    /*
        * ------- Save Insurance Category All Database Information End--------- *
    */

    /*
        * ------- Save Insurance Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_insurance_name_info($data)
    {
        $this->db->insert('tbl_insurance_name',$data);
    }

    public function select_all_insurance_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_name');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_insurance_id($insurance_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('insurance_id',$insurance_id);
        $this->db->update('tbl_insurance_name');
          
    }
    public function update_unpublication_status_by_insurance_id($insurance_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('insurance_id',$insurance_id);
        $this->db->update('tbl_insurance_name');
           
    }

    public function select_insurance_name_info_by_id($insurance_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_name');
        $this->db->where('insurance_id', $insurance_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_insurance_name_info($data, $insurance_id) 
    {
        $this->db->where('insurance_id', $insurance_id);
        $this->db->update('tbl_insurance_name', $data);
    }

    public function delete_insurance_logo_by_id($insurance_id)
    {
        $sql="SELECT * FROM tbl_insurance_name WHERE insurance_id='$insurance_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->insurance_logo");
        
        $this->db->set('insurance_logo', '');
        $this->db->where('insurance_id', $insurance_id);
        $this->db->update('tbl_insurance_name');
        
        return $result;
    }

    public function delete_category_by_insurance_id($insurance_id)
    {
        $this->db->where('insurance_id',$insurance_id);
        $this->db->delete('tbl_insurance_name');
    }

    /*
        * ------- Save Insurance Name All Database Information End--------- *
    */

    /*
        * ---- Save Insurance Deposit Information All Database Information Start form Line 150 to 203 ------ *
    */

    public function save_insurance_deposit_information_info($data)
    {
        $this->db->insert('tbl_insurance_diposit',$data);
    }

    public function select_all_insurance_deposit_information()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_diposit');
        $this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_insurance_deposit_information($insurance_diposit_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('insurance_diposit_id',$insurance_diposit_id);
        $this->db->update('tbl_insurance_diposit');
          
    }
    public function update_unpublication_status_by_insurance_deposit_information($insurance_diposit_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('insurance_diposit_id',$insurance_diposit_id);
        $this->db->update('tbl_insurance_diposit');
           
    }

    public function select_insurance_deposit_information_info_by_id($insurance_diposit_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_diposit');
        $this->db->where('insurance_diposit_id', $insurance_diposit_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_insurance_deposit_information_info($data, $insurance_diposit_id) 
    {
        $this->db->where('insurance_diposit_id', $insurance_diposit_id);
        $this->db->update('tbl_insurance_diposit', $data);
    }

    public function delete_category_by_insurance_deposit_information($insurance_diposit_id)
    {
        $this->db->where('insurance_diposit_id',$insurance_diposit_id);
        $this->db->delete('tbl_insurance_diposit');
    }

    /*
        * ------- Save Insurance Deposit Information All Database Information End --------- *
    */

    /** ------- -------------------------------------------------------------- --------- **/

    public function select_all_published_insurance_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_insurance_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_name');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_published_insurance_loan_category_id()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_loan_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

}