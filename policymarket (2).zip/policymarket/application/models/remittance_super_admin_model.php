<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Remittance_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_remittance_name_info($data)
    {
        $this->db->insert('tbl_remittance',$data);
    }

    public function select_all_remittance_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_remittance');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_remittance_id($remittance_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('remittance_id',$remittance_id);
        $this->db->update('tbl_remittance');
          
    }
    public function update_unpublication_status_by_remittance_id($remittance_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('remittance_id',$remittance_id);
        $this->db->update('tbl_remittance');
           
    }

    public function select_remittance_name_info_by_id($remittance_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_remittance');
        $this->db->where('remittance_id', $remittance_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_remittance_name_info($data, $remittance_id) 
    {
        $this->db->where('remittance_id', $remittance_id);
        $this->db->update('tbl_remittance', $data);
    }

    public function delete_remittance_logo_by_id($remittance_id)
    {
        $sql="SELECT * FROM tbl_remittance WHERE remittance_id='$remittance_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->remittance_logo");
        
        $this->db->set('remittance_logo', '');
        $this->db->where('remittance_id', $remittance_id);
        $this->db->update('tbl_remittance');
        
        return $result;
    }

    public function delete_category_by_remittance_id($remittance_id)
    {
        $this->db->where('remittance_id',$remittance_id);
        $this->db->delete('tbl_remittance');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

}