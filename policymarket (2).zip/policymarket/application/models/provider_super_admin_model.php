<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Provider_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_provider_name_info($data)
    {
        $this->db->insert('tbl_payment_getway',$data);
    }

    public function select_all_provider_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_payment_getway');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_provider_id($provider_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('provider_id',$provider_id);
        $this->db->update('tbl_payment_getway');
          
    }
    public function update_unpublication_status_by_provider_id($provider_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('provider_id',$provider_id);
        $this->db->update('tbl_payment_getway');
           
    }

    public function select_provider_name_info_by_id($provider_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_payment_getway');
        $this->db->where('provider_id', $provider_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_provider_name_info($data, $provider_id) 
    {
        $this->db->where('provider_id', $provider_id);
        $this->db->update('tbl_payment_getway', $data);
    }

    public function delete_provider_logo_by_id($provider_id)
    {
        $sql="SELECT * FROM tbl_payment_getway WHERE provider_id='$provider_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->provider_logo");
        
        $this->db->set('provider_logo', '');
        $this->db->where('provider_id', $provider_id);
        $this->db->update('tbl_payment_getway');
        
        return $result;
    }

    public function delete_category_by_provider_id($provider_id)
    {
        $this->db->where('provider_id',$provider_id);
        $this->db->delete('tbl_payment_getway');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

}