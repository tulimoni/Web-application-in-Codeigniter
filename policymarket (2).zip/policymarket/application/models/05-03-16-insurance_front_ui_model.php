<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurance_Front_Ui_Model extends CI_Model {
    	
	public function search_diposit_info($installment_amount,$instalment_type,$year)
	{
		$where = "diposit_amount='$installment_amount' AND diposit_type='$instalment_type' and  OR diposit_duration='$year'";
 		$this->db->select('*');
  		$this->db->from('tbl_insurance_diposit');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$instalment_type)->where('tbl_insurance_diposit.publication_status',1)->or_where('diposit_duration',$year);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
      	return $result;  
    }

	public function compare1($installment_amount,$installment_type,$deposit_year,$insurance_name1)
	{
		$this->db->select('*');
  		$this->db->from('tbl_insurance_diposit');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_insurance_diposit.insurance_id',$insurance_name1)->where('tbl_insurance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
      	return $result; 
	}
	
	public function compare2($installment_amount,$installment_type,$deposit_year,$insurance_name2)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_insurance_diposit');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_insurance_diposit.insurance_id',$insurance_name2)->where('tbl_insurance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
      	return $result; 
   	}
	
	public function compare3($installment_amount,$installment_type,$deposit_year,$insurance_name3)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_insurance_diposit');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_insurance_diposit.insurance_id',$insurance_name3)->where('tbl_insurance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
    return $result; 
	}
	
	public function select_all_published_loan_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_loan_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function search_loan_info($insurance_loan_id)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_insurance_loan_info');
  		$this->db->join('tbl_insurance_loan_category', 'tbl_insurance_loan_info.insurance_loan_category_id = tbl_insurance_loan_category.insurance_loan_category_id');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_loan_info.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('tbl_insurance_loan_info.insurance_loan_category_id',$insurance_loan_id)->where('tbl_insurance_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
   	}

 	public function form_loan()
    {
      $this->db->select('*');
      $this->db->from('tbl_insurance_name');
	  $this->db->join('tbl_insurance_category', 'tbl_insurance_name.insurance_category_id = tbl_insurance_category.insurance_category_id');
      $this->db->where('publication_status',1);
      $query_result=$this->db->get();
      $result=$query_result->result();
       
      return $result;
    }
		
	public function select_insurance()
    {
      $this->db->select('*');
      $this->db->from('tbl_insurance_name');
	  $this->db->join('tbl_insurance_category', 'tbl_insurance_name.insurance_category_id = tbl_insurance_category.insurance_category_id');
      $this->db->where('tbl_insurance_name.publication_status',1);
      $query_result=$this->db->get();
      $result=$query_result->result();
       
      return $result;
    }
	
	public function cat()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function select_insurance_by_cat($cat)
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_name');
		$this->db->join('tbl_insurance_category', 'tbl_insurance_name.insurance_category_id = tbl_insurance_category.insurance_category_id');
        $this->db->where('tbl_insurance_name.publication_status',1)->where('tbl_insurance_category.insurance_category_id',$cat);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function search_all_insurance()
    {
        $this->db->select('*');
        $this->db->from('tbl_insurance_name'); 
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_payment_getway()
    {
        $this->db->select('*');
        $this->db->from('tbl_payment_getway'); 
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function select_all_remittance()
    {
        $this->db->select('*');
        $this->db->from('tbl_remittance'); 
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function show_diposit_info($pro)
	{
		$this->db->select('*');
		$this->db->from('tbl_insurance_diposit');
		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('insurance_diposit_id',$pro)->where('tbl_insurance_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
	}

	public function select_exchange_type()
	{
	 	$this->db->select('*');
	 	$this->db->group_by('currency_type');
		$this->db->from('tbl_insurance_exchange_rates');
		$this->db->where('publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;
	}
	
	public function currency_type($currency_type)
	{
		$this->db->select('*');
  		$this->db->from('tbl_insurance_exchange_rates');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_exchange_rates.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('currency_type',$currency_type)->where('tbl_insurance_exchange_rates.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}
	
	public function default_usd_select()
	{
		$this->db->select('*');
  		$this->db->from('tbl_insurance_exchange_rates');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_exchange_rates.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('currency_type','USD')->where('tbl_insurance_exchange_rates.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}
	
	public function default_deposit_select()
	{
		$this->db->select('*');
  		$this->db->from('tbl_insurance_diposit');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_diposit.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('diposit_amount','500')->where('tbl_insurance_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

	public function default_loan_select()
	{
		$this->db->select('*');
  		$this->db->from('tbl_insurance_loan_info');
  		$this->db->join('tbl_insurance_name', 'tbl_insurance_loan_info.insurance_id = tbl_insurance_name.insurance_id');
		$this->db->where('insurance_loan_category_id','3')->where('tbl_insurance_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

}	 
	 
	
