<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Jobs_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_jobs_name_info($data)
    {
        $this->db->insert('tbl_jobs',$data);
    }

    public function select_all_jobs_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_jobs');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_jobs_id($jobs_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('jobs_id',$jobs_id);
        $this->db->update('tbl_jobs');
          
    }
    public function update_unpublication_status_by_jobs_id($jobs_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('jobs_id',$jobs_id);
        $this->db->update('tbl_jobs');
           
    }

    public function select_jobs_name_info_by_id($jobs_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_jobs');
        $this->db->where('jobs_id', $jobs_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_jobs_name_info($data, $jobs_id) 
    {
        $this->db->where('jobs_id', $jobs_id);
        $this->db->update('tbl_jobs', $data);
    }

    public function delete_jobs_logo_by_id($jobs_id)
    {
        $sql="SELECT * FROM tbl_jobs WHERE jobs_id='$jobs_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->jobs_logo");
        
        $this->db->set('jobs_logo', '');
        $this->db->where('jobs_id', $jobs_id);
        $this->db->update('tbl_jobs');
        
        return $result;
    }

    public function delete_category_by_jobs_id($jobs_id)
    {
        $this->db->where('jobs_id',$jobs_id);
        $this->db->delete('tbl_jobs');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

}