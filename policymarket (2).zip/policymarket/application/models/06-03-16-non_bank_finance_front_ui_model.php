<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Non_Bank_Finance_Front_Ui_Model extends CI_Model {
    	
	public function search_diposit_info($installment_amount,$instalment_type,$year)
	{
		$where = "diposit_amount='$installment_amount' AND diposit_type='$instalment_type' and  OR diposit_duration='$year'";
 		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_diposit');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$instalment_type)->where('tbl_non_bank_finance_diposit.publication_status',1)->or_where('diposit_duration',$year);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
      	return $result;  
    }

	public function compare1($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name1)
	{
		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_diposit');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_non_bank_finance_diposit.non_bank_finance_id',$non_bank_finance_name1)->where('tbl_non_bank_finance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
      	return $result; 
	}
	
	public function compare2($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name2)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_diposit');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_non_bank_finance_diposit.non_bank_finance_id',$non_bank_finance_name2)->where('tbl_non_bank_finance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
      	return $result; 
   	}
	
	public function compare3($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name3)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_diposit');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_type',$installment_type)->where('tbl_non_bank_finance_diposit.non_bank_finance_id',$non_bank_finance_name3)->where('tbl_non_bank_finance_diposit.publication_status',1)->or_where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
    return $result; 
	}
	
	public function select_all_published_loan_category()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_loan_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function search_loan_info($non_bank_finance_loan_id)
	{
 		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_loan_info');
  		$this->db->join('tbl_non_bank_finance_loan_category', 'tbl_non_bank_finance_loan_info.non_bank_finance_loan_category_id = tbl_non_bank_finance_loan_category.non_bank_finance_loan_category_id');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_loan_info.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('tbl_non_bank_finance_loan_info.non_bank_finance_loan_category_id',$non_bank_finance_loan_id)->where('tbl_non_bank_finance_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
   	}

 	public function form_loan()
    {
      $this->db->select('*');
      $this->db->from('tbl_non_bank_finance_name');
	  $this->db->join('tbl_non_bank_finance_category', 'tbl_non_bank_finance_name.non_bank_finance_category_id = tbl_non_bank_finance_category.non_bank_finance_category_id');
      $this->db->where('publication_status',1);
      $query_result=$this->db->get();
      $result=$query_result->result();
       
      return $result;
    }
		
	public function select_non_bank_finance()
    {
      $this->db->select('*');
      $this->db->from('tbl_non_bank_finance_name');
	  $this->db->join('tbl_non_bank_finance_category', 'tbl_non_bank_finance_name.non_bank_finance_category_id = tbl_non_bank_finance_category.non_bank_finance_category_id');
      $this->db->where('tbl_non_bank_finance_name.publication_status',1);
      $query_result=$this->db->get();
      $result=$query_result->result();
       
      return $result;
    }
	
	public function cat()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_category');
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function select_non_bank_finance_by_cat($cat)
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_name');
		$this->db->join('tbl_non_bank_finance_category', 'tbl_non_bank_finance_name.non_bank_finance_category_id = tbl_non_bank_finance_category.non_bank_finance_category_id');
        $this->db->where('tbl_non_bank_finance_name.publication_status',1)->where('tbl_non_bank_finance_category.non_bank_finance_category_id',$cat);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }
	
	public function search_all_non_bank_finance()
    {
        $this->db->select('*');
        $this->db->from('tbl_non_bank_finance_name'); 
        $this->db->where('publication_status',1);
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }


	public function show_diposit_info($pro)
	{
		$this->db->select('*');
		$this->db->from('tbl_non_bank_finance_diposit');
		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('non_bank_finance_diposit_id',$pro)->where('tbl_non_bank_finance_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
	}


	
	public function default_deposit_select()
	{
		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_diposit');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_diposit.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('diposit_amount','500')->where('tbl_non_bank_finance_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

	public function default_loan_select()
	{
		$this->db->select('*');
  		$this->db->from('tbl_non_bank_finance_loan_info');
  		$this->db->join('tbl_non_bank_finance_name', 'tbl_non_bank_finance_loan_info.non_bank_finance_id = tbl_non_bank_finance_name.non_bank_finance_id');
		$this->db->where('non_bank_finance_loan_category_id','3')->where('tbl_non_bank_finance_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

}	 
	 
	
