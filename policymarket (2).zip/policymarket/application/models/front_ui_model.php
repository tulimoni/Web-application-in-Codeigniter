<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front_Ui_Model extends CI_Model {
    	
	public function search_diposit_info($installment_amount,$installment_name,$year)
	{
		$where = "diposit_amount='$installment_amount' AND diposit_name='$installment_name' OR diposit_duration='$year'";
 		$this->db->select('*');
  	$this->db->from('tbl_bank_diposit');
  	$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_name',$installment_name)->or_where('diposit_duration',$year)->where('tbl_bank_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
  }

  public function select_all_bank_deposit()
  {
    $this->db->select('diposit_amount');
    $this->db->group_by('diposit_amount');
    $this->db->from('tbl_bank_diposit'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_bank_deposit_name()
  {
    $this->db->select('diposit_name');
    $this->db->group_by('diposit_name');
    $this->db->from('tbl_bank_diposit'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_bank_deposit_duration()
  {
    $this->db->select('diposit_duration');
    $this->db->group_by('diposit_duration');
    $this->db->from('tbl_bank_diposit'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

	public function compare1($installment_amount,$installment_name,$deposit_year,$bank_name1)
	{
		$this->db->select('*');
  	$this->db->from('tbl_bank_diposit');
  	$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_name',$installment_name)->where('tbl_bank_diposit.bank_id',$bank_name1)->where('tbl_bank_diposit.publication_status',1)->where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
    return $result; 
	}
	
	public function compare2($installment_amount,$installment_name,$deposit_year,$bank_name2)
	{
 		$this->db->select('*');
  	$this->db->from('tbl_bank_diposit');
  	$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_name',$installment_name)->where('tbl_bank_diposit.bank_id',$bank_name2)->where('tbl_bank_diposit.publication_status',1)->where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
    return $result; 
   	}
	
	public function compare3($installment_amount,$installment_name,$deposit_year,$bank_name3)
	{
 		$this->db->select('*');
  	$this->db->from('tbl_bank_diposit');
  	$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('diposit_amount',$installment_amount)->where('diposit_name',$installment_name)->where('tbl_bank_diposit.bank_id',$bank_name3)->where('tbl_bank_diposit.publication_status',1)->where('diposit_duration',$deposit_year);
		$query_result=$this->db->get();
		$result=$query_result->result();
     
    return $result; 
	}
	
	public function select_all_published_loan_category()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_loan_category');
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }
	
	public function search_loan_info($bank_loan_id)
	{
 		$this->db->select('*');
  	$this->db->from('tbl_bank_loan_info');
  	$this->db->join('tbl_bank_loan_category', 'tbl_bank_loan_info.bank_loan_category_id = tbl_bank_loan_category.bank_loan_category_id');
  	$this->db->join('tbl_bank_name', 'tbl_bank_loan_info.bank_id = tbl_bank_name.bank_id');
		$this->db->where('tbl_bank_loan_info.bank_loan_category_id',$bank_loan_id)->where('tbl_bank_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
   	}

 	public function form_loan()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_name');
	  $this->db->join('tbl_bank_category', 'tbl_bank_name.bank_category_id = tbl_bank_category.bank_category_id');
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }
		
	public function select_bank()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_name');
	  $this->db->join('tbl_bank_category', 'tbl_bank_name.bank_category_id = tbl_bank_category.bank_category_id');
    $this->db->where('tbl_bank_name.publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }
	
	public function cat()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_category');
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }
	
	public function select_bank_by_cat($cat)
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_name');
		$this->db->join('tbl_bank_category', 'tbl_bank_name.bank_category_id = tbl_bank_category.bank_category_id');
    $this->db->where('tbl_bank_name.publication_status',1)->where('tbl_bank_category.bank_category_id',$cat);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }
	
	public function search_all_bank()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_name'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_payment_getway()
  {
    $this->db->select('*');
    $this->db->from('tbl_payment_getway'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_remittance()
  {
    $this->db->select('*');
    $this->db->from('tbl_remittance'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_share_market()
  {
    $this->db->select('*');
    $this->db->from('tbl_share_market'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_brokerage_house()
  {
    $this->db->select('*');
    $this->db->from('tbl_brokerage_house'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_news()
  {
    $this->db->select('*');
    $this->db->from('tbl_policy_news'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_all_news_id($news_id)
  {
    $this->db->select('*');
    $this->db->from('tbl_policy_news');
    $this->db->where('news_id',$news_id);
    $query_result=$this->db->get();
    $result=$query_result->row();
       
    return $result;
  }
	
	public function show_diposit_info($pro)
	{
		$this->db->select('*');
		$this->db->from('tbl_bank_diposit');
		$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('bank_diposit_id',$pro)->where('tbl_bank_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;  
	}

	public function select_exchange_type()
	{
	 	$this->db->select('*');
	 	$this->db->group_by('currency_type');
		$this->db->from('tbl_bank_exchange_rates');
		$this->db->where('publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result;
	}
	
	public function currency_type($currency_type)
	{
		$this->db->select('*');
  	$this->db->from('tbl_bank_exchange_rates');
  	$this->db->join('tbl_bank_name', 'tbl_bank_exchange_rates.bank_id = tbl_bank_name.bank_id');
		$this->db->where('currency_type',$currency_type)->where('tbl_bank_exchange_rates.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}
	
	public function default_usd_select()
	{
		$this->db->select('*');
  	$this->db->from('tbl_bank_exchange_rates');
  	$this->db->join('tbl_bank_name', 'tbl_bank_exchange_rates.bank_id = tbl_bank_name.bank_id');
		$this->db->where('currency_type','USD')->where('tbl_bank_exchange_rates.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}
	
	public function default_deposit_select()
	{
		$this->db->select('*');
  	$this->db->from('tbl_bank_diposit');
  	$this->db->join('tbl_bank_name', 'tbl_bank_diposit.bank_id = tbl_bank_name.bank_id');
		$this->db->where('diposit_amount','500')->where('tbl_bank_diposit.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

	public function default_loan_select()
	{
		$this->db->select('*');
  	$this->db->from('tbl_bank_loan_info');
  	$this->db->join('tbl_bank_name', 'tbl_bank_loan_info.bank_id = tbl_bank_name.bank_id');
		$this->db->where('bank_loan_category_id','3')->where('tbl_bank_loan_info.publication_status',1);
		$query_result=$this->db->get();
		$result=$query_result->result();
       
    return $result; 
	}

   public function select_all_jobs()
  {
    $this->db->select('*');
    $this->db->from('tbl_jobs'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

   public function select_all_mobile_banking()
  {
    $this->db->select('*');
    $this->db->from('tbl_mobile_banking'); 
    $this->db->where('publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result;
  }

  public function select_double_benefit()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_double_benefit');
    $this->db->join('tbl_bank_name', 'tbl_bank_double_benefit.bank_id = tbl_bank_name.bank_id');
    $this->db->where('tbl_bank_double_benefit.publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result; 
  }

  public function select_triple_benefit()
  {
    $this->db->select('*');
    $this->db->from('tbl_bank_triple_benefit_info');
    $this->db->join('tbl_bank_name', 'tbl_bank_triple_benefit_info.bank_id = tbl_bank_name.bank_id');
    $this->db->where('tbl_bank_triple_benefit_info.publication_status',1);
    $query_result=$this->db->get();
    $result=$query_result->result();
       
    return $result; 
  }

}	 
	 
	
