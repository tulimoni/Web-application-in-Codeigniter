<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Stock_Exchange_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_stock_exchange_name_info($data)
    {
        $this->db->insert('tbl_share_market',$data);
    }

    public function select_all_stock_exchange_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_share_market');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_stock_exchange_id($stock_exchange_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('stock_exchange_id',$stock_exchange_id);
        $this->db->update('tbl_share_market');
          
    }
    public function update_unpublication_status_by_stock_exchange_id($stock_exchange_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('stock_exchange_id',$stock_exchange_id);
        $this->db->update('tbl_share_market');
           
    }

    public function select_stock_exchange_name_info_by_id($stock_exchange_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_share_market');
        $this->db->where('stock_exchange_id', $stock_exchange_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_stock_exchange_name_info($data, $stock_exchange_id) 
    {
        $this->db->where('stock_exchange_id', $stock_exchange_id);
        $this->db->update('tbl_share_market', $data);
    }

    public function delete_stock_exchange_logo_by_id($stock_exchange_id)
    {
        $sql="SELECT * FROM tbl_share_market WHERE stock_exchange_id='$stock_exchange_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->stock_exchange_logo");
        
        $this->db->set('stock_exchange_logo', '');
        $this->db->where('stock_exchange_id', $stock_exchange_id);
        $this->db->update('tbl_share_market');
        
        return $result;
    }

    public function delete_category_by_stock_exchange_id($stock_exchange_id)
    {
        $this->db->where('stock_exchange_id',$stock_exchange_id);
        $this->db->delete('tbl_share_market');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

    public function save_brokerage_house_name_info($data)
    {
        $this->db->insert('tbl_brokerage_house',$data);
    }

    public function select_all_brokerage_house_name()
    {
        $this->db->select('*');
        $this->db->from('tbl_brokerage_house');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_brokerage_house_id($brokerage_house_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('brokerage_house_id',$brokerage_house_id);
        $this->db->update('tbl_brokerage_house');
          
    }
    public function update_unpublication_status_by_brokerage_house_id($brokerage_house_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('brokerage_house_id',$brokerage_house_id);
        $this->db->update('tbl_brokerage_house');
           
    }

    public function select_brokerage_house_name_info_by_id($brokerage_house_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_brokerage_house');
        $this->db->where('brokerage_house_id', $brokerage_house_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_brokerage_house_name_info($data, $brokerage_house_id) 
    {
        $this->db->where('brokerage_house_id', $brokerage_house_id);
        $this->db->update('tbl_brokerage_house', $data);
    }

    public function delete_brokerage_house_logo_by_id($brokerage_house_id)
    {
        $sql="SELECT * FROM tbl_brokerage_house WHERE brokerage_house_id='$brokerage_house_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        //unlink("$result->brokerage_house_logo");
        
        $this->db->set('brokerage_house_logo', '');
        $this->db->where('brokerage_house_id', $brokerage_house_id);
        $this->db->update('tbl_brokerage_house');
        
        return $result;
    }

    public function delete_category_by_brokerage_house_id($brokerage_house_id)
    {
        $this->db->where('brokerage_house_id',$brokerage_house_id);
        $this->db->delete('tbl_brokerage_house');
    }

}