<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class News_Super_Admin_Model extends CI_Model {
    

    /*
        * ------- Save Providers Name All Database Information Start form Line 72 to 140--------- *
    */

    public function save_news_title_info($data)
    {
        $this->db->insert('tbl_policy_news',$data);
    }

    public function select_all_news_title()
    {
        $this->db->select('*');
        $this->db->from('tbl_policy_news');
        $query_result=$this->db->get();
        $result=$query_result->result();
       
        return $result;
    }

    public function update_publication_status_by_news_id($news_id)
    {
        
        $this->db->set('publication_status',1);
        $this->db->where('news_id',$news_id);
        $this->db->update('tbl_policy_news');
          
    }
    public function update_unpublication_status_by_news_id($news_id)
    {
        
        $this->db->set('publication_status',0);
        $this->db->where('news_id',$news_id);
        $this->db->update('tbl_policy_news');
           
    }

    public function select_news_title_info_by_id($news_id) 
    {
        $this->db->select('*');
        $this->db->from('tbl_policy_news');
        $this->db->where('news_id', $news_id);
        $query_result = $this->db->get();
        $result = $query_result->row();

        return $result;
    }

    public function update_news_title_info($data, $news_id) 
    {
        $this->db->where('news_id', $news_id);
        $this->db->update('tbl_policy_news', $data);
    }

    public function delete_news_logo_by_id($news_id)
    {
        $sql="SELECT * FROM tbl_policy_news WHERE news_id='$news_id'";
        $query_result = $this->db->query($sql);
        $result = $query_result->row();
       
        unlink("$result->news_logo");
        
        $this->db->set('news_logo', '');
        $this->db->where('news_id', $news_id);
        $this->db->update('tbl_policy_news');
        
        return $result;
    }

    public function delete_category_by_news_id($news_id)
    {
        $this->db->where('news_id',$news_id);
        $this->db->delete('tbl_policy_news');
    }

    /*
        * ------- Save Providers Name All Database Information End--------- *
    */

}