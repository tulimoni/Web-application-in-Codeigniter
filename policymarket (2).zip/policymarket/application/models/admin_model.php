<?php
class Admin_Model extends CI_Model {
    
    public function check_admin_login_info($admin_user_name,$admin_password)
    {
        $this->db->select('*');
        $this->db->from('tbl_admin');
        $this->db->where('admin_user_name',$admin_user_name);
        $this->db->where('admin_password',md5($admin_password));
        $query_result=$this->db->get();
        $result=$query_result->row();
        return $result;
    }
}