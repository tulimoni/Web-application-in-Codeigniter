<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

function lang_key($keyword = '') {
    // Get current CodeIgniter instance
    $CI = & get_instance();
    
    // $lang_id = 'ES';
    $lang_id = $CI->session->userdata('Lang_ID');
    $Key_title = $CI->trailmaster_model->get_foreign_title(trim($keyword), $lang_id);
    
    if (!$Key_title) {
        echo $keyword;
    } else {
        echo $Key_title;
    }
}

function pr($arr = array(), $flag = 0) {
    echo '<pre>';
    print_r($arr);
    echo '<pre>';
    if ($flag != 0) {
        die("<br/>==========ARRAY PRINT==========");
    }
}
