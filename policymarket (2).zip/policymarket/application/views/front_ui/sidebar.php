<div class="col-md-3">
  <div class="side-bar-revenues"> 
    <!-- Key Financials -->
    <h6 class="head"><a data-toggle="collapse" href="#key" aria-expanded="false"><i class="fa fa-university"></i>&nbsp;Bank</a></h6>
    <div class="collapse" id="key">
      <div class="well">
        <ul class="cate result">
          <li> <a href="<?php echo base_url();?>bank_ui/diposit_search">Deposit Information</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/loan_search">Loan Information</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/money_exchange">Money Exchange Rate</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/bank_search">Bank Information</a></li>
        </ul>
      </div>
    </div>
    
    <!-- Key Financials -->
    <h6 class="head"><a data-toggle="collapse" href="#Stories" aria-expanded="false"><i class="fa fa-codepen"></i>&nbsp;Insurance</a></h6>
    <div class="collapse" id="Stories">
      <div class="well">
        <ul class="cate result">
          <li> <a href="<?php echo base_url();?>insurance_ui/diposit_search">Insurance Deposit</a></li>
          <li><a href="<?php echo base_url();?>insurance_ui/insurance_search">Insurance Information</a></li>
        </ul>
      </div>
    </div>

    <!-- Key Financials -->
    <h6 class="head"><a data-toggle="collapse" href="#copo" aria-expanded="false"><i class="fa fa-home"></i>&nbsp;Non Finance Bank</a></h6>
    <div class="collapse" id="copo">
      <div class="well">
        <ul class="cate result">
          <li> <a href="<?php echo base_url();?>non_bank_finance_ui/diposit_search">Non Bank finance Deposit</a></li>
          <li><a href="<?php echo base_url();?>non_bank_finance_ui/loan_search"> Non Bank finance Loan</a></li>
          <li><a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_search">Non Bank finance Information</a></li>
        </ul>
      </div>
    </div>
    
    <!-- Media Relations -->
    <h6 class="head"><a href="<?php echo base_url();?>bank_ui/remittance"><i class="fa fa-bar-chart"></i>&nbsp;Remittance</a></h6>
    
    <!-- Key Financials -->
    <h6 class="head"><a href="<?php echo base_url();?>bank_ui/payment_getway"><i class="fa fa-money"></i>&nbsp;Payment Getway</a></h6>
    
    <!-- Key Financials -->
    <h6 class="head"><a data-toggle="collapse" href="#men" aria-expanded="false"><i class="fa fa-line-chart"></i>&nbsp;Share Market</a></h6>
    <div class="collapse" id="men">
      <div class="well">
        <ul class="cate result">
          <li> <a href="<?php echo base_url();?>bank_ui/b_share_market">Bangladeshi Stock Exchange</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/i_share_market">International Stock Exchange</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>