</div>
</div>
</section>

<section class="clients padding-top-30 padding-bottom-30">
  <div class="container">
    <div class="heading text-center">
      <!-- <h4>Our Amazing Clients</h4> -->
      <span></span> </div>
    <div class="single-slide">
      <div class="item">
        <ul class="row col-5">
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/AB_BANK_1.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/48.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
        </ul>
      </div>
      <div class="item">
        <ul class="row col-5">
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/48.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/AB_BANK_1.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
          <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
        </ul>
      </div>
    </div>
  </div>
</section>
</div>

<!-- FOOTER -->
<footer>
  <div class="container">
    <div class="row"> 
      
      <!-- ABOUT -->
      <div class="col-md-3 footimg"><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>front_assets/images/logo-footer.png"alt=""></a>
        <div class="about-foot">
          <ul>
           <!--<li><p><i class="fa fa-map-marker"></i> House #67/B,Flat #4B,Road #26(old),15/A(New)Dhanmondi, Dhaka-1209,Bangladesh.</p></li>-->
            <li>
              <p><i class="fa fa-phone"></i> (+88 04475 141844)</p>
              <p><i class="fa fa-phone"></i> (+88 01841 226262)</p>
            </li>
            <li>
              <p><i class="fa fa-envelope"></i>info.policymarket@gmail.com</p>
            </li>
          </ul>
        </div>
      </div>
      
      <!-- Twitter Feed -->
      <div class="col-md-3">
        <h6>Twitter Feed</h6>
        <ul class="tweet">
            <li>
              <p>Choose the best insurance Policy <a href="https://twitter.com/policy_market/status/706444270819934208" target="_blank" class="primary-color">https://twitter.com/?lang=en</a></p>
            </li>  
            
            <li>
              <p>Choose the best bank Policy <a href="https://twitter.com/policy_market/status/706444906466676736" target="_blank" class="primary-color" >https://twitter.com/?lang=en</a></p>
            </li> 
            
            <li>
              <p>Find the bank atm/branch in your preferred area <a href="https://twitter.com/policy_market/status/706445139409915904" target="_blank" class="primary-color">https://twitter.com/?lang=en</a></p>
            </li> 
            
            <li>
              <p>Find all payment gateway provide <a href="https://twitter.com/policy_market/status/706446142729400321" target="_blank" class="primary-color" >https://twitter.com/?lang=en</a></p>
            </li> 
          </ul>
      </div>
      
      <!-- Photostream -->
      <div class="col-md-3">
        <h6>Photostream</h6>
        <ul class="photo-steam">
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/9" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/US_Dollar.jpg" alt=""></a></li>
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/10" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/biz.jpg" alt=""></a></li>
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/13" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/Muhit-2015.jpg" alt=""></a></li>
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/14" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/l05Cc9x.jpg" alt=""></a></li>
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/16" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/India-Bangladesh_1.jpg" alt=""></a></li>
          <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/15" target="_blank"><img class="img-responsive" src="<?php echo base_url();?>image/news_logo/Bangladesh-Bank-Jobs-Circular-2016.jpg" alt=""></a></li>
        </ul>
      </div>
      
      <!-- Categories -->
      <div class="col-md-3">
        <h6>Policy Market Services</h6>
        <ul class="xlink">
          <li><a href="<?php echo base_url();?>"> Home</a> </li>
          <li><a href="<?php echo base_url();?>bank_ui/bank_show"> Bank</a> </li>
          <li><a href="<?php echo base_url();?>insurance_ui/insurance_show">Insurance</a></li>
          <li> <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_show">House Finance</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/remittance">Remittance </a> </li>
          <li><a href="<?php echo base_url();?>bank_ui/payment_getway">Payment Gateway</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/share_market">Share Market</a></li>
          <li> <a href="<?php echo base_url();?>bank_ui/bank_atm_locator">ATM/Branch Locator</a> </li>
        </ul>
      </div>
    </div>
  </div>
</footer>

<!-- RIGHTS -->
<div class="rights">
  <div class="container">
    <div class="row">
      <div class="col-md-6 customfoot">
        <p> © All Rights Reserved <?php echo date("Y");?>&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp; Powered By<a href="http://www.emporiumtechnologyltd.com">Emporium Technology Ltd. </a></p>
      </div>
      <div class="col-md-6 text-right customfoot"> <a href="<?php echo base_url();?>bank_ui/privacy_policy" target="_blank">Privacy Policy</a> <a href="<?php echo base_url();?>bank_ui/terms_conditions" target="_blank">Terms & Conditions</a> </div>
    </div>
  </div>
</div>

<!--marguee  class="navbar-fixed-bottom"-->
<footer class="ftr_msg_cont">
  <div id="massage-bar" class="navbar-fixed-bottom">
    <div class="container">
      <div style="overflow:hidden"> <strong style="display:inline-block; color:#1076BC; width:100px; float:left">Policy News:</strong>
        <div id="features">
          <ul>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/15" target="_blank">Hackers tried to steal $951 million; $850 million was saved: Bangladesh</a></li>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/10" target="_blank"> Govt ‘considering’ fuel oil price review </a></li>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/13" target="_blank">Muhith hints budget for next fiscal will be around</a></li>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/9" target="_blank"> Bangladesh forex reserves hit a new high, top $28 billion</a></li>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/14" target="_blank">Bangladesh’s July-January FDI rises over 30 percent</a></li>
              <li><a href="http://www.policymarket.com.bd/bank_ui/news_details/9" target="_blank"> Bangladesh forex reserves hit a new high, top $28 billion</a></li>
          </ul>
        </div>
      </div>
      <!--<marquee  align='middle' behavior='scroll' direction='left' scrollamount='3' onmouseover='this.stop()' onmouseout='this.start();'>
        we provide an unbiased comparison between all the top bank service policy along with product reviews to help you decide
        </marquee>--> 
    </div>
  </div>
</footer>
</div>

<div id="popUpBoxWrap"></div>  
<div id="popUpBox">
 	<a class="close" href="#"></a>
<?php error_reporting(0); ?>
<div class="col-md-9">
  <section>
    <div class="container"> 
      <!-- Heading --> 
      
    </div>
    <div class="best-services"> 
    	<?php 
$to = "sahmed.emporium@gmail.com";
$subject = "This Mail from Policy Market";

$email= $_POST['email'];
$message ="Hi I am ".$_POST['name']. ". My email is ".$_POST['email']. ". My phone no is ".$_POST['phone']. ". I am a " .$_POST['profession']. ". I want a loan of ".$_POST['loan_expectation']. "Tk." ;
$from = "From: $email";

if($email =='' || $message==''){
	echo 'Please fill out all information for Loan';
}else{
	mail($to, $subject, $message, $from);
}

?>

<div class="page-header">
</div>

<form id="contact-form" action="?" method="post">
<link href="<?php echo base_url();?>front_assets/css/from.css" rel="stylesheet">
<script src="<?php echo base_url();?>front_assets/js/from.js"></script>
			<h3>Apply for Loan</h3>
			<h4>Fill in the form below, and we'll get back to you within 24 hours.</h4>
			<div>
			<label>
			<span>Full Name: (required)</span>
			<input placeholder="Please enter your full name" type="text" tabindex="1" name="name" required autofocus>
			</label>
			</div>
			<div>
			<label>
			<span>Email: (required)</span>
			<input placeholder="Please enter your email address" type="email" tabindex="2" name="email" required>
			</label>
			</div>
			<div>
			<label>
			<span>Phone: (required)</span>
			<input placeholder="Please enter your phone number" type="tel" tabindex="3" name="phone" required>
			</label>
			</div>
			<div>
			<label>
			<span>Profession: (required)</span>
			<input placeholder="Please enter your Profession" type="text" tabindex="4" name="profession" required>
			</label>
			</div>
                        <div>
			<label>
			<span>Loan Expectation: (required)</span>
			<input placeholder="Please enter your Loan Expectation" type="text" tabindex="5" name="loan_expectation" required>
			</label>
			</div>
			<div>
			<button name="submit" type="submit" id="contact-submit">Apply For Loan</button>
			</div>
		</form>

    </div>
  </section>
</div>


  </div>

<script src="<?php echo base_url();?>front_assets/js/jquery-1.11.0.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/bootstrap.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/own-menu.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.isotope.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.flexslider-min.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/owl.carousel.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.cubeportfolio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.colio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/main.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/featurify.js"></script> 
<script type="text/javascript">
	$("#features").featurify();
	
	//or if you want some options
	$("#sample3").featurify({
	 directionIn : -1, // left: -1 / right: 1. Direction from where will come the next slide 
	 directionOut: -1, // left: -1 / right: 1. Direction to where will go the current slide
	 pause:2000,       // time in milleseconds between each slide
	 transition:350    // time in milleseconds that will take the sliding effect
 });
</script>
<link href="<?php echo base_url();?>front_assets/fancybox/jquery.fancybox.css" rel="stylesheet">
<script src="<?php echo base_url();?>front_assets/fancybox/jquery.fancybox.js"></script>
<script src="<?php //echo base_url();?>front_assets/fancybox/jquery.fancybox.pack.js"></script>

<script src="<?php echo base_url();?>front_assets/js/myJs.js"></script>


<script type="text/javascript">
$(document).ready(function(){	
		$("#popUpBoxWrap").hide();
		$("#popUpBox").hide();
		$(".detailForLoan").click(function(){
				$("#popUpBoxWrap").show();
				$("#popUpBox").show();
			});
		$("#popUpBox .close").click(function(){
				$("#popUpBoxWrap").hide();
				$("#popUpBox").hide();
			});	
});
</script>
</body></html>