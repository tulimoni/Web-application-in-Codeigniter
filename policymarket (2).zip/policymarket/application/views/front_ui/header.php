<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url();?>front_assets/policy-market.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Policymarket | Bank loan | insurance, Payment gateway | remittance | non bank finance | loan Bangladesh | bank loan Bangladesh | loans Bangladesh | best loan rates | interest rates Bangladesh | bd bank | fixed deposit | dps | home loan| personal loan | car loan</title>

<meta name="keywords" content="Policymarket, Bank loan, insurance, Payment gateway, remittance, non bank finance, loan Bangladesh, bank loan Bangladesh, loans Bangladesh, best loan rates, interest rates Bangladesh, bd bank, fixed deposit, dps, home loan, personal loan, car loan">

<meta name="description" content="Compare and apply online for personal loans, Bank loan, home loan, fixed deposits, car loan, remittance, Payment gateway, insurance, non bank finance, dps, and interest rates in Bangladesh. Choose one according to your choice and capability. Find the best loan rates in Bangladesh.">

<meta name="author" content="Policymarket">

<link href="<?php echo base_url();?>front_assets/css/bootstrap.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo base_url();?>front_assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url();?>front_assets/css/ionicons.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/main.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/menu.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/responsive.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/common.css" />

<link rel="stylesheet" href="<?php echo base_url();?>front_assets/css/1.css">
<link href="<?php echo base_url();?>front_assets//css/2.css" rel="stylesheet">
<script src="<?php echo base_url();?>front_assets/js/1.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/2.js"></script>     
<script src="<?php echo base_url();?>front_assets/js/3.js"></script>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,700' rel='stylesheet' type='text/css' />
<script type="text/javascript" src="<?php echo base_url();?>front_assets/js/modernizr.custom.79639.js"></script>

<!-- Online Fonts -->
<link href='https://fonts.googleapis.com/css?family=Raleway:400,600,800,200,500' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600italic,400italic,300,300italic,600,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Libre+Baskerville:400italic,400,700' rel='stylesheet' type='text/css'>

<!-- COLORS -->
<link rel="stylesheet" id="color" href="<?php echo base_url();?>front_assets/css/colors/default.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<!-- JavaScripts -->

<script src="<?php echo base_url();?>front_assets/js/modernizr.js"></script>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body onload="hideDiv()">

<!-- Wrap -->
<div id="wrap">
<!-- header -->
<header> 
  <!-- Top bar -->
  <div class="top-bar">
    <div class="top-info">
      <div class="container">
        <ul class="personal-info">
          <li>
            <p><i class="fa fa-phone"></i>(+88 01842 POLICY)</p>
          </li>
          
          <li>
            <p><i class="fa fa-envelope"></i>info.policymarket@gmail.com</p>
          </li>
          <li>
              <p class="googleplay"><a href="https://play.google.com/store/apps/details?id=com.etl.rashid.policymarketapps" target="_blank"><img src="<?php echo base_url();?>front_assets/images/googleplay.png" alt=""></a></p>
          </li>
        </ul>
        
        <!-- Right Sec -->
        <div class="right-sec"> 
          
          <!-- social -->
          <ul class="social">
            <li><a href="https://www.facebook.com/Policymarket/" target="_blank"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/policy_market" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://plus.google.com/110651186448905530349" target="_blank"><i class="fa fa-google"></i></a></li>
            <li><a href="https://www.linkedin.com/company/policy-market" target="_blank"><i class="fa fa-linkedin"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Navigation -->
  <nav class="navbar">
    <div class="sticky">
      <div class="container"> 
        <!-- LOGO -->
        <div class="row">
          <div class="logo"> <a href="<?php echo base_url();?>"><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/logo.png" alt=""></a> </div>
          <!-- Nav -->
          
          <ul class="menuTemplate1 decor1_1" license="mylicense">
    <li><a href="<?php echo base_url();?>">HOME</a></li>
    
    <li><a href="<?php echo base_url();?>bank_ui/bank_show" class="arrow">BANK <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2" style="width: 375px;">
            <div class='left'>
                <b>Bank Menu</b>
                <div>
                    <a href="<?php echo base_url();?>bank_ui/deposit_info">Deposit Information</a><br />
                    <!-- <a href="<?php echo base_url();?>bank_ui/double_benefit"> Double Benefit Deposit Information</a><br /> -->
                    <a href="<?php echo base_url();?>bank_ui/loan_info">Loan Information</a><br />
                    <a href="<?php echo base_url();?>bank_ui/money_exchange">Money Exchange Rate</a><br />
                    <a href="<?php echo base_url();?>bank_ui/bank_search">Bank Information</a><br/>
                    <a href="<?php echo base_url();?>bank_ui/credit_card">Credit Card</a>
                </div>
            </div>
            <div class='left' style="text-align:right; width:200px;">
                <img src="<?php echo base_url();?>front_assets/images/bank.png" style="width:128px; height:128px;" />
            </div>
            <div style='clear: both;'></div>
        </div>
    </li>
  
  <li><a href="<?php echo base_url();?>insurance_ui/insurance_show" class="arrow">INSURANCE <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2" style="width: 375px;">
            <div class='left'>
                <b>Insurance Menu</b>
                <div>
                    <a href="<?php echo base_url();?>insurance_ui/diposit_search">Insurance Deposit</a><br />
                    <a href="<?php echo base_url();?>insurance_ui/insurance_search">Insurance Information</a>
                </div>
            </div>
            <div class='left' style="text-align:right; width:200px;">
                <img src="<?php echo base_url();?>front_assets/images/insurance.png" style="width:128px; height:128px;" />
            </div>
            <div style='clear: both;'></div>
        </div>
    </li>
  
  <li><a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_show" class="arrow">NON BANK FINANCE <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2" style="width: 420px;">
            <div class='left'>
                <b>Non Bank Finance Menu</b>
                <div>
                    <a href="<?php echo base_url();?>non_bank_finance_ui/deposit_info">Deposit Information</a><br />
                    <!-- <a href="<?php echo base_url();?>non_bank_finance_ui/loan_info">Loan Information</a><br /> -->
                    <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_search">Non Bank Finance Information</a>
                </div>
            </div>
            <div class='left' style="text-align:right; width:200px;">
                <img src="<?php echo base_url();?>front_assets/images/non_bank_finance.png" style="width:128px; height:128px;" />
            </div>
            <div style='clear: both;'></div>
        </div>
    </li>
  
  <li><a href="<?php echo base_url();?>bank_ui/remittance">REMITTANCE</a></li>
  
  <li><a href="#" class="arrow">PAYMENT GETAWAY <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2 dropToLeft" style="width: 440px;">
            <img src="<?php echo base_url();?>front_assets/images/payment.png" style="float:left; width:128px;height:128px;margin:10px 80px 10px 20px;" />
            <div class='left'>
                <b>Payment Getaway Menu</b>
                <div>
                    <a href="<?php echo base_url();?>bank_ui/payment_getway">International Payment Getaway</a><br/>
                    <a href="<?php echo base_url();?>bank_ui/mobile_banking">Bangladeshi Mobile Banking</a>
                </div>
            </div>
        </div>
    </li>
    
    <li><a href="<?php echo base_url();?>bank_ui/share_market" class="arrow">SHARE MARKET <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2 dropToLeft" style="width: 430px;">
            <img src="<?php echo base_url();?>front_assets/images/sharemarket.png" style="float:left; width:128px;height:128px;margin:10px 80px 10px 20px;" />
            <div class='left'>
                <b>Share Market Menu</b>
                <div>
                    <a href="<?php echo base_url();?>bank_ui/b_share_market">Bangladeshi Stock Exchange</a><br />
                    <a href="<?php echo base_url();?>bank_ui/i_share_market">International Stock Exchange</a><br/>
                    <a href="<?php echo base_url();?>bank_ui/brokerage_house">Brokerage House</a>
                </div>
            </div>
        </div>
    </li>
  
  <li><a href="#" class="arrow">ATM/Branch Locator <i class="fa fa-angle-down"></i></a>
        <div class="drop decor1_2 dropToLeft" style="width: 460px;">
            <img src="<?php echo base_url();?>front_assets/images/atm.png" style="float:left; width:128px;
                height:128px;margin:10px 80px 10px 20px;" />
            <div class='left'>
                <b>ATM/Branch Locator Menu</b>
                <div>
                    <a href="<?php echo base_url();?>bank_ui/bank_atm_locator">Bank ATM/Branch Locator</a><br />
          <a href="<?php echo base_url();?>insurance_ui/insurance_atm_locator">Insurance Branch Locator</a><br />
                    <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_atm_locator">Non Bank Finance Branch Locator</a>
                </div>
            </div>
        </div>
    </li>

    <li><a href="<?php echo base_url();?>bank_ui/jobs">JOBS</a></li>
</ul>
          <!-- Search --> 
          <!--<div class="search-icon"> <a href="#."><i class="fa fa-search"></i></a>
            <form>
              <input class="form-control" type="search" placeholder="Type Here">
              <button type="submit"><i class="fa fa-search"></i></button>
            </form>
          </div>--> 
        </div>
      </div>
    </div>
  </nav>
</header>

<section class="sub-bnr bnr-2" data-stellar-background-ratio="0.5">
  <div style="width: 1260px; margin:0 auto 20px">
        <a href="#">
        <img class="ShakeAndBorder" alt=""  src="<?php echo base_url();?>front_assets/images/banner/banner-1.png" />
        </a>
        
        <a href="#">
            <img class="ShakeAndBorder" alt="" src="<?php echo base_url();?>front_assets/images/banner/banner-2.png" />
        </a>
                
        <a href="#">
            <img class="ShakeAndBorder" alt="" src="<?php echo base_url();?>front_assets/images/banner/banner-3.png" />
        </a>
        <a href="#">
            <img class="ShakeAndBorder" alt=""  src="<?php echo base_url();?>front_assets/images/banner/banner-4.png" />
        </a>
        
        <a href="#">
            <img class="ShakeAndBorder" alt="" src="<?php echo base_url();?>front_assets/images/banner/banner-5.png" />
        </a>
                
        <a href="#">
            <img class="ShakeAndBorder" alt="" src="<?php echo base_url();?>front_assets/images/banner/banner-6.png" />
        </a>
        <a href="#">
            <img class="ShakeAndBorder" alt="" src="<?php echo base_url();?>front_assets/images/banner/banner-7.png" />
        </a>
        

      <script>
      $('.ShakeAndBorder').ShakeBorder();
      </script>
  </div>
  </section>

<div id="content">
<!-- Revenues -->
<section class="revenues padding-top-40 padding-bottom-40">
<div class="container">
<div class="row">