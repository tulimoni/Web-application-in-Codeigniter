<?php error_reporting(0); ?>
<div class="col-md-9">
   <div class="from_dempsit_wrap">
       <div class="contact-form">
          <h6>Choose Your Preferred Amount</h6>
          <!-- Success Msg -->
          <div id="contact_message" class="success-msg"> <i class="fa fa-paper-plane-o"></i>Thank You. Your Message has been Submitted</div>
          
          <!-- FORM -->

          <form role="form" method="post" action="<?php echo base_url();?>insurance_ui/compare">
            <table>
               <tr>
                <td> Amount
            <select name="installment_amount">
              <option value="500" >500</option>
              <option value="1000">1000</option>
              <option value="2000" >2000</option>
              <option value="3000">3000</option>
              <option value="5000">5000</option>
              <option value="10000" >10000</option>
              <option value="15000">15000</option>
              <option value="20000">20000</option>
              <option value="25000" >25000</option>
              <option value="50000">50000</option>
            </select>
                 </td>
          
              <td> Type
        <select name="installment_type" >
          <option value="Monthly" <?php if($_SESSION['installment_type'] == Monthly) echo 'selected'; ?>>Monthly</option>
          <option value="Yearly" <?php if($_SESSION['installment_type'] == Yearly) echo 'selected'; ?>>Yearly</option>
        </select></td>
      <?php
        $option='';
        
       for($i='';$i<=20;$i++) {
          
             $option .= '<option value = "'.$i.'">'.$i.'</option>'; 
            }
             ?>
      <td>Year <select class="easyui-combobox" name="deposit_year"  value="<?php echo $_SESSION['deposit_year'];?>" />
        <option value="">Select Year</option>
        <?php echo $option; ?>
        </select></td>
              </tr>
            </table> 
        </div>
        
    </div>    
    <link href="<?php echo base_url();?>front_assets/css/TableCSSCode.css" rel="stylesheet">

    <center><h5>Compare Bank with Another Bank</h5></center>
            <div class="CSSTableGenerator2 comparebtn" >
        <table>
          <tr>
            <td> Bank Name</td>
            <td > 
        <select name="insurance_name1" >
          <option value="">Select Bank</option>
          <?php
           foreach ($insurance_name as $insurance) 
                {
                ?>
          <option value="<?php echo $insurance->insurance_id;?>"><?php echo $insurance->insurance_name;?></option>
                <?php } ?>
        </select>
        <button class="btn" type="submit" value="submit">Quest</button> </td>
            <td> 
        <select name="insurance_name2">
          <option value="">Select Bank</option>
          <?php
           foreach ($insurance_name as $insurance) 
                {                  
                ?>
          <option value="<?php echo $insurance->insurance_id;?>"><?php echo $insurance->insurance_name;?></option>
          <?php } ?>
        </select>
        <button class="btn" type="submit" value="submit">Quest</button> </td>
            <td > 
        <select name="insurance_name3" >
          <option value="">Select Bank</option>
          <?php
           foreach ($insurance_name as $insurance) 
                {
                ?>
          <option value="<?php echo $insurance->insurance_id;?>"><?php echo $insurance->insurance_name;?></option>
                <?php } ?>
        </select>
        <button class="btn" type="submit" value="submit">Quest</button> </td>
          </tr>
          <tr>
            <td >Bank</td>
            <td> <?php echo $this->session->userdata('insurance_name1')?> </td>
            <td> <?php echo $this->session->userdata('insurance_name2')?> </td>
            <td> <?php echo $this->session->userdata('insurance_name3')?> </td>
          </tr>
          <tr>
            <td >Deposit Name</td>
            <td> <?php echo $this->session->userdata('diposit_name1'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_name2'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_name3'); ?> </td>
          </tr>
          <tr>
            <td >Type</td>
            <td> <?php echo $this->session->userdata('diposit_type1'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_type2'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_type3'); ?> </td>
          </tr>
          <tr>
            <td >Duration</td>
            <td> <?php echo $this->session->userdata('diposit_duration1'); ?> Years </td>
            <td> <?php echo $this->session->userdata('diposit_duration2'); ?> Years</td>
            <td> <?php echo $this->session->userdata('diposit_duration3'); ?> Years</td>
          </tr>
          <tr>
            <td >Deposit</td>
            <td>TK <?php echo $this->session->userdata('diposit_amount1'); ?>/-  </td>
            <td>TK <?php echo $this->session->userdata('diposit_amount2'); ?>/-  </td>
            <td>TK <?php echo $this->session->userdata('diposit_amount3'); ?>/-  </td>
          </tr>
          <tr>
            <td >Interest</td>
            <td> <?php echo $this->session->userdata('diposit_interest_rate1'); ?>% </td>
            <td> <?php echo $this->session->userdata('diposit_interest_rate2'); ?>% </td>
            <td> <?php echo $this->session->userdata('diposit_interest_rate3'); ?>% </td>
          </tr>
          <tr>
            <td >Monthly</td>
            <td> <?php echo $this->session->userdata('diposit_monthy_benefit1'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_monthy_benefit2'); ?> </td>
            <td> <?php echo $this->session->userdata('diposit_monthy_benefit3'); ?> </td>
          </tr>
          <tr>
            <td >Final Return</td>
            <td>TK <?php echo $this->session->userdata('final_amount1'); ?>/-  </td>
            <td>TK <?php echo $this->session->userdata('final_amount2'); ?>/-  </td>
            <td>TK <?php echo $this->session->userdata('final_amount3'); ?>/-  </td>
          </tr>
        </table>
        </form>
      </div>
            
            </div>
           </div>
         </div>
       </div>
      </div>
    </div>
    </section>
  