<div class="col-md-9">
  <section class="services padding-bottom-70">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/style6.css" />
    <section class="main">
      
        <ul class="ch-grid">
          <li>
            <div class="ch-item ch-img-1">        
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-1"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>insurance_ui/diposit_search"><h3>Deposit</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>insurance_ui/diposit_search"> View on Details</p></a>
                  </div>  
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-2">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-2"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>insurance_ui/insurance_search"><h3>Insurance Information</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>insurance_ui/insurance_search"> View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
        
      </section>
  </section>
</div>
