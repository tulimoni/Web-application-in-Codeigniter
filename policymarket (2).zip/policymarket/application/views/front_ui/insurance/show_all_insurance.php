<?php error_reporting(0);?>
  <div class="col-md-12">
    <section class="services padding-bottom-70">
    <div class="contact-form">
     <div class="newfrom">
          <!--<h5 >Search Insurance By Category</h5>-->
          <!-- Success Msg -->
         <?php if($message)
		 {?>
		 <font color="#FF0000"; style="margin-left:200px;">
		<?php echo $message;
		 }
	?>
		 </font>
          <!-- FORM
		   <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
          <form  method="post" action="<?php echo base_url();?>insurance_ui/insurance_search_by_cat">
            <table>
               <tr>
			  <select name="insurance_cat" class="input-sm" style="margin-right:10px">
                    <option>Select Insurance Category</option>
                    <?php
                   foreach ($all_cat as $cat) 
                        {
                        
                                            
                        ?>
                    <option value="<?php echo $cat->insurance_category_id; ?>"><?php echo $cat->insurance_category_name; ?></option>
                    <?php } ?>
                </select>
			  <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Start <i class="fa fa-caret-right"></i></button>
              </tr>
            </table>
          </form>
         </div>
      
		<link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
    <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">
    <div class="newtext"><center><strong>Insurance List</strong></center></div>
                <section class="padding-bottom-10">
                </section>
			<div class="tablenn">
        <div class="tablebiinformation">
        <div class="bank_logo_area_for_table">
                <table >

                    <thead>
  <tr>
    <th style="padding:5px">Insurance</th>
    <th style="padding:5px">Category</th>
    <th style="padding:5px">Head Office Address</th>
    <th style="padding:5px" width="20%">Head Office Phone Number</th>
    <th style="padding:5px" width="10%">Details View</th>
  </tr>
  </thead>
					<?php foreach ($all_insurance as $row) {
					?>
                    <tr>
                    <td >
                        <?php   $a=$row->insurance_logo;?>
                        <img src="<?php echo base_url().$a?>" height="60px" width="120px" /></br>
                        <div class="newfont"><?php echo $row->insurance_name;?></div>
                        </td>
                        <td><?php echo $row->insurance_category_name;?></td>
                        <td><?php echo $row->insurance_office_address;?></td>
                        <td><?php echo $row->insurance_phone_number;?></td>
			<td><a href="<?php echo $row->insurance_website_url;?>" target="_blank">Details</a></td>
                    </tr>
                   <?php }?>
                </table>
            </div>
	   </div>
	   </div>
	   </div>
        </div>
      </div>
      </div>
    </section>
	