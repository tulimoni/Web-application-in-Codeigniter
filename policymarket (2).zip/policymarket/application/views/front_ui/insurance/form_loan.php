  <?php error_reporting(0);?>
  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <h6>Search Your Preferred Loan Policy</h6>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
          <!-- FORM
       <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
          <form  method="post" action="<?php echo base_url();?>insurance_ui/check_loan">
           <table>
           <tr>
           <td>
        <select name="insurance_loan_id">
                <option>Select Category</option>
                <?php
               foreach ($all_loan as $loan) 
                    {
                    
                                        
                    ?>
                <option value="<?php echo $loan->insurance_loan_category_id; ?>"><?php echo $loan->insurance_loan_category_name; ?></option>
                <?php } ?>
            </select>
            </td>
       <td>
        <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Quest <i class="fa fa-caret-right"></i></button>
               
        </td>
              </tr>
            </table>
          </form>
      
  <link href="<?php echo base_url();?>front_assets/css/TableCSSCode.css" rel="stylesheet">

  <center><h5>Compare Your Preferred Loan Policy</h5></center>
      <div class="CSSTableGenerator" >
      <table>
    <tr>
            <td> Bank </td>
            <td> Loan Name </td>
            <td> Loan Duration </td>
            <td> Interest Rate </td>
            <td> Loan Range </td>
            <td> Monthly Installment </td>
            <td> Processing Fees </td>
            <td> Details </td>
            <td width="10%"><a href="javascript:void(0)" onClick="compare();" > <b>Compare</b></a></td>
          </tr>
<?php
foreach ($default_loan_deposit as $loan_deposit) {
          ?>
          
           <tr>
  
            <td >
            <?php   $a=$loan_deposit->insurance_logo;?>
            <img src="<?php echo base_url().$a?>" height="70px" width="100px" />
            <?php   echo '<br>';echo $loan_deposit->insurance_name; ?>
            </td>         
            <td><?php echo $loan_deposit->insurance_loan_name;?></td>
            <td><?php echo $loan_deposit->insurance_loan_duration;?></td>
            <td><?php echo $loan_deposit->insurance_loan_interest_rate;?>%</td>
            <td>TK <?php echo $loan_deposit->insurance_loan_range;?></td>
            <td>TK <?php echo $loan_deposit->monthly_installment;?></td>
            <td><?php echo $loan_deposit->insurance_loan_processing_fees;?></td>
            <td><?php $ab=$row->insurance_loan_id; ?>
            <a href="javascript:void(0);" class="detail" id="<?php echo $ab; ?>">Details</a>
            </td>
        <td>
          
<input type="checkbox" name="products[]" class="products" id="<?php echo $default->insurance_diposit_id; ?>"> 
</td>
</tr>
  
  <?php
  }?>
  </table>
    </div>
     </div>
      </div>
   </div>

  

      


	   
	

			