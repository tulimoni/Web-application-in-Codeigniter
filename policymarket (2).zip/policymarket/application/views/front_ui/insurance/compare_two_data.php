<?php
$con = @mysql_connect('localhost','policyma_nsr','$EMP#P16!2016pSSxPlc');
if (!$con) {
	die('Could not connect: ' . mysql_error());
}
$a = mysql_query("CREATE DATABASE IF NOT EXISTS policyma_ndb");
if (!$a) {
    echo "error creating database";
} else {
    echo " ";
}

mysql_select_db('policyma_ndb', $con);


$type = trim($_REQUEST['type']);
$res ='';
$res="<table cellspacing='2' cellpadding='0' align='left' width='200'>
<tr><th align='left'><strong>Bank Attributes<hr></strong></th></tr>
<tr height='75' align='center'><td align='left'>&nbsp;</td></tr>
<tr height='40' align='center'><td align='left'>Company Name</td></tr>
<tr height='40' align='center'><td align='left'> Deposit Name</td></tr>
<tr height='40' align='center'><td align='left'> Dposit type</td></tr>
<tr height='40' align='center'><td align='left'>Interest Rate</td></tr>
<tr height='40' align='center'><td align='left'>Monthly Instalment</td></tr>
<tr height='40' align='center'><td align='left'>Year</td></tr>
<tr height='40' align='center'><td align='left'>Maturity Amount</td></tr>
<tr height='40' align='center'><td align='left'>Features</td></tr>
<tr height='40' align='center'><td align='left'>Monthly Benifit</td></tr>
</table>";
if($type=='detail')
{
$pid = $_REQUEST['p_id'];
$id = $pid;
$sql = mysql_query("SELECT * FROM tbl_insurance_diposit,tbl_insurance_name where tbl_insurance_diposit.insurance_id=tbl_insurance_name.insurance_id  and insurance_diposit_id=$id") OR die(mysql_error());

$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Bank Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           
                <img src=".base_url().$data['insurance_logo']." width='110px' height='45px'>
         
        </td>
</tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_interest_rate']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_type']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_amount']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_duration']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['final_amount']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_feature']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_monthy_benefit']."</td></tr>";
$res .= "</table>";
}

else if($type=='compare')
{
$Totalpids = (array)json_decode(stripslashes($_REQUEST['pids']));
foreach($Totalpids as $product)
{
$r=$product->pid;


$sql = mysql_query("SELECT * FROM tbl_insurance_diposit,tbl_insurance_name where tbl_insurance_diposit.insurance_id=tbl_insurance_name.insurance_id and insurance_diposit_id=".$product->pid."");
$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Deposit Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           <img src=".base_url().$data['insurance_logo']." width='110px' height='45px'>      
        </td>
		</tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_interest_rate']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_type']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_amount']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_duration']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['final_amount']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_feature']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['diposit_monthy_benefit']."</td></tr>";
$res .= "</table>";

}
}
echo $res;
?>