 <?php error_reporting(0);?>
<script type="text/javascript">
$(document).ready(function(){             
        $(".detail").click(function(){ 
        var p_id = $(this).attr('id');
        if(p_id!='')
        { 
         $.ajax({
                type:"post",
        
                url: '<?= base_url()."insurance_ui/check_compaire"?>',
                data:{p_id:p_id,type:'detail'},
                cache: false,
                success:function(data){
                $.fancybox(data, {
                        fitToView: false,
                        width: 700,
                        height: 700,
                        autoSize: true,
                        closeClick: false,
                        openEffect: 'none',
                        closeEffect: 'refresh'
                        });     
                                
                        }
           });
        }
        });
});

function compare()
{
        var total_check = new Array();
        $('.products:checked').each(function () {
                total_check.push($(this).val());
        });

        if (total_check != '') {
                if (total_check.length == '2') {
                var i = 0;
                var pidArray = new Object();
                $('.products:checked').each(function () {
                total_check.push($(this).val());
                var id = $(this).attr('id');
                pidArray[i] = {
                        pid: id
                };
                i++;
        });
        var data = JSON.stringify(pidArray);
        $('#wait').show();
        $.ajax({
                url: '<?= base_url()."insurance_ui/check_compaire"?>',
                type: "POST",
                data: {pids:data,type:'compare'},
                cache: false,
                success: function (data) {
                $('#wait').hide();
                        $.fancybox(data, {
                                fitToView: false,
                                width: 700,
                                height: 500,
                                autoSize: false,
                                closeClick: false,
                                openEffect: 'none',
                                closeEffect: 'refresh'
                        });
                }
        });
                } else {
                alert("Please select two Insurances ");
                return false;
                }
        } else {
                alert("Please select minimum two Insurances");
                return false;
        }
}
</script>
  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <!--<h5 >Choose Your Preferred Deposit Policy</h5>-->
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
          <!-- FORM
       <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
          <form class="common_fact"  method="post" action="<?php echo base_url();?>insurance_ui/check_diposit_info">
           <table>
              <tr>
        
             <td> 
                 <select name="installment_amount" id="installment_amount_insurance" onchange="javascript:deposit_for_insurance();">
                  <option> Select Installment Amount</option>
                  <?php
            foreach ($all_insurance_deposit as $insurance_deposit) 
            {                   
            ?>
            <option value="<?php echo $insurance_deposit->diposit_amount;?>"><?php echo $insurance_deposit->diposit_amount;?></option>
            <?php } ?>


                 </select>
             </td>
                 
             <td>
            <select name="installment_name" onchange="javascript:year_for_insurance();" id="installmentForinsurance"  required>
            
              <option>Select Deposit Name</option>
              <?php
            foreach ($all_insurance_deposit_name as $insurance_deposit_name) 
            {                   
            ?>
            <option value="<?php echo $insurance_deposit_name->diposit_name;?>"><?php echo $insurance_deposit_name->diposit_name;?></option>
            <?php } ?>
          </select>
             </td>
              
              <td>
            <select id="yearForinsurance" onchange="javascript:year_for_bank();"  name="deposit_year" required>
              <option>Select Year</option>
              <?php
            foreach ($all_insurance_deposit_duration as $insurance_deposit_duration) 
            {                   
            ?>
            <option value="<?php echo $insurance_deposit_duration->diposit_duration;?>"><?php echo $insurance_deposit_duration->diposit_duration;?></option>
            <?php } ?>
          </select>
             </td>
                  
              
               <td>
            <button type="submit" value="submit" class="btn btn-1" id="btn_submit_2" onClick="proceed();">Quest <i class="fa fa-caret-right"></i></button>
        </td>
             
              </tr>
            </table>
          </form>
      
  <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
  <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">
  <!--<center><h5>Compare Your Preferred Deposit Policy</h5></center>-->
     <div class="tablenn">
       <div class="tablebideposit">
        <div class="bank_logo_area_for_table">
  <table>
   <thead>
    <tr>
        <th style="padding:5px">Insurance</th>
        <!--<th style="padding:5px">Deposit Name</th>-->
        <th style="padding:5px">Interest Rate(%)</th>
        <!--<th style="padding:5px">Installment Type</th>
        <th style="padding:5px">Installment</th>
        <th style="padding:5px">Year</th>-->
        <th style="padding:5px">Maturity Amount(BDT)</th>
        <th style="padding:5px">Monthly Benefit(BDT)</th>
        <th style="padding:5px">Details</th>
        <th width="12%">Compare</th>
   </tr>
  </thead>
<?php
foreach ($default_deposit as $default) {
          ?>
          
            <tr>
                        <td >
                         <?php   $a=$default->insurance_logo;?>
<img src="<?php echo base_url().$a?>" height="70px" width="100px" />
<?php   echo '<br>';echo $default->insurance_name; ?>
                        </td>
                       
        <!--<td><?php echo $default->diposit_name;?></td>-->
        <td><strong><?php echo $default->diposit_interest_rate;?></strong></td>
        <!--<td><?php echo $default->diposit_type;?></td>
        <td>TK <?php echo $default->diposit_amount;?>/-</td>
        <td><?php echo $default->diposit_duration;?> Years</td>-->
        <td><strong><?php echo $default->final_amount;?></strong></td>
        <td><strong><?php echo $default->diposit_monthy_benefit;?></strong></td>
        <td><?php $ab=$default->insurance_diposit_id; ?>
            <a href="javascript:void(0);" class="detail" id="<?php echo $ab; ?>">Details</a>
            </td>
        <td><input type="checkbox" name="products[]" class="products" id="<?php echo $default->insurance_diposit_id; ?>"> 
            <a href="javascript:void(0)" onClick="compare();"><button class="btn btn-sm btn-success">Compare</button></a>
        </td>
</tr>
  
  <?php
  }?>
  </table>
    </div>
     </div>
      </div>
       </div> 
        </div>
         </div>     