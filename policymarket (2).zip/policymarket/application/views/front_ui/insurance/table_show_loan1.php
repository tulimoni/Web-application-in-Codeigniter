﻿<?php error_reporting(0); ?>

<!-----------------------------Loan Part--------------------------------->

<script type="text/javascript">
$(document).ready(function(){             
        $(".detail").click(function(){ 
        var p_id = $(this).attr('id');
        if(p_id!='')
        { 
         $.ajax({
                type:"post",
				
                url: '<?= base_url()."insurance_ui/check_compaire_insurance_loan" ?>',
                data:{p_id:p_id,type:'detail'},
                cache: false,
                success:function(data){
                $.fancybox(data, {
                        fitToView: false,
                        width: 700,
                        height: 700,
                        autoSize: true,
                        closeClick: false,
                        openEffect: 'none',
                        closeEffect: 'refresh'
                        });     
                                
                        }
           });
        }
        });
});

function compare()
{
        var total_check = new Array();
        $('.products:checked').each(function () {
                total_check.push($(this).val());
        });

        if (total_check != '') {
                if (total_check.length == '2') {
                var i = 0;
                var pidArray = new Object();
                $('.products:checked').each(function () {
                total_check.push($(this).val());
                var id = $(this).attr('id');
                pidArray[i] = {
                        pid: id
                };
                i++;
        });
        var data = JSON.stringify(pidArray);
        $('#wait').show();
        $.ajax({
                url: '<?= base_url()."insurance_ui/check_compaire_insurance_loan"?>',
                type: "POST",
                data: {pids:data,type:'compare'},
                cache: false,
                success: function (data) {
                $('#wait').hide();
                        $.fancybox(data, {
                                fitToView: false,
                                width: 700,
                                height: 500,
                                autoSize: false,
                                closeClick: false,
                                openEffect: 'none',
                                closeEffect: 'refresh'
                        });
                }
        });
                } else {
                alert("Please select two Banks ");
                return false;
                }
        } else {
                alert("Please select minimum two Banks");
                return false;
        }
}
</script>

<div class="col-md-9">
  <div class="from_dempsit_wrap">
    <div class="contact-form">
      <?php if($message)
		 {?>
      <font color="#FF0000"; style="margin-left:200px;"> <?php echo $message;
		 }
	?> </font> 
      <!-- FORM
		   <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
      <form  class="common_fact"  method="post" action="<?php echo base_url();?>insurance_ui/check_loan">
        <table>
          <tr>

          <h6>Choose Your Preferred Loan Policy</h6>
          <!-- Success Msg -->
          <?php if($message)
          {?>
          <font color="#FF0000"; style="margin-left:200px;">
          <?php echo $message;
            }
          ?>
            <td><select name="insurance_loan_id">
                <option>Select Category</option>
                <?php
           foreach ($all_loan as $loan) 
                {
                  
                ?>
                <option value="<?php echo $loan->insurance_loan_category_id;?>"><?php echo $loan->insurance_loan_category_name;?></option>
                <?php } ?>
              </select></td>
            <td><button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Quest <i class="fa fa-caret-right"></i></button></td>
          </tr>
        </table>
      </form>
      <link href="<?php echo base_url();?>front_assets/css/TableCSSCode.css" rel="stylesheet">
      
      <center><h5>Compare Your Preferred Loan Policy</h5></center>
      <div class="CSSTableGenerator">
        
        <table>
          <tr>
            <td width="10%"><a href="javascript:void(0)" onClick="compare();" > <b>Compare</b></a></td>
            <td> Bank </td>
            <td > Loan Name </td>
            <td> Loan Duration </td>
            <td > Interest Rate </td>
            <td> Loan Range </td>
            <td> Monthly Installment </td>
            <td> Processing Fees </td>
            <td> Details </td>
          </tr>
          <?php foreach ($results as $row) {
					?>
          <tr>
            <td><input type="checkbox" name="products[]" class="products" id="<?php echo $row->insurance_loan_id; ?>"></td>
            <td ><?php   $a=$row->insurance_logo;?>
                <img src="<?php echo base_url().$a?>" height="70px" width="100px" />
                <?php   echo '<br>';echo $row->insurance_name; ?></td>
            <td><?php echo $row->insurance_loan_name; ?></td>
            <td><?php echo $row->insurance_loan_duration; ?>Years</td>
            <td><?php echo $row->insurance_loan_interest_rate; ?>%</td>
            <td>TK <?php echo $row->insurance_loan_range; ?></td>
            <td>TK <?php echo $row->monthly_installment; ?></td>
            <td><?php echo $row->insurance_loan_processing_fees;?></td>
            <td><?php $ab=$row->insurance_loan_id; ?>
              <a href="javascript:void(0);" class="detail" id="<?php echo $ab; ?>">Details</a></td>
          </tr>
          <?php } ?>
        </table>
      </div>

<!----------------------------------------------------------End Of Loan Part------------------------------------> 

