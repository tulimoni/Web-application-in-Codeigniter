  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <div class="newtext"><center><strong><u>Select Your Preferred Insurance</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_insurance_branch as $insurance_info_branch) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $insurance_info_branch->insurance_atm_url; ?>" target="bankatm">
            <img src="<?php echo base_url().$insurance_info_branch->insurance_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <iframe src= "http://www.agraniins.com/index.php/2012-03-14-03-24-50/branches" name="bankatm" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" >
        </iframe>

     </div>
      </div>
   </div>

  

      


       
    

            
  

      

