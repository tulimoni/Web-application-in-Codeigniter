<?php
$con = @mysql_connect('localhost','policyma_nsr','$EMP#P16!2016pSSxPlc');
if (!$con) {
	die('Could not connect: ' . mysql_error());
}
$a = mysql_query("CREATE DATABASE IF NOT EXISTS policyma_ndb");
if (!$a) {
    echo "error creating database";
} else {
    echo " ";
}

mysql_select_db('policyma_ndb', $con);


$type = trim($_REQUEST['type']);
$res ='';
$res="<table cellspacing='2' cellpadding='0' align='left' width='200'>
<tr><th align='left'><strong>Loan Attributes<hr></strong></th></tr>
<tr height='75' align='center'><td align='left'>&nbsp;</td></tr>
<tr height='40' align='center'><td align='left'>Bank Name</td></tr>
<tr height='40' align='center'><td align='left'> Loan Name</td></tr>
<tr height='40' align='center'><td align='left'> Loan Duration</td></tr>
<tr height='40' align='center'><td align='left'>Interest Rate</td></tr>
<tr height='40' align='center'><td align='left'Loan Range</td></tr>
<tr height='40' align='center'><td align='left'>Monthly Installment</td></tr>
<tr height='40' align='center'><td align='left'> Processing Fees</td></tr>
<tr height='40' align='center'><td align='left'>Maximum Term Loan</td></tr>
<tr height='40' align='center'><td align='left'>Customer Segment</td></tr>
<tr height='40' align='center'><td align='left'>Eligibility</td></tr>
</table>";
if($type=='detail')
{
$pid = $_REQUEST['p_id'];
$id = $pid;
$sql = mysql_query("SELECT * FROM tbl_insurance_loan_info,tbl_insurance_name,tbl_insurance_loan_category
 where tbl_insurance_loan_category.insurance_loan_category_id=tbl_insurance_loan_info.insurance_loan_category_id
  and tbl_insurance_loan_info.insurance_id=tbl_insurance_name.insurance_id 
   and insurance_loan_id=$id") OR die(mysql_error());

$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Bank Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           
                <img src=".base_url().$data['insurance_logo']." width='75px' height='75px'>
         
        </td>
</tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_duration']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_interest_rate']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_range']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['monthly_installment']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_processing_fees']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['maximum_term_insurance_loan']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['customer_segment']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['eligibility']."</td></tr>";
$res .= "</table>";
}

else if($type=='compare')
{
$Totalpids = (array)json_decode(stripslashes($_REQUEST['pids']));
foreach($Totalpids as $product)
{
$r=$product->pid;


$sql = mysql_query("SELECT * FROM tbl_insurance_loan_info,tbl_insurance_name,tbl_insurance_loan_category
 where tbl_insurance_loan_category.insurance_loan_category_id=tbl_insurance_loan_info.insurance_loan_category_id
  and tbl_insurance_loan_info.insurance_id=tbl_insurance_name.insurance_id  and insurance_loan_id=".$product->pid."");
$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Diposit Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           <img src=".base_url().$data['insurance_logo']." width='75px' height='75px'>      
        </td>
	</tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_duration']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_interest_rate']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_range']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['monthly_installment']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['insurance_loan_processing_fees']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['maximum_term_insurance_loan']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['customer_segment']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['eligibility']."</td></tr>";
$res .= "</table>";

}
}
echo $res;
?>