  <?php error_reporting(0);?>
  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
          <!-- FORM
       <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
          <form class="common_fact" method="post" action="<?php echo base_url();?>non_bank_finance_ui/check_loan">
           <table>
           <tr>
           <td>
        <select name="non_bank_finance_loan_id">
                <option>Select Category</option>
                <?php
               foreach ($all_loan as $loan) 
                    {
                    
                                        
                    ?>
                <option value="<?php echo $loan->non_bank_finance_loan_category_id; ?>"><?php echo $loan->non_bank_finance_loan_category_name; ?></option>
                <?php } ?>
            </select>
            </td>
       <td>
        <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Quest <i class="fa fa-caret-right"></i></button>
               
        </td>
              </tr>
            </table>
          </form>
      
  <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

  <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
        <div class="tablenbfloan">
        <div class="bank_logo_area_for_table">
      <table>

<thead>
   <tr>
    <th style="padding:5px" width="14%">Non Bank Finance</th>
    <th style="padding:5px" width="12%">Loan Duration</th>
    <th style="padding:5px" width="12%">Interest Rate(%)</th>
    <th style="padding:5px" width="14%">Loan Range(BDT)</th>
    <th style="padding:5px" width="18%">Monthly Installment(BDT)</th>
    <th style="padding:5px" width="16%">Processing Fees(BDT)</th>
    <th style="padding:5px">Apply</th>
    <th width="12%">Compare</th>
  </tr>
  </thead>

<?php
foreach ($default_loan_deposit as $loan_deposit) {
          ?>
          
           <tr>
  
            <td >
            <?php   $a=$loan_deposit->non_bank_finance_logo;?>
            <img src="<?php echo base_url().$a?>" height="70px" width="100px" />
            <?php   echo '<br>';echo $loan_deposit->non_bank_finance_name; ?>
            </td>
            <td><strong><?php echo $loan_deposit->non_bank_finance_loan_duration;?> Years</strong></td>
            <td><strong><?php echo $loan_deposit->non_bank_finance_loan_interest_rate;?>%</strong></td>
            <td><strong><?php echo $loan_deposit->non_bank_finance_loan_range;?></strong></td>
            <td><strong><?php echo $loan_deposit->monthly_installment;?></strong></td>
            <td><strong><?php echo $loan_deposit->non_bank_finance_loan_processing_fees;?></strong></td>
            <td><?php $ab=$row->non_bank_finance_loan_id;?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
                <button class="btn btn-sm btn-success" >APPLY</button></a></td>
            <td><input type="checkbox" name="products[]" class="products" id="<?php echo $default->non_bank_finance_diposit_id; ?>">
            <a href="javascript:void(0)" onClick="compare();" ><button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
            </tr>
  
  <?php
  }?>
  </table>
    </div>
     </div>
      </div>
   </div>
   </div>
   </div>
  

      


	   
	

			