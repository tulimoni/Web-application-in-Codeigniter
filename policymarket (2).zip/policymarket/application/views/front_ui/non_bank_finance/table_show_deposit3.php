﻿
<script type="text/javascript">
$(document).ready(function(){             
        $(".detail").click(function(){ 
        var p_id = $(this).attr('id');
        if(p_id!='')
        { 
         $.ajax({
                type:"post",
				
                url: '<?= base_url()."non_bank_finance_ui/check_compaire"?>',
                data:{p_id:p_id,type:'detail'},
                cache: false,
                success:function(data){
                $.fancybox(data, {
                        fitToView: false,
                        width: 700,
                        height: 700,
                        autoSize: true,
                        closeClick: false,
                        openEffect: 'none',
                        closeEffect: 'refresh'
                        });     
                                
                        }
           });
        }
        });
});

function compare()
{
        var total_check = new Array();
        $('.products:checked').each(function () {
                total_check.push($(this).val());
        });

        if (total_check != '') {
                if (total_check.length == '2') {
                var i = 0;
                var pidArray = new Object();
                $('.products:checked').each(function () {
                total_check.push($(this).val());
                var id = $(this).attr('id');
                pidArray[i] = {
                        pid: id
                };
                i++;
        });
        var data = JSON.stringify(pidArray);
        $('#wait').show();
        $.ajax({
                url: '<?= base_url()."non_bank_finance_ui/check_compaire"?>',
                type: "POST",
                data: {pids:data,type:'compare'},
                cache: false,
                success: function (data) {
                $('#wait').hide();
                        $.fancybox(data, {
                                fitToView: false,
                                width: 700,
                                height: 500,
                                autoSize: false,
                                closeClick: false,
                                openEffect: 'none',
                                closeEffect: 'refresh'
                        });
                }
        });
                } else {
                alert("Please select two Non Bank finances ");
                return false;
                }
        } else {
                alert("Please select minimum two Non Bank finances");
                return false;
        }
}
</script>
 <div class="col-md-9">
 
    <div class="contact-form">
	
	
	 <form  method="post" action="<?php echo base_url();?>non_bank_finance_ui/check_diposit_info" style="width:600px;">
           <table>
             
              <tr>
			  <td> Installment amount</td>
                 <td> <input type="text" class="form-control" name="installment_amount" id="installment_amount" placeholder="Installment amount">
				 </td></tr>
               
             
               <tr>
			   <td>Installment Type</td>
			   <td>
                  <select name="installment_type">
                    <option value="Monthly" >Monthly</option>
                    <option value="Yearly">Yearly</option>
                  </select>
               </td></tr>
                   <?php
				$option='';
			  
			 for($i='';$i<=20;$i++) {
					
						 $option .= '<option value = "'.$i.'">'.$i.'</option>';	
						}
						 ?>
						<tr><td>Year</td>
						<td>
							 <select class="easyui-combobox" name="deposit_year"> 
							<?php echo $option; ?>
							</select>
              </td></tr>
             <tr>
			 <td></td>
			 <td>
			  <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Quest <i class="fa fa-caret-right"></i></button>
               
				</td>
              </tr>
            </table>
          </form>
	
	
	
	
	
	
	
	
	
	
	
	
	<link href="<?php echo base_url();?>front_assets/css/TableCSSCode.css" rel="stylesheet">
<div class="CSSTableGenerator" >
<table  id="table1" class="table table-hover col-sm-12">



<tr>

 <td>
                          Non Bank finance
                        </td>
                        <td >
                            Deposit Name
                        </td>
						<td>
						Interest Rate
						</td>
						<td >
                           Instalment Type
                        </td>
                        <td>
                          Instalment
                        </td>
                        <td>
						Year
						</td> 
                        <td>
                           Maturity Amount
                        </td>
						<td>
						Features
						</td>
						<td>
						Monthly Benifit
						</td>
						<td>
						Details
						</td>
						<td width="10%">

     <a href="javascript:void(0)" onClick="compare();" style="color:green;font-size:15px;">
        <b>Select to Compare</b></a>
</td>
</tr><?php foreach ($results as $row) {
					?>
                    <tr>
					
					

                        <td >
                         <?php   $a=$row->non_bank_finance_logo;?>
<img src="<?php echo base_url().$a?>" height="70px" width="100px" />
<?php   echo '<br>';
   echo $row->non_bank_finance_name; 
  ?>
                        </td>
                       
						 <td>
                         <?php echo $row->diposit_name;?>
                        </td>
                        <td>
                           <?php echo $row->diposit_interest_rate.'%';?>
                        </td>
                        <td>
						 <?php echo $row->diposit_type;?>
                           
                        </td>
                        <td>
                         <?php echo $row->diposit_amount;?>
                        </td>
						<td>
						 <?php echo $row->diposit_duration;?>
						</td>
						<td>
						  <?php echo $row->final_amount.' TK';?>
						</td>
						<td>
						  <?php echo $row->non_bank_finance_feature;?>
						</td>
						<td>
						  <?php echo $row->diposit_monthy_benefit;?>
						</td>
						
						<td>
						<?php $ab=$row->non_bank_finance_diposit_id; ?>
         
<a href="javascript:void(0);" class="detail" id="<?php echo $ab; ?>">Details</a>
</td>
<td>
					
  <input type="checkbox" name="products[]" class="products" id="<?php echo $row->non_bank_finance_diposit_id; ?>"> 
</td>
</tr>
        <?php } ?>
</table>
</div>
	   </div>
	   </div>
	   </div>
        </div>
      </div>
    </section>
	

    
  