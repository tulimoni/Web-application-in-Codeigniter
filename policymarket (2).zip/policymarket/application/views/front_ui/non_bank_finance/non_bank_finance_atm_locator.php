  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <div class="newtext"><center><strong><u>Select Your Preferred Non Bank Finance</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_non_bank_finance_branch as $non_bank_finance_info_branch) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $non_bank_finance_info_branch->non_bank_finance_atm_url; ?>" target="bankatm">
            <img src="<?php echo base_url().$non_bank_finance_info_branch->non_bank_finance_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <iframe src= "https://www.unitedfinance.com.bd/contacts_2.html" name="bankatm" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" >
        </iframe>

     </div>
      </div>
   </div>

  

      


       
    

            
  

      

