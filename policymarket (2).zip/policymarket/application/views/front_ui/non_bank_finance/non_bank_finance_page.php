<div class="col-md-9">
  <section class="services padding-bottom-70">
    
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/style4.css" />
<section class="main">
      
        <ul class="ch-grid">
          <li>
            <div class="ch-item ch-img-1">        
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-1"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>non_bank_finance_ui/deposit_info"><h3>Deposit</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>non_bank_finance_ui/deposit_info">View on Details</p></a>
                  </div>  
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-2">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-2"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>non_bank_finance_ui/loan_info"><h3>Loan</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>non_bank_finance_ui/loan_info">View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-3">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-3"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_search"><h3>Non Bank finance Information</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_search">View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
        
      </section>

  </section>
</div>
