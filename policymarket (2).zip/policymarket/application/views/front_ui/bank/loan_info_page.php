  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
   
      <!-- <h4><u>Remittance</u></h4>
      <p>A remittance is a transfer of money by a foreign worker to an individual in his or her home country. Money sent home by migrants competes with international aid as one of the largest financial inflows to developing countries. Workers' remittances are a significant part of international capital flows, especially with regard to labour-exporting countries. In 2014, $436 billion went to developing countries, setting a new record. Overall global remittances also totaled $583 billion. In 2014, Bangladesh received an estimated $15.10 billion.</p>
          <h4>Select Your Preferred Remittance Company</h4> -->
        <div class="newloan">
        <a href="<?php echo base_url();?>bank_ui/home_loan">
            <img class="ShakeAndBorder2" alt="Home Loan"  src="<?php echo base_url();?>front_assets/images/Loan_Image/home_loan.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/car_loan">
            <img class="ShakeAndBorder2" alt="Car Loan" src="<?php echo base_url();?>front_assets/images/Loan_Image/car_loan.png" />
        </a>
                
        <a href="<?php echo base_url();?>bank_ui/personal_loan">
            <img class="ShakeAndBorder2" alt="Personal Loan" src="<?php echo base_url();?>front_assets/images/Loan_Image/personal_loan.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/marriage_loan">
            <img class="ShakeAndBorder2" alt="Marriage Loan" src="<?php echo base_url();?>front_assets/images/Loan_Image/marrige_loan.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/study_loan">
            <img class="ShakeAndBorder2" alt="Study Loan" src="<?php echo base_url();?>front_assets/images/Loan_Image/study_loan.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/health_loan">
            <img class="ShakeAndBorder2" alt="Health Loan" src="<?php echo base_url();?>front_assets/images/Loan_Image/health.png" />
        </a>
   
      
      <script>
      $('.ShakeAndBorder2').ShakeBorder();
      </script>
          </div>
    </div>

  

      


       
    

            
	

			

