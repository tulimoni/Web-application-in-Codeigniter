<link href="<?php echo base_url();?>front_assets/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url();?>front_assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/TableCSSCode.css" rel="stylesheet">
        <form class="form-horizontal" role="form" style="width: 600px;margin: auto;margin-top:150px;">
 
     <table id="table2"  class="table col-sm-12">

        </table>
    
    <div class="form-group">
      
    </div>
   <!-- <div class="form-group" style="border: 1px solid #ddd">-->
	<center><h5>Compare Your Preferred Loan</h5></center>
  <div class="CSSTableGenerator" >
        <table id="table1" class="table table-hover col-sm-12">
           <thead>
            <tr>
              <td>Bank</td>
              <td >Deposit Name</td>
						  <td>Interest Rate</td>
						  <td>Instalment Type</td>
              <td>Instalment</td>
              <td>Year</td> 
              <td>Maturity Amount</td>
						  <td>Features</td>
						  <td>Monthly Benifit</td>
				    </tr>
            </thead>
					<?php foreach ($results as $row) {
					?>
                    <tr>
                        <td >
                         <?php   $a=$row->bank_logo;?>
                         <img src="<?php echo base_url().$a?>" height="70px" width="100px" />
                          <?php   echo '<br>'; echo $row->bank_name;?>
                        </td>
                        <td><?php echo $row->diposit_name;?></td>
                        <td><?php echo $row->diposit_interest_rate.'%';?></td>
                        <td><?php echo $row->diposit_type;?></td>
                        <td><?php echo $row->diposit_amount;?></td>
						            <td><?php echo $row->diposit_duration;?></td>
						            <td><?php echo $row->final_amount;?></td>
						            <td><?php echo $row->bank_feature;?></td>
						            <td><?php echo $row->diposit_monthy_benefit;?></td>
						            </tr>
                        <?php }?>
            </tbody>
        </table>
    <!--</div>-->
	</div>
    <div class="form-group">
        <div class="col-sm-12">
            <span class="help-block">You can select with <b>Ctrl</b>, <b>Shift</b>, <b>Common</b> Or <b>Ctrl + A</b></span>
        </div>
    </div>
    
</form>
<script src="<?php echo base_url();?>front_assets/js/jquery-1.11.1.min.js"></script>
<script src="<?php echo base_url();?>front_assets/js/multiselect.js" type="text/javascript"></script>
<script type="text/javascript">
    $(function () {
        $('#table1').multiSelect({
            actcls: 'info', 
            selector: 'tbody tr', 
            except: ['tbody'], 
            statics: ['.danger', '[data-no="1"]'],
            callback: function (items) {
                $('#table2').empty().append(items.clone().removeClass('info').addClass('success'));
            }
        });
    })
</script>
