<?php error_reporting(0);?>
  <div class="col-md-12">
    <section class="services padding-bottom-70">
    <div class="contact-form">
    
		 </font>
         
		<link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
    <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">
		<div class="newtext"><center><strong>Brokerage House List</strong></center></div>
			<div class="tablenn">
        <div class="tablenbfbrokeragehouse">
          <div class="bank_logo_area_for_table">
                <table >

  <thead>
  <tr>
    <th style="padding:5px">Brokerage House</th>
    <th style="padding:5px" width="15%">Membership No</th>
    <th style="padding:5px">Office Address</th>
    <th style="padding:5px"width="20%">Office Phone Number</th>
    <th style="padding:5px" width="10%">Details View</th>
  </tr>
  </thead>
					<?php foreach ($all_brokerage_house as $row) {
          ?>
                    <tr>
                    <td >
                        <?php   $a=$row->brokerage_house_logo;?>
                        <img src="<?php echo base_url().$a?>"/></br>
                        <div class="newfont"><?php echo $row->brokerage_house_name;?></div>
                        </td>
                        <td><?php echo $row->membership_no;?></td>
                        <td><?php echo $row->brokerage_house_office_address;?></td>
                        <td><?php echo $row->brokerage_house_phone_number;?></td>
      <td><a href="<?php echo $row->brokerage_house_website_url;?>" target="_blank">Details</a></td>
                    </tr>
                   <?php }?>
                </table>
            </div>
            </div>
	   </div>
	   </div>
	   </div>
     </div>
        </div>
      </div>
    </section>
	