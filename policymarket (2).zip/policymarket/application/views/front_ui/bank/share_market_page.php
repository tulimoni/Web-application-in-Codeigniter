<div class="col-md-9">
  <section class="services padding-bottom-70">
  
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/style7.css" />
      <section class="main">
      
        <ul class="ch-grid">
          <li>
            <div class="ch-item">       
              <div class="ch-info">
                <div class="ch-info-front ch-img-1"></div>
                <div class="ch-info-back">
                  <a href="<?php echo base_url();?>bank_ui/b_share_market"><h3>Bangladeshi Stock Exchange</h3>
                  <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/b_share_market">View on Details</p></a>
                </div>  
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item">
              <div class="ch-info">
                <div class="ch-info-front ch-img-2"></div>
                <div class="ch-info-back">
                  <a href="<?php echo base_url();?>bank_ui/i_share_market"><h3>International Stock Exchange</h3>
                  <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/i_share_market">View on Details</p></a>
                </div>
              </div>
            </div>
          </li>
        </ul>
        
      </section>
    </div>
  </section>
</div>
