  <div class="col-md-9">
  
  <div id="content"> 
    
    <!-- BLOG -->
    <section class="blog blog-pages blog-single padding-bottom-70">
      <div class="container">
        <div class="row">
          <div class="col-md-8"> 
            
            <!-- Post -->
            <article> <img class="img-responsive" src="<?php echo base_url().$all_news_info->news_logo; ?>" alt=""> 
              <!-- Date --> 
              <!--<div class="date"> 19 <span>MAY</span> </div>--> 
              <!-- Detail -->
              <div class="post-detail">
                <h5 class="font-normal"><?php echo $all_news_info->news_title?> </h5>
                <p><?php echo $all_news_info->news_details?><br></p>
              </div>
            </article>
          </div> 
        </div>
      </div>
    </section>
  </div>
  
  </div>