  <?php error_reporting(0);?>

  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="newfrom1">
    <div class="from_dempsit_wrap">
    <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
          <div class="newfrom">
  <form class="common_fact" method="post" action="<?php echo base_url();?>bank_ui/home_loan_search">
           <table>
           <tr>
           <td>Amount of Loan: <input type="number" min="50000" max="10000000" name="money" value="<?php echo set_value('money'); ?>" required></td></br>
           <td>Duration of Loan:  
            <select name="month" value="<?php echo set_value('month'); ?>">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>  Years
           </td> 
       <td>
        <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();"> Start <i class="fa fa-caret-right"></i></button>
               
        </td>
            </tr>
            </table>
          </form>
        </div>
        </div>
     <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

  <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
        <div class="bank_logo_area_for_table">
  <div class="newtext">     
  <center>We Found <strong>'18'</strong> Home Loan, Loan Amount is <strong>'100,000.00'</strong> BDT, Loan Duration is <strong>'1'</strong> Year.</center>
  </div>
  <section class="padding-bottom-30">
  </section>
  
  <h5>Last Update: <?php echo date("d M Y");?>. </h5>
  
  <table id="homeLoan_t">

  <thead>
  <tr>
    <th style="padding:5px" width="15%">Bank</th>
    <th style="padding:5px" width="14%">Interest Rate</th>
    <th style="padding:5px" width="17%">Total Interest to Pay</th>
    <th style="padding:5px" width="17%">Monthly Installment</th>
    <th style="padding:5px" width="14%">Processing Fees</th>
    <th style="padding:5px" width="10%">Apply</th>
    <th width="14%">Compare</th>
  </tr>
  </thead>

  <tr id="one_t">
    <td><img src="<?php echo base_url();?>image/bank_logo/bank_asia_logo.gif" alt="" /></br><div class="newfont">Bank Asia Ltd.</div></td>
    <td><strong>11%</strong></td>
    <td><strong>6,057.99 BDT</strong></td>
    <td><strong>8,838.17 BDT</strong></td>
    <td><strong>1.5%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr id="two_t">
    <td><img src="<?php echo base_url();?>image/bank_logo/tbl_logo.png" alt="" /></br><div class="newfont">Trust Bank Ltd.</div></td>
    <td><strong>10.5%</strong></td>
    <td><strong>5,778.32 BDT</strong></td>
    <td><strong>8,814.86 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/prime_39.png" alt="" /></br><div class="newfont">Prime Bank Ltd.</div></td>
    <td><strong>9.99%</strong></td>
    <td><strong>5,493.48 BDT</strong></td>
    <td><strong>8,791.12 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/brac_bank_11.png" alt="" /></br><div class="newfont">Brac Bank Ltd.</div></td>
    <td><strong>9.75%</strong></td>
    <td><strong>5,359.59 BDT</strong></td>
    <td><strong>8,779.97 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/eastern-bank-ltd.gif" alt="" /></br><div class="newfont">Eastern Bank Ltd.</div></td>
    <td><strong>9%</strong></td>
    <td><strong>4,941.77 BDT</strong></td>
    <td><strong>8,745.15 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/ific_logo.jpg" alt="" /></br><div class="newfont">IFIC Bank Ltd..</div></td>
    <td><strong>10.5%</strong></td>
    <td><strong>5,493.48 BDT</strong></td>
    <td><strong>8,791.12 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_71.png" alt="" /></br><div class="newfont">United Commercial Bank Ltd.</div></td>
    <td><strong>11%</strong></td>
    <td><strong>6,057.99 BDT</strong></td>
    <td><strong>8,838.17 BDT</strong></td>
    <td><strong>1%-1.5%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/sjibl.gif" alt="" /></br><div class="newfont">Shahjalal Islami Bank</div></td>
    <td><strong>12%</strong></td>
    <td><strong>6,618.55 BDT</strong></td>
    <td><strong>8,884.88 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo2.gif" alt="" /></br><div class="newfont">Dhaka Bank Ltd.</div></td>
    <td><strong>12%</strong></td>
    <td><strong>6,618.55 BDT</strong></td>
    <td><strong>8,884.88 BDT</strong></td>
    <td><strong>1.5%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/sibl.gif" alt="" /></br><div class="newfont">SIBL</div></td>
    <td><strong>12.5%</strong></td>
    <td><strong>6,899.44 BDT</strong></td>
    <td><strong>8,908.29 BDT</strong></td>
    <td><strong>NA</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/exim1.gif" alt="" /></br><div class="newfont">EXIM Bank Ltd.</div></td>
    <td><strong>13.5%</strong></td>
    <td><strong>7,462.43 BDT</strong></td>
    <td><strong>8,955.20 BDT</strong></td>
    <td><strong>NA</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mbl-logo.png" alt="" /></br><div class="newfont">Modhu Moti Bank Ltd.</div></td>
    <td><strong>13.5%</strong></td>
    <td><strong>7,462.43 BDT</strong></td>
    <td><strong>8,955.20 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo_png.png" alt="" /></br><div class="newfont">One Bank Ltd.</div></td>
    <td><strong>10.25%</strong></td>
    <td><strong>5,638.64 BDT</strong></td>
    <td><strong>8,803.22 BDT</strong></td>
    <td><strong>1%-2%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_8.png" alt="" /></br><div class="newfont">Standard Chartered Bank</div></td>
    <td><strong>9.5%</strong></td>
    <td><strong>5,220.21 BDT</strong></td>
    <td><strong>8,768.35 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo1.gif" alt="" /></br><div class="newfont">The City Bank Ltd.</div></td>
    <td><strong>9.99%</strong></td>
    <td><strong>5,493.48 BDT</strong></td>
    <td><strong>8,791.12 BDT</strong></td>
    <td><strong>NA</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/dutch_bangla.png" alt="" /></br><div class="newfont">Dutch Bangla Bank Ltd.</div></td>
    <td><strong>10%</strong></td>
    <td><strong>5,499.06 BDT</strong></td>
    <td><strong>8,791.59 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/nrblogo.gif" alt="" /></br><div class="newfont">NRB Bank Ltd.</div></td>
    <td><strong>11.5%</strong></td>
    <td><strong>6,338.06 BDT</strong></td>
    <td><strong>8,861.51 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mdblogo.jpg" alt="" /></br><div class="newfont">Midland Bank Ltd.</div></td>
    <td><strong>11.99%</strong></td>
    <td><strong>6,612.93 BDT</strong></td>
    <td><strong>8,884.41 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="chk" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>

  </table>
    </div>
     </div>
      </div>
       </div>
        </div>
		



      


     
  

      