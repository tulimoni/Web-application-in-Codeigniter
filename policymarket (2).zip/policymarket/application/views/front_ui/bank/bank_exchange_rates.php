<?php error_reporting(0); ?>
<div class="col-md-12">
   <div class="from_dempsit_wrap">
       <div class="contact-form">
         <div class="newfrom">
          <!--<h6>Choose Your Preferred Currency</h6>-->
          <!-- Success Msg -->
          <div id="contact_message" class="success-msg"> <i class="fa fa-paper-plane-o"></i>Thank You. Your Message has been Submitted</div>
          
          <!-- FORM -->

          <form role="form" method="post" action="<?php echo base_url();?>bank_ui/exchange_rate_currency_wise">
            <table>
               <tr>
               	<td>
                   <select name="currency_type">
            <option>Select Currency</option>
            <?php
           foreach ($exchange_rate as $money) 
                {
				
                                    
                ?>
            <option value="<?php echo $money->currency_type;?>"><?php echo $money->currency_type;?></option>
            <?php } ?>
        </select>
              	</td>
          
              <td>
                <button type="submit" value="submit" class="btn btn-1" id="btn_submit">Start <i class="fa fa-caret-right"></i></button>
              </tr>
              </table>
          </form>
        </div>
         </div>
           </div>    
    <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
    <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

    <div class="newtext"><center><strong>Compare Exchange Rates in BDT</strong></center></div>
    <section class="padding-bottom-20">
        </section>
      <div class="tablenn">
        <div class="tablebexchange">
          <div class="bank_logo_area_for_table">
                <table>

<thead>
  <tr>
    <th style="padding:5px">Bank</th>
    <th style="padding:5px">Currency</th>
    <th style="padding:5px">Selling [BDT]</th>
    <th style="padding:5px">Buying [BDT]</th>
    <!-- <th style="padding:5px">BC [BDT]</th>
    <th style="padding:5px">TT Clean [BDT]</th> -->
    <th style="padding:5px">Last Revised</th>
  </tr>
</thead>


		  <?php
		  if($currency_wise_rate)
		  {
		   foreach ($currency_wise_rate as $currency_wise) 
                		{
						?>
						 <tr>
                <td ><img src="<?php echo base_url();?><?php echo $currency_wise->bank_logo ?>" alt="" height="70px" width="100px"/>
						<br /><div class="newfont"><?php echo $currency_wise->bank_name;?></div></td>
                <td><strong><?php echo $currency_wise->currency_type;?></strong></td>
                <td><strong><?php echo $currency_wise->selling;?></strong></td>
                <td><strong><?php echo $currency_wise->buying;?></strong></td>
                <!-- <td><strong><?php echo $currency_wise->bc;?></strong></td>
	              <td><strong><?php echo $currency_wise->tt_clean;?></strong></td> -->
                <td><strong><?php echo date("d M Y");?>.</strong></td>
                </tr>	
					<?php
					}
				}
					else
					{
					 foreach ($default as $currency) 
                {                  
                ?>
                  <tr>
			             <td><img src="<?php echo base_url();?><?php echo $currency->bank_logo ?>"" alt="" height="70px" width="100px"/>
						           <br/><div class="newfont"><?php echo $currency->bank_name;?></div></td>
                    <td><strong><?php echo $currency->currency_type;?></strong></td>
                    <td><strong><?php echo $currency->selling;?></strong></td>
                    <td><strong><?php echo $currency->buying;?></strong></td>
                    <!-- <td><strong><?php echo $currency->bc;?></strong></td>
		    <td><strong><?php echo $currency->tt_clean;?></strong></td> -->
                    <td><strong><?php echo date("d M Y");?>.</strong></td>
                    </tr>
                    <?php }
					}
					 ?>
					</table>
	         </div>
	       </div>
	     </div>
      </div>
    </div>
    </div>
      </div>
    </div>
    </section>
	