<div class="col-md-9">
  <section class="services padding-bottom-70">
     
      <!-- Heading 
      
    </div>
    <div class="best-services"> 
      
      <div class="container">
        <ul class="row list">
          
          <li class="col-md-4" data-content="#colio_c1">
            <article class="thumb"> <a href="<?php echo base_url();?>bank_ui/deposit_info"> <i class="fa fa-gg-circle"></i>
              <h5>DEPOSIT</h5>
              </a> </article>
          </li>
          
         
          <li class="col-md-4" data-content="#colio_c2">
            <article class="thumb"><a href="<?php echo base_url();?>bank_ui/loan_info"> <i class="fa fa-ils"></i>
              <h5>LOAN</h5>
              </a> </article>
          </li>
        </ul>
      </div>
      <div class="container">
        <ul class="row list">
         
          <li class="col-md-4" data-content="#colio_c1"> <article class="thumb"> <a href="<?php echo base_url();?>bank_ui/money_exchange"> <i class="fa fa-retweet"></i>
            <h5>Money Exchange Rate</h5>
            </a> </article> 
          </li>
          
          
          <li class="col-md-4" data-content="#colio_c2"> <article class="thumb"><a href="<?php echo base_url();?>bank_ui/bank_search"> <i class="fa fa-binoculars"></i>
            <h5>Bank Information</h5>
            </a> </article> 
          </li>
        </ul>
      </div>
    </div> -->


<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/css/style5.css" />
<section class="main">
      
        <ul class="ch-grid">
          <li>
            <div class="ch-item ch-img-1">        
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-1"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>bank_ui/deposit_info"><h3>Deposit</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/deposit_info">View on Details</p></a>
                  </div>  
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-2">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-2"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>bank_ui/loan_info"><h3>Loan</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/loan_info"> View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-3">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-3"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>bank_ui/money_exchange"><h3>Money Exchange Rate</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/money_exchange">View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div class="ch-item ch-img-4">
              <div class="ch-info-wrap">
                <div class="ch-info">
                  <div class="ch-info-front ch-img-4"></div>
                  <div class="ch-info-back">
                    <a href="<?php echo base_url();?>bank_ui/bank_search"><h3>Bank Information</h3>
                    <p>by Policy Market <a href="<?php echo base_url();?>bank_ui/bank_search">View on Details</p></a>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
        
      </section>

  </section>
</div>
