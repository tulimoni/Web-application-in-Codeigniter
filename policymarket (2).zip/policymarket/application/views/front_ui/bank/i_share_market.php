  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <div class="newtext"><strong><center>Select Your Preferred Stock Exchange</center></strong></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_share_market as $share_market) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $share_market->stock_exchange_website_url; ?>" target="share_market">
            <img src="<?php echo base_url().$share_market->stock_exchange_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <iframe src= "http://www.londonstockexchange.com/home/homepage.htm" name="share_market" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>

        </div>
      </div>
    </div>

  

      


       
    

            
	

			

