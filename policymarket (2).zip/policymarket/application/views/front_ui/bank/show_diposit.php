<?php error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="M_Adnan">
<title>Policy Market-<?php echo $title ;?></title>
<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url();?>front_assets/css/bootstrap.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo base_url();?>front_assets/css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url();?>front_assets/css/ionicons.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/main.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url();?>front_assets/css/responsive.css" rel="stylesheet">

<!-- Online Fonts -->
<link href='https://fonts.googleapis.com/css?family=Raleway:400,600,800,200,500' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600italic,400italic,300,300italic,600,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Libre+Baskerville:400italic,400,700' rel='stylesheet' type='text/css'>

<!-- COLORS -->
<link rel="stylesheet" id="color" href="<?php echo base_url();?>front_assets/css/colors/default.css">

<!-- JavaScripts -->
<script src="<?php echo base_url();?>front_assets/js/modernizr.js"></script>
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>

<!-- Wrap -->
<div id="wrap"> 
  <!-- header -->
  <header> 
    <!-- Top bar -->
    <div class="top-bar">
      <div class="top-info">
        <div class="container">
          <ul class="personal-info">
            <li>
              <p><i class="fa fa-phone"></i> +8804475-141844 </p>
            </li>
            <li> 
              <!--<p>Hi! Here comes custom txt line </p>--> 
            </li>
            <li>
              <p><i class="fa fa-envelope"></i>emporium@gmail.com </p>
            </li>
          </ul>
          
          <!-- Right Sec -->
          <div class="right-sec"> 
            
            <!-- social -->
            <ul class="social">
              <li><a href="#."><i class="fa fa-facebook"></i></a></li>
              <li><a href="#."><i class="fa fa-twitter"></i></a></li>
              <li><a href="#."><i class="fa fa-google"></i></a></li>
              <li><a href="#."><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Navigation -->
    <nav class="navbar">
      <div class="sticky">
        <div class="container"> 
          <!-- LOGO -->
          <div class="row">
            <div class="logo"> <a href="<?php echo base_url();?>"><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/logo.png" alt=""></a> </div>
            <!-- Nav -->
            
            <ul class="nav ownmenu">
              <li class="active"> <a href="<?php echo base_url();?>">Home </a> 
                <!--<ul class="dropdown">
              <li> <a href="index-boxed.html">Home Boxed</a> </li>
            </ul>--> 
              </li>
            
              <li> <a href="loan.html">Contact</a> </li>
              <li> <a href="index.html">Privacy Policy</a> </li>
              <li> <a href="index.html">Services </a> </li>
              <li> <a href="news.html">News</a></li>
              <li> <a href="contact.html">About Us</a> 
			   <!--<ul class="dropdown">
              
			  <li> <a href="index-boxed.html">Contact </a> </li>
			  <li> <a href="index-boxed.html">News</a> </li>
            </ul>-->
			  
			  </li>
			  <li> <a href="loan.html">ATM Branch Locator</a> </li>
			   <li> <a href="#">Campare</a> 
			   <ul class="dropdown">
              
			  <li> <a href="<?php echo base_url();?>welcome/diposit_compare">Diposit Compare </a> </li>
			  
            </ul>
			   
			   </li>
            </ul>
            <!-- Search -->
            <div class="search-icon"> <a href="#."><i class="fa fa-search"></i></a>
              <form>
                <input class="form-control" type="search" placeholder="Type Here">
                <button type="submit"><i class="fa fa-search"></i></button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </nav>
  </header>
  
<?php
if($sidebar){
	
  echo $sidebar;
	}
 //echo $maincontent;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>phpmysqlcode</title>
<link href="style.css" rel="<?php echo base_url();?>front_assets/css/comstylesheet" type="text/css" />
<script src="<?php echo base_url();?>front_assets/js/comjquery.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>front_assets/fancybox/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>front_assets/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />

<script type="text/javascript">
$(document).ready(function(){             
        $(".detail").click(function(){ 
        var p_id = $(this).attr('id');
        if(p_id!='')
        { 
         $.ajax({
                type:"post",
				
                url: '<?= base_url()."Welcome/check_compaire"?>',
                data:{p_id:p_id,type:'detail'},
                cache: false,
                success:function(data){
                $.fancybox(data, {
                        fitToView: false,
                        width: 700,
                        height: 700,
                        autoSize: true,
                        closeClick: false,
                        openEffect: 'none',
                        closeEffect: 'refresh'
                        });     
                                
                        }
           });
        }
        });
});

function compare()
{
        var total_check = new Array();
        $('.products:checked').each(function () {
                total_check.push($(this).val());
        });

        if (total_check != '') {
                if (total_check.length == '2') {
                var i = 0;
                var pidArray = new Object();
                $('.products:checked').each(function () {
                total_check.push($(this).val());
                var id = $(this).attr('id');
                pidArray[i] = {
                        pid: id
                };
                i++;
        });
        var data = JSON.stringify(pidArray);
        $('#wait').show();
        $.ajax({
                url: '<?= base_url()."Welcome/check_compaire"?>',
                type: "POST",
                data: {pids:data,type:'compare'},
                cache: false,
                success: function (data) {
                $('#wait').hide();
                        $.fancybox(data, {
                                fitToView: false,
                                width: 700,
                                height: 500,
                                autoSize: false,
                                closeClick: false,
                                openEffect: 'none',
                                closeEffect: 'refresh'
                        });
                }
        });
                } else {
                alert("Please select two Banks ");
                return false;
                }
        } else {
                alert("Please select minimum two Banks");
                return false;
        }
}
</script>

<table width="100%">


<span align="center">
        <img id="wait" style="display:none;margin-left:300px;" src="image/loading.gif">
</span>
<tr>
<td width="10%">
        <a href="javascript:void(0)" onClick="compare();" style="color:green;font-size:15px;">
        <b>Compare</b></a>
</td>
<td width="20%">Product Image</td>
<td width="20%">Comany Name</td>
<td width="20%">Price</td>
<td width="20%">Details</td>
</tr><?php foreach ($results as $row) {
					?>
                    <tr>
					
					<td>
					<?php
					 $ab=$row->bank_diposit_id;?>
  <input type="checkbox" name="products[]" class="products" id="<?php echo $ab; ?>">
</td>

                        <td >
                         <?php   $a=$row->bank_logo;?>
<img src="<?php echo base_url().$a?>" height="70px" width="100px" />
<?php   echo '<br>';
   echo $row->bank_name; 
  ?>
                        </td>
                       
						
						  <?php echo $row->final_amount;?>
						</td>
						<td>
						  <?php echo $row->bank_feature;?>
						</td>
						<td>
						  <?php echo $row->diposit_monthy_benefit;?>
						</td>
						
						<td>
						<?php $ab=$row->bank_diposit_id; ?>
						
                  
  <a href="javascript:void(0);" class="detail" id="<?php echo $ab; ?>">Details</a>
</td>
</tr>
        <?php } ?>
</table>
</div>
</div></div>
</div>
</body>
</html>
    
    <!-- Clients slider --> 
    <section class="clients padding-top-100 padding-bottom-100">
      <div class="container"> 
        
        <div class="heading text-center">
          <h4>Our Amazing Clients</h4>
          <span>We trust in longlasting partnerships with the most important brands on the market</span> </div>
        
        <div class="single-slide">
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/AB_BANK_1.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/48.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
            </ul>
          </div>
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/48.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/AB_BANK_1.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/47.jpg" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/49.jpg" alt=""></a></li>
            </ul>
          </div>
        </div>
      </div>
    </section> 
  </div>
  
  <!-- FOOTER -->
  <footer>
    <div class="container">
      <div class="row"> 
        
        <!-- ABOUT -->
        <div class="col-md-3"> <img src="<?php echo base_url();?>front_assets/images/logo-footer.png"alt="">
          <div class="about-foot">
            <ul>
              <li>
                <p><i class="fa fa-map-marker"></i> House #67/B,Flat #4B,Road #26(old),15/A(New)Dhanmondi, Dhaka-1209,Bangladesh.</p>
              </li>
              <li>
                <p><i class="fa fa-phone"></i> (+88 04475-141844)</p>
              </li>
              <li>
                <p><i class="fa fa-envelope"></i> emporiumtechnologyltd.com</p>
              </li>
            </ul>
          </div>
        </div>
        
        <!-- Twitter Feed -->
        <div class="col-md-3">
          <h6>Twitter Feed</h6>
          <ul class="tweet">
            <li>
              <p>A Guide to Better Brainstorming <a href="#." class="primary-color">https://twitter.com/?lang=en</a></p>
              <span>May 22, 2015</span> </li>
            <p>we provide an unbiased comparison between all the top bank service policy along with product reviews to help you decide. </p>
          </ul>
        </div>
        
        <!-- Photostream -->
        <div class="col-md-3">
          <h6>Photostream</h6>
          <ul class="photo-steam">
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/1.jpg" alt=""></a></li>
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/2.jpg" alt=""></a></li>
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/3.jpg" alt=""></a></li>
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/4.jpg" alt=""></a></li>
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/2.jpg" alt=""></a></li>
            <li><a href="#."><img src="<?php echo base_url();?>front_assets/images/1.jpg" alt=""></a></li>
          </ul>
        </div>
        
        <!-- Categories -->
        <div class="col-md-3">
          <h6>Policy Market</h6>
          <ul class="xlink">
            <li><a href="#.">Home</a></li>
            <li><a href="#.">Loan</a></li>
            <li><a href="#.">Deposit</a></li>
            <li><a href="#.">Savings</a></li>
            <li><a href="#.">Services</a></li>
            <li><a href="#.">House Finance</a></li>
            <li><a href="#.">Ramitance</a></li>
            <!--<li><a href="#.">e-commerce</a></li>
            <li><a href="#.">Web development</a></li>-->
          </ul>
        </div>
      </div>
    </div>
  </footer>
  
  <!-- RIGHTS -->
  <div class="rights">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p> ? All Rights Reserved 2016<a href="http://www.emporiumtechnologyltd.com">emporiumtechnologyltd.com </a></p>
        </div>
        <div class="col-md-6 text-right"> <a href="#.">Privacy Policy</a> <a href="#.">Terms & Conditions</a> </div>
      </div>
    </div>
  </div>
  
  <!--marguee  class="navbar-fixed-bottom"-->
  <footer class="ftr_msg_cont">
    <div id="massage-bar" class="navbar-fixed-bottom">
      <div class="container">
        <div style="overflow:hidden"> <!--<strong style="display:inline-block; color:#1076BC; width:100px; float:left">Message:</strong>-->
          <div id="features">
            <ul>
              <li><a href="#">Something really cool Lorem Ipsum is simply dummy text of the printing and typesetting industry.</a></li>
              <li><a href="#">Another thing cooler Lorem Ipsum is simply dummy text of the printing and typesetting industry.</a></li>
              <li><a href="#">Final awesome thing Lorem Ipsum is simply dummy text of the printing and typesetting industry.</a></li>
            </ul>
          </div>
        </div>
        <!--<marquee  align='middle' behavior='scroll' direction='left' scrollamount='3' onmouseover='this.stop()' onmouseout='this.start();'>
        we provide an unbiased comparison between all the top bank service policy along with product reviews to help you decide
        </marquee>--> 
      </div>
    </div>
  </footer>
</div>
<script src="<?php echo base_url();?>front_assets/js/jquery-1.11.0.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/bootstrap.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/own-menu.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.isotope.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.flexslider-min.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/owl.carousel.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.cubeportfolio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.colio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/main.js"></script> 

<script src="<?php echo base_url();?>front_assets/js/featurify.js"></script> 
<script type="text/javascript">
	$("#features").featurify();
	
	//or if you want some options
	$("#sample3").featurify({
	 directionIn : -1, // left: -1 / right: 1. Direction from where will come the next slide 
	 directionOut: -1, // left: -1 / right: 1. Direction to where will go the current slide
	 pause:2000,       // time in milleseconds between each slide
	 transition:350    // time in milleseconds that will take the sliding effect
 });
</script>
</body>
</html>