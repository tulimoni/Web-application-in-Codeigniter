<?php 
function current_url()
{
  $url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
  $validURL = str_replace("&","&amp;",$url);

  return $validURL;
}

echo "Page URL is :".current_url();

?>