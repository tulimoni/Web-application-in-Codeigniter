  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <div class="newtext"><center><strong><u>Select Your Preferred Bank</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_bank as $bank_info) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $bank_info->bank_atm_url; ?>" target="bankatm">
            <img src="<?php echo base_url().$bank_info->bank_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
<iframe src= "http://www.mutualtrustbank.com/branch-atm-location/" name="bankatm" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>

     </div>
      </div>
   </div>

  

      


       
    

            
	

			

