<?php
$con = @mysql_connect('localhost','root','');
if (!$con) {
  die('Could not connect: ' . mysql_error());
}
$a = mysql_query("CREATE DATABASE IF NOT EXISTS policyma_ndb");
if (!$a) {
    echo "error creating database";
} else {
    echo " ";
}

mysql_select_db('policyma_ndb', $con);


$type = trim($_REQUEST['type']);
$res ='';
$res="<table cellspacing='2' cellpadding='0' align='left' width='200'>
<tr><th align='left'><strong>Double Benefit Attributes<hr></strong></th></tr>
<tr height='75' align='center'><td align='left'>&nbsp;</td></tr>
<tr height='40' align='center'><td align='left'>Bank Name</td></tr>
<tr height='40' align='center'><td align='left'> Interest Rate</td></tr>
<tr height='40' align='center'><td align='left'> Minimum Deposit</td></tr>
<tr height='40' align='center'><td align='left'>Duration of Double</td></tr>
<tr height='40' align='center'><td align='left'>Last Checked Date</td></tr>
</table>";
if($type=='detail')
{
$pid = $_REQUEST['p_id'];
$id = $pid;
$sql = mysql_query("SELECT * FROM tbl_bank_double_benefit,tbl_bank_name
       where tbl_bank_double_benefit.bank_id=tbl_bank_name.bank_id
       and bank_double_benefit_id=$id") OR die(mysql_error());

$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Bank Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           
                <img src=".base_url().$data['bank_logo']." width='110px' height='45px'>
         
        </td>
</tr>
<tr height='40' align='center'><td align='left'>".$data['bank_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_i_r']."%</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_m_d']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_duration']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_lcd']."</td></tr>";
$res .= "</table>";
}

else if($type=='compare')
{
$Totalpids = (array)json_decode(stripslashes($_REQUEST['pids']));
foreach($Totalpids as $product)
{
$r=$product->pid;


$sql = mysql_query("SELECT * FROM tbl_bank_double_benefit,tbl_bank_name
      where tbl_bank_double_benefit.bank_id=tbl_bank_name.bank_id and bank_loan_id=".$product->pid."");
$data = mysql_fetch_assoc($sql);
$res .="<table cellspacing='2' cellpadding='0' align='left' width='240'>
<tr><th align='left'><strong>Double Benefit Details<hr></strong></th></tr>
<tr height='75' align='center'>
        <td align='left'>
           <img src=".base_url().$data['bank_logo']." width='110px' height='45px'>      
        </td>
  </tr>
<tr height='40' align='center'><td align='left'>".$data['bank_name']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_i_r']."%</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_m_d']."</td></tr>
<tr height='40' align='center'><td align='left'>".$data['bank_double_benefit_lcd']."</td></tr>";
$res .= "</table>";

}
}
echo $res;
?>