<?php error_reporting(0); ?>
<script type="text/javascript">
$(document).ready(function(){             
        $(".detail").click(function(){ 
        var p_id = $(this).attr('id');
        if(p_id!='')
        { 
         $.ajax({
                type:"post",
				
                url: '<?= base_url()."bank_ui/check_compaire_bank_double_benefit" ?>',
                data:{p_id:p_id,type:'detail'},
                cache: false,
                success:function(data){
                $.fancybox(data, {
                        fitToView: false,
                        width: 700,
                        height: 700,
                        autoSize: true,
                        closeClick: false,
                        openEffect: 'none',
                        closeEffect: 'refresh'
                        });     
                                
                        }
           });
        }
        });
});

function compare()
{
        var total_check = new Array();
        $('.products:checked').each(function () {
                total_check.push($(this).val());
        });

        if (total_check != '') {
                if (total_check.length == '2') {
                var i = 0;
                var pidArray = new Object();
                $('.products:checked').each(function () {
                total_check.push($(this).val());
                var id = $(this).attr('id');
                pidArray[i] = {
                        pid: id
                };
                i++;
        });
        var data = JSON.stringify(pidArray);
        $('#wait').show();
        $.ajax({
                url: '<?= base_url()."bank_ui/check_compaire_bank_double_benefit"?>',
                type: "POST",
                data: {pids:data,type:'compare'},
                cache: false,
                success: function (data) {
                $('#wait').hide();
                        $.fancybox(data, {
                                fitToView: false,
                                width: 700,
                                height: 500,
                                autoSize: false,
                                closeClick: false,
                                openEffect: 'none',
                                closeEffect: 'refresh'
                        });
                }
        });
                } else {
                alert("Please select two Banks ");
                return false;
                }
        } else {
                alert("Please select minimum two Banks");
                return false;
        }
}
</script>

<div class="col-md-12">
  <div class="from_dempsit_wrap">
    <div class="contact-form">
      <?php if($message)
		 {?>
      <font color="#FF0000"; style="margin-left:200px;"> <?php echo $message;
		 }
	?> </font> 
      <!-- FORM
		   <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
      <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">
      
      <div class="newtext"><center>We Found <strong>'2'</strong> Triple Benefit Schemes Information</center></div>
      <section class="padding-bottom-30"> </section>
      <div class="tablenn">
        <div class="triple_benefit">
        <div class="bank_logo_area_for_table">
        
        <table>
       
        <thead>
  <tr>
    <th style="padding:5px"width="15%">Bank</th>
    <th style="padding:5px" width="14%">Interest Rate</th>
    <th style="padding:5px" width="14%">Minimum Deposit</th>
    <th style="padding:5px" width="16%">Duration of Triple</th>
    <th style="padding:5px" width="20%">Last Update</th>
    <!-- <th style="padding:5px" width="20%">Compare</th> -->
  </tr>
  </thead>
          <?php foreach ($all_triple_benefit as $triple_benefit) {
					?>
          <tr>
            
            <td><?php   $a=$triple_benefit->bank_logo;?>
                <img src="<?php echo base_url().$a?>" height="50px" width="70px" /></br>
                <div class="newfont"><?php echo $triple_benefit->bank_name; ?></div></td>
            <td><strong><?php echo $triple_benefit->bank_triple_benefit_i_r;?>%</strong></td>
            <td><strong><?php echo $triple_benefit->bank_triple_benefit_m_d;?>.00 BDT</strong></td>
            <td><strong><?php echo $triple_benefit->bank_triple_benefit_duration;?></strong></td>
            <td><strong><?php echo $triple_benefit->bank_triple_benefit_lcd;?></strong></td>
            <!-- <td><input type="checkbox" name="products[]" class="products" id="<?php echo $triple_benefit->bank_triple_benefit_id; ?>"><a href="javascript:void(0)" onClick="compare();" > <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td> -->
            
          </tr>
          <?php } ?>
        </table>
      </div>
    </div>


