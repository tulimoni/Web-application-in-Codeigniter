  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
   
      <!-- <h4><u>Remittance</u></h4>
      <p>A remittance is a transfer of money by a foreign worker to an individual in his or her home country. Money sent home by migrants competes with international aid as one of the largest financial inflows to developing countries. Workers' remittances are a significant part of international capital flows, especially with regard to labour-exporting countries. In 2014, $436 billion went to developing countries, setting a new record. Overall global remittances also totaled $583 billion. In 2014, Bangladesh received an estimated $15.10 billion.</p>
          <h4>Select Your Preferred Remittance Company</h4> -->
        <div class="newdeposit">
        <a href="<?php echo base_url();?>bank_ui/m_i_scheme_deposit">
            <img class="ShakeAndBorder2" alt="Monthly Income Scheme"  src="<?php echo base_url();?>front_assets/images/Deposit_Image/income.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/m_s_scheme_deposit">
            <img class="ShakeAndBorder2" alt="Monthly Saving Scheme" src="<?php echo base_url();?>front_assets/images/Deposit_Image/monthly_saving_deposit.png" />
        </a>
                
        <a href="<?php echo base_url();?>bank_ui/fixed_deposit">
            <img class="ShakeAndBorder2" alt="Fixed Deposit Scheme" src="<?php echo base_url();?>front_assets/images/Deposit_Image/fixed deposit.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/double_benefit">
            <img class="ShakeAndBorder2" alt="Double Benefit Scheme" src="<?php echo base_url();?>front_assets/images/Deposit_Image/dubble.png" />
        </a>
        <a href="<?php echo base_url();?>bank_ui/triple_benefit">
            <img class="ShakeAndBorder2" alt="Triple Benefit Scheme " src="<?php echo base_url();?>front_assets/images/Deposit_Image/tripple.png" />
        </a>
      
      <script>
      $('.ShakeAndBorder2').ShakeBorder();
      </script>
          </div>
    </div>

  

      


       
    

            
	

			

