<?php error_reporting(0);?>
  <div class="col-md-12">
    <section class="services padding-bottom-70">
    <div class="contact-form">
     <div class="newfrom">
          <!--<h5>Search Bank By Category</h5>-->
          <!-- Success Msg -->
         <?php if($message)
		 {?>
		 <font color="#FF0000"; style="margin-left:200px;">
		<?php echo $message;
		 }
	?>
		 </font>
          <!-- FORM
		   <input type="submit" class="btn btn-1" id="btn_submit" value="Submit">  -->
          <form  method="post" action="<?php echo base_url();?>bank_ui/bank_search_by_cat" style="">
            <table>
               <tr>
			  <select name="bank_cat" class="input-sm" style="margin-right:10px">
                    <option>Select Bank Category</option>
                    <?php
                   foreach ($all_cat as $cat) 
                        {                  
                        ?>
                    <option value="<?php echo $cat->bank_category_id; ?>"><?php echo $cat->bank_category_name; ?></option>
                    <?php } ?>
                </select>
	<button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Start <i class="fa fa-caret-right"></i></button>
              </tr>
            </table>
          </form>
      </div>
		<link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
    <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">
		<div class="newtext"><center><strong>Bank List</strong></center></div>
                <section class="padding-bottom-10">
                </section>
	<div class="tablenn">
        <div class="tablebeinformation">
          <div class="bank_logo_area_for_table">
                <table >

  <thead>
  <tr>
    <th style="padding:5px">Bank</th>
    <th style="padding:5px" width="15%">Category</th>
    <th style="padding:5px">Head Office Address</th>
    <th style="padding:5px"width="20%">Head Office Phone Number</th>
    <th style="padding:5px" width="10%">Details View</th>
  </tr>
  </thead>
					<?php foreach ($all_bank as $row) {
					?>
                    <tr>
                    <td >
                        <?php   $a=$row->bank_logo;?>
                        <img src="<?php echo base_url().$a?>"/></br>
                        <div class="newfont"><?php echo $row->bank_name;?></div>
                        </td>
                        <td><?php echo $row->bank_category_name;?></td>
                        <td><?php echo $row->bank_office_address;?></td>
                        <td><?php echo $row->bank_phone_number;?></td>
			<td><a href="<?php echo $row->bank_website_url;?>" target="_blank">Details</a></td>
                    </tr>
                   <?php }?>
                </table>
            </div>
            </div>
	   </div>
	   </div>
	   </div>
     </div>
        </div>
      </div>
    </section>
	