  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
          <div class="newtext"><strong><center>Select Your Preferred Stock Exchange</center></strong></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
      <div class="bank_atm_wrapper">
<div class="bank_atm_logo_area">
      <a href="http://www.dsebd.org/" target="share_market">
      <img src="http://www.policymarket.com.bd/image/stock_exchange_logo/Dhaka-stock-exchange.jpg" alt="" title=""></a>
      </div>
<div class="bank_atm_logo_area">
      <a href="http://www.cse.com.bd/" target="share_market">
      <img src="http://www.policymarket.com.bd/image/stock_exchange_logo/cse-logo-s.png" alt="" title="">     
      </a>
      </div>
      </div>


  
        <iframe src= "http://www.dsebd.org/" name="share_market" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>

        </div>
      </div>
    </div>

  

      


       
    

            
	

			

