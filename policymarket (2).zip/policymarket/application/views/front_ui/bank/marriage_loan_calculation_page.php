  <?php error_reporting(0);?>

  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="newfrom1">
    <div class="from_dempsit_wrap">
      <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
        <div class="newfrom">
        <form class="common_fact" method="post" action=" ">
          <table>
          <tr>
        <td>Amount of Loan: <input type="number" min="50000" max="10000000" name="money" value="<?php echo set_value('money'); ?>" required></td></br>
          <td>Duration of Loan:  
            <select name="month">
              <option value="1" <?php echo set_select('month','1'); ?> >1</option>
              <option value="2" <?php echo set_select('month','2'); ?> >2</option>
              <option value="3" <?php echo set_select('month','3'); ?> >3</option>
              <option value="4" <?php echo set_select('month','4'); ?> >4</option>
              <option value="5" <?php echo set_select('month','5'); ?> >5</option>
              <option value="6" <?php echo set_select('month','6'); ?> >6</option>
              <option value="7" <?php echo set_select('month','7'); ?> >7</option>
              <option value="8" <?php echo set_select('month','8'); ?> >8</option>
              <option value="9" <?php echo set_select('month','9'); ?> >9</option>
              <option value="10" <?php echo set_select('month','10'); ?> >10</option>
            </select> Years
           </td> 
          <td>
          <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Start <i class="fa fa-caret-right"></i></button>       
          </td>
          </tr>
          </table>
          </form>
          </div>
          </div>
      <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

      <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
        <div class="bank_logo_area_for_table">
        <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        ?>
        <div class="newtext"><center>We Found <strong>'1'</strong> Marriage Loan, Loan Amount is <strong>'<?php echo number_format("$money",2);?>'</strong> BDT, Loan Duration is <strong>'<?php echo $month;?>'</strong> Years.</center></div>
        <section class="padding-bottom-30">
        </section>
      
      <h5>Last Update: <?php echo date("d M Y");?>. </h5> 
    
    <table>
      <thead>
        <tr>
          <th style="padding:5px" width="15%">Bank</th>
          <th style="padding:5px" width="14%">Interest Rate</th>
          <th style="padding:5px" width="17%">Total Interest to Pay</th>
          <th style="padding:5px" width="17%">Monthly Installment</th>
          <th style="padding:5px" width="14%">Processing Fees</th>
          <th style="padding:5px" width="10%">Apply</th>
          <th width="14%">Compare</th>
        </tr>
      </thead>

  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/ific_logo.jpg" alt="" /></br><div class="newfont">IFIC Bank Ltd.</div></td>
    <td><strong>16.5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.01375,($month*12)));
        $i=($money*((0.01375)+((0.01375)/($r-1))));
        $ti=(($i*$month*12)-$money);
    ?>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong>--</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  
  </table>
    </div>
      </div>
        </div>
          </div>
            </div>


  

      


	   
	

			