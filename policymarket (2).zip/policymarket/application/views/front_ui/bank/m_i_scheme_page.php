  <?php error_reporting(0);?>

  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="newfrom1">
    <div class="from_dempsit_wrap">
      <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
        <div class="newfrom">
        <form class="common_fact" method="post" action="<?php echo base_url();?>bank_ui/m_i_scheme_deposit_search">
          <table>
          <tr>
        <td>Amount of Deposit: <input type="number" min="50000" max="10000000" name="money" value="<?php echo set_value('money'); ?>" required></td></br>
          <td>Duration of Deposit:  
            <select name="month">
              <option value="2" <?php echo set_select('month','2'); ?> >2</option>
              <option value="3" <?php echo set_select('month','3'); ?> >3</option>
              <option value="4" <?php echo set_select('month','4'); ?> >4</option>
              <option value="5" <?php echo set_select('month','5'); ?> >5</option>
              <option value="6" <?php echo set_select('month','6'); ?> >6</option>
              <option value="7" <?php echo set_select('month','7'); ?> >7</option>
              <option value="8" <?php echo set_select('month','8'); ?> >8</option>
              <option value="9" <?php echo set_select('month','9'); ?> >9</option>
              <option value="10" <?php echo set_select('month','10'); ?> >10</option>
            </select> Years
           </td> 
          <td>
          <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Start <i class="fa fa-caret-right"></i></button>       
          </td>
          </tr>
          </table>
          </form>
          </div>
          </div>
      <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

      <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
       <div class="tablebdeposit">
        <div class="bank_logo_area_for_table">
        <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        ?>
        <div class="newtext"><center>We Found <strong>'14'</strong> Monthly Income Schemes, Deposit Amount is <strong>'100,000.00'</strong> BDT, Deposit Duration is <strong>'2'</strong> Years.</center></div>
        <section class="padding-bottom-30">
        </section>
      
      <h5>Last Update: <?php echo date("d M Y");?>. </h5> 
    
    <table>
      <thead>
        <tr>
          <th style="padding:5px" width="12%">Bank</th>
          <th style="padding:5px" width="14%">Interest Rate</th>
          <th style="padding:5px" width="17%">Future Amount Get</th>
          <th style="padding:5px" width="17%">Monthly Interest Get</th>
          <!-- <th style="padding:5px" width="10%">Apply</th> -->
          <th width="14%">Compare</th>
        </tr>
      </thead>

  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo1.gif" alt="" /></br><div class="newfont">The City Bank Ltd.</div></td>
    <td><strong>5%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>416.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/nrblogo.gif" alt="" /></br><div class="newfont">NRB Bank Ltd.</div></td>
    <td><strong>8%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>666.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/bank_asia_logo.gif" alt="" /></br><div class="newfont">Bank Asia Ltd.</div></td>
    <td><strong>8.4%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>700.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/ific_logo.jpg" alt="" /></br><div class="newfont">IFIC Bank Ltd.</div></td>
    <td><strong>7%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>583.33 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mdblogo.jpg" alt="" /></br><div class="newfont">Midland Bank Ltd.</div></td>
    <td><strong>8%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>666.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_71.png" alt="" /></br><div class="newfont">United Commercial Bank Ltd.</div></td>
    <td><strong>7.5%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>625.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo-ab-bank.jpg" alt="" /></br><div class="newfont">AB Bank Ltd.</div></td>
    <td><strong>8%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>666.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/ific_logo.jpg" alt="" /></br><div class="newfont">IFIC Bank Ltd.</div></td>
    <td><strong>9.5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        // $r=(pow(1.12,($month*1)));
        $i=($money*0.00675);
        // $ti=($i-$money);
    ?>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>675.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo_png.png" alt="" /></br><div class="newfont">One Bank Ltd.</div></td>
    <td><strong>7%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>583.33 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo_slogan.jpg" alt="" /></br><div class="newfont">Meghna Bank Ltd.</div></td>
    <td><strong>8.4%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>700.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mbl-logo.png" alt="" /></br><div class="newfont">Modhu Moti Bank Ltd.</div></td>
    <td><strong>9.5%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>791.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/jbl_24.jpg" alt="" /></br><div class="newfont">Jamuna Bank Ltd.</div></td>
    <td><strong>7.5%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>625.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo1.png" alt="" /></br><div class="newfont">The Farmers Bank Ltd.</div></td>
    <td><strong>10.11%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>842.50 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_61.png" alt="" /></br><div class="newfont">The Premier Bank Ltd.</div></td>
    <td><strong>8.6%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>716.67 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/nrbcb_logo.jpg" alt="" /></br><div class="newfont">NRB Commercial Bank</div></td>
    <td><strong>8.4%</strong></td>
    <td><strong>100,000.00 BDT</strong></td>
    <td><strong>700.00 BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a class="bankDepositCompare" href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  
  </table>
    </div>
     </div>
      </div>
        </div>
          </div>
            </div>
