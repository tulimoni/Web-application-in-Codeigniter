<div class="col-md-12">
  <section class="services padding-bottom-70">
    <div class="container"> 
      <!-- Heading --> 
      
    </div>
    <div class="best-services"> 
    	<div class="newtext"><strong><u>Credit Card</u></strong></div>
    
      <p>A credit card is a payment card issued to users (cardholders) as a method of payment. It allows the cardholder to pay for goods and services based on the holder's promise to pay for them.The issuer of the card (usually a bank) creates a revolving account and grants a line of credit to the cardholder, from which the cardholder can borrow money for payment to a merchant or as a cash advance.

<strong>So why late Apply Now ............   </strong><td><a href="#" class="detailForLoan"><button class="btn btn-sm" >APPLY</button></a></td></p>

       <p>A credit card is different from a charge card, where it requires the balance to be repaid in full each month. In contrast, credit cards allow the consumers a continuing balance of debt, subject to interest being charged. A credit card also differs from a cash card, which can be used like currency by the owner of the card. A credit card differs from a charge card also in that a credit card typically involves a third-party entity that pays the seller and is reimbursed by the buyer, whereas a charge card simply defers payment by the buyer until a later date.</p>
    </div>
  </section>
</div>
<div id="popUpBoxWrap"></div>
<div id="popUpBox"> <a class="close" href="#"></a>
  <?php error_reporting(0); ?>
  <div class="col-md-9">
    <section>
      <div class="container">
        <!-- Heading -->
      </div>
      <div class="best-services">

<?php error_reporting(0); ?>
<div class="col-md-9">
  <section>
    <div class="container">
      <!-- Heading -->
    </div>
    <div class="best-services">
      <?php 
$to = "shathi.emporium@gmail.com";
$subject = "This Mail from Policy Market";

$email= $_POST['email'];
$message ="Hi I am ".$_POST['name']. ". 
           Email =".$_POST['email']. ". 
           Phone = ".$_POST['phone']. ". 
           Profession= " .$_POST['profession']. ". 
           Job Experiences= ".$_POST['job_experiences']. ". 
           Monthly Income= ".$_POST['monthly_income']. "Tk." ;
$from = "From: $email";

if($email =='' || $message==''){
	echo 'Please fill out all information for Credit Card';
}else{
	mail($to, $subject, $message, $from);
}

?>
      <form id="contact-form" action="?" method="post">
        <link href="<?php echo base_url();?>front_assets/css/from.css" rel="stylesheet">
        <script src="<?php echo base_url();?>front_assets/js/from.js"></script>
        <h3>Apply for Credit Card</h3>
        <h4>Fill in the form below, and we'll get back to you within 24 hours.</h4>
        <div>
          <label> <span>Full Name: (required)</span>
          <input placeholder="Please enter your full name" type="text" tabindex="1" name="name" required autofocus>
          </label>
        </div>
        <div>
          <label> <span>Email: (required)</span>
          <input placeholder="Please enter your email address" type="email" tabindex="2" name="email" required>
          </label>
        </div>
        <div>
          <label> <span>Phone: (required)</span>
          <input placeholder="Please enter your phone number" type="tel" tabindex="3" name="phone" required>
          </label>
        </div>
        <div>
          <label> <span>Profession: (required)</span>
          <input placeholder="Please enter your Profession" type="text" tabindex="4" name="profession" required>
          </label>
        </div>
        <div>
          <label> <span>Job Experiences: (required)</span>
          <input placeholder="Please enter your Loan Expectation" type="text" tabindex="5" name="job_experiences" required>
          </label>
        </div>
        <div>
          <label> <span>Monthly Income: (required)</span>
          <input placeholder="Please enter your Loan Expectation" type="text" tabindex="6" name="monthly_income" required>
          </label>
        </div>
        <div>
          <button name="submit" type="submit" id="contact-submit">Apply For Credit Card</button>
        </div>
      </form>
    </div>
  </section>
</div>
		
		</div>
    </section>
  </div>
</div>
<script type="text/javascript">
$(document).ready(function(){	
		
    $("#popUpBoxWrap").hide();
    $("#popUpBox").hide();
    $(".detailForLoan").click(function(){
        $("#popUpBoxWrap").show();
        $("#popUpBox").show();
      });
    $("#popUpBox .close").click(function(){
        $("#popUpBoxWrap").hide();
        $("#popUpBox").hide();
      }); 	
});
</script>