  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
      <div class="newtext"><center><strong><u>Policy Related Jobs</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_jobs as $jobs) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $jobs->jobs_website_url; ?>" target="jobs">
            <img src="<?php echo base_url().$jobs->jobs_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <section class="revenues padding-top-40">
  
        <iframe src= "http://jobs.bdjobs.com/jobsearch.asp?fcatId=2&icatId=" name="jobs" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>
        </section>
        
        </div>
      </div>
    </div>

  

      


       
    

            
  

      

