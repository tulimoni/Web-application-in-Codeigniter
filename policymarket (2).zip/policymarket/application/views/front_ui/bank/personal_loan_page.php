  <?php error_reporting(0);?>

  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="newfrom1">
    <div class="from_dempsit_wrap">
    <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
          <div class="newfrom">
<form class="common_fact" method="post" action="<?php echo base_url();?>bank_ui/personal_loan_search">
           <table>
           <tr>
           <td>Amount of Loan: <input type="number" min="50000" max="10000000" name="money" value="<?php echo set_value('money'); ?>" required></td></br>
           <td>Duration of Loan:  
            <select name="month" value="<?php echo set_value('month'); ?>">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>  Years
           </td> 
       <td>
        <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();"> Start <i class="fa fa-caret-right"></i></button>
               
        </td>
            </tr>
            </table>
          </form>
        </div>
        </div>
     <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

  <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
        <div class="bank_logo_area_for_table">
  <div class="newtext">     
  <center>We Found <strong>'16'</strong> Personal Loan, Loan Amount is <strong>'100,000.00'</strong> BDT, Loan Duration is <strong>'1'</strong> Year.</center>
  </div>
  <section class="padding-bottom-30">
  </section>
  
  <h5>Last Update: <?php echo date("d M Y");?>. </h5>
  
  <table>

  <thead>
  <tr>
    <th style="padding:5px" width="15%">Bank</th>
    <th style="padding:5px" width="14%">Interest Rate</th>
    <th style="padding:5px" width="17%">Total Interest to Pay</th>
    <th style="padding:5px" width="17%">Monthly Installment</th>
    <th style="padding:5px" width="14%">Processing Fees</th>
    <th style="padding:5px" width="10%">Apply</th>
    <th width="14%">Compare</th>
  </tr>
  </thead>

  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/tbl_logo.png" alt="" /></br><div class="newfont">Trust Bank Ltd.</div></td>
    <td><strong>13%</strong></td>
    <td><strong>7,180.73 BDT</strong></td>
    <td><strong>8,931.73 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/prime_39.png" alt="" /></br><div class="newfont">Prime Bank Ltd.</div></td>
    <td><strong>14.5%</strong></td>
    <td><strong>8,027.05 BDT</strong></td>
    <td><strong>9,002.25 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/brac_bank_11.png" alt="" /></br><div class="newfont">Brac Bank Ltd.</div></td>
    <td><strong>11%</strong></td>
    <td><strong>6,057.99 BDT</strong></td>
    <td><strong>8,838.17 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo-ab-bank.jpg" alt="" /></br><div class="newfont">AB Bank Ltd.</div></td>
    <td><strong>15%</strong></td>
    <td><strong>8,309.97 BDT</strong></td>
    <td><strong>9,025.83 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/BrandNameLogo.jpg" alt="" /></br><div class="newfont">Southeast Bank Ltd.</div></td>
    <td><strong>15%</strong></td>
    <td><strong>8,309.97 BDT</strong></td>
    <td><strong>9,025.83 BDT</strong></td>
    <td><strong>NA</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/eastern-bank-ltd.gif" alt="" /></br><div class="newfont">Eastern Bank Ltd.</div></td>
    <td><strong>11%</strong></td>
    <td><strong>6,057.99 BDT</strong></td>
    <td><strong>8,838.17 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/ific_logo.jpg" alt="" /></br><div class="newfont">IFIC Bank Ltd.</div></td>
    <td><strong>15%</strong></td>
    <td><strong>8,309.97 BDT</strong></td>
    <td><strong>9,025.83 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_71.png" alt="" /></br><div class="newfont">United Commercial Bank Ltd.</div></td>
    <td><strong>14%</strong></td>
    <td><strong>7,744.54 BDT</strong></td>
    <td><strong>8,978.71 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo2.png" alt="" /></br><div class="newfont">Mutual Trust Bank Ltd.</div></td>
    <td><strong>14.5%</strong></td>
    <td><strong>8,027.05 BDT</strong></td>
    <td><strong>9,002.25 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/sibl.gif" alt="" /></br><div class="newfont">SIBL</div></td>
    <td><strong>13.5%</strong></td>
    <td><strong>7,462.43 BDT</strong></td>
    <td><strong>8,955.20 BDT</strong></td>
    <td><strong>NA</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo_png.png" alt="" /></br><div class="newfont">One Bank Ltd.</div></td>
    <td><strong>13.5%</strong></td>
    <td><strong>7,462.43 BDT</strong></td>
    <td><strong>8,955.20 BDT</strong></td>
    <td><strong>1%-2%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/Screenshot_8.png" alt="" /></br><div class="newfont">Standard Chartered Bank</div></td>
    <td><strong>13%</strong></td>
    <td><strong>7,180.73 BDT</strong></td>
    <td><strong>8,931.73 BDT</strong></td>
    <td><strong>2%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo1.gif" alt="" /></br><div class="newfont">The City Bank Ltd.</div></td>
    <td><strong>13.5%</strong></td>
    <td><strong>7,462.43 BDT</strong></td>
    <td><strong>8,955.20 BDT</strong></td>
    <td><strong>2%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/dutch_bangla.png" alt="" /></br><div class="newfont">Dutch Bangla Bank Ltd.</div></td>
    <td><strong>15%</strong></td>
    <td><strong>8,309.97 BDT</strong></td>
    <td><strong>9,025.83 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/nrblogo.gif" alt="" /></br><div class="newfont">NRB Bank Ltd.</div></td>
    <td><strong>15%</strong></td>
    <td><strong>8,309.97 BDT</strong></td>
    <td><strong>9,025.83 BDT</strong></td>
    <td><strong>1%-2%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mdblogo.jpg" alt="" /></br><div class="newfont">Midland Bank Ltd.</div></td>
    <td><strong>13.99%</strong></td>
    <td><strong>7,738.89 BDT</strong></td>
    <td><strong>8,978.24 BDT</strong></td>
    <td><strong>1%</strong></td>
    <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td>
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>

  </table>
    </div>
     </div>
      </div>
       </div>
        </div>


  

      


     
  

      