  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
      <div class="newtext"><strong><u>Remittance</u></strong></div>
      <p>A remittance is a transfer of money by a foreign worker to an individual in his or her home country. Money sent home by migrants competes with international aid as one of the largest financial inflows to developing countries. Workers' remittances are a significant part of international capital flows, especially with regard to labour-exporting countries. In 2014, $436 billion went to developing countries, setting a new record. Overall global remittances also totaled $583 billion. In 2014, Bangladesh received an estimated $15.10 billion.</p>
          <div class="newtext"><center><strong><u>Select Your Preferred Remittance Company</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_remittance as $remittance) { ?>
          <div class="bank_atm_logo_area">
            <a href="#" target="remittance">
            <img src="<?php echo base_url().$remittance->remittance_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <!--<iframe src= "#" name="remittance" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>-->
        
        </div>
      </div>
    </div>

  

      


       
    

            
	

			

