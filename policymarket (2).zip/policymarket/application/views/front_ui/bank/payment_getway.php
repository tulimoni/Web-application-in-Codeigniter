  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
      <div class="newtext"><strong><u>Payment Gateway</u></strong></div>
      <p>A payment gateway is an e-commerce application service provider service that authorizes credit card payments for e-businesses, online retailers, bricks and clicks, or traditional brick and mortar.</br>

A payment gateway facilitates the transfer of information between a payment portal (such as a website, mobile phone or interactive voice response service) and the Front End Processor or acquiring bank.</p>
          <div class="newtext"><center><strong><u>Select Your Preferred Payment Gateway Provider</u></strong></center></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_payment_getway as $payment_getway) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $payment_getway->provider_website_url; ?>" target="payment">
            <img src="<?php echo base_url().$payment_getway->provider_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
  
        <iframe src= "http://www.2c2p.com/" name="payment" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>
        <!-- <iframe src= "https://www.paypal.com/cy/webapps/mpp/home" name="payment" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe> -->

        </div>
      </div>
    </div>

  

      


       
    

            
	

			

