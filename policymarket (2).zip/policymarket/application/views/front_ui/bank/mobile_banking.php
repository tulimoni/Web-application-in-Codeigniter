  <?php error_reporting(0);?>
  <div class="col-md-12">
    
      <!--<div class="col-md-5">-->
      <div class="from_dempsit_wrap">
    <div class="contact-form">
      <div class="newtext"><strong><center>Mobile Banking Agent in BD</center></strong></div>
          <!-- Success Msg -->
         <?php if($message)
     {?>
     <font color="#FF0000"; style="margin-left:200px;">
    <?php echo $message;
     }
  ?>
     </font>
         <div class="bank_atm_wrapper"> 
          <?php 
          foreach ($all_mobile_banking as $mobile_banking) { ?>
          <div class="bank_atm_logo_area">
            <a href="<?php echo $mobile_banking->mobile_banking_website_url; ?>" target="mobile_banking">
            <img src="<?php echo base_url().$mobile_banking->mobile_banking_logo; ?>" />
          </a>
          </div>
          <?php } ?>
        </div>
        <section class="revenues padding-top-40">
  
        <iframe src= "http://www.dutchbanglabank.com/mobile-banking/home.html" name="mobile_banking" width="100%" height="1300px" style="border:1px solid #ccc;" frameborder="1" ></iframe>
        </section>
        </div>
      </div>
    </div>

  

      


       
    

            
  

      

