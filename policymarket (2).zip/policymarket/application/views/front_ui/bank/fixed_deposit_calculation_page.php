  <?php error_reporting(0);?>

  <div class="col-md-12">
      <!--<div class="col-md-5">-->
      <div class="newfrom1">
    <div class="from_dempsit_wrap">
      <div class="contact-form">
          <!--<h6>Search Your Preferred Loan Policy</h6>-->
        <div class="newfrom">
        <form class="common_fact" method="post" action=" ">
          <table>
          <tr>
        <td>Amount of Deposit: <input type="number" min="50000" max="10000000" name="money" value="<?php echo set_value('money'); ?>" required></td></br>
          <td>Duration of Deposit:  
            <select name="month">
              <option value="3" <?php echo set_select('month','3'); ?> >3</option>
              <option value="4" <?php echo set_select('month','4'); ?> >4</option>
              <option value="5" <?php echo set_select('month','5'); ?> >5</option>
              <option value="6" <?php echo set_select('month','6'); ?> >6</option>
              <option value="7" <?php echo set_select('month','7'); ?> >7</option>
              <option value="8" <?php echo set_select('month','8'); ?> >8</option>
              <option value="9" <?php echo set_select('month','9'); ?> >9</option>
              <option value="10" <?php echo set_select('month','10'); ?> >10</option>
            </select> Years
           </td> 
          <td>
          <button type="submit" value="submit" class="btn btn-1" id="btn_submit" onClick="proceed();">Start <i class="fa fa-caret-right"></i></button>       
          </td>
          </tr>
          </table>
          </form>
          </div>
          </div>
      <link href="<?php echo base_url();?>front_assets/css/table.css" rel="stylesheet">
      <link href="<?php echo base_url();?>front_assets/css/responsivetable.css" rel="stylesheet">

      <!--<center><h5>Compare Your Preferred Loan Policy</h5></center>-->
      <div class="tablenn">
       <div class="tablebfdeposit">
        <div class="bank_logo_area_for_table">
        <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        ?>
        <div class="newtext"><center>We Found <strong>'11'</strong> Fixed Deposit Schemes, Deposit Amount is <strong>'<?php echo number_format("$money",2);?>'</strong> BDT, Deposit Duration is <strong>'<?php echo $month;?>'</strong> Years.</center></div>
        <section class="padding-bottom-30">
        </section>
      
      <h5>Last Update: <?php echo date("d M Y");?>. </h5> 
    
    <table>
      <thead>
        <tr>
          <th style="padding:5px" width="12%">Bank</th>
          <th style="padding:5px" width="14%">Interest Rate</th>
          <th style="padding:5px" width="17%">Future Amount Get</th>
          <th style="padding:5px" width="17%">Total Interest Get</th>
          <!-- <th style="padding:5px" width="10%">Apply</th> -->
          <th width="14%">Compare</th>
        </tr>
      </thead>

  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/brac_bank_11.png" alt="" /></br><div class="newfont">Brac Bank Ltd.</div></td>
    <td><strong>4.75%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.0475,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/eastern-bank-ltd.gif" alt="" /></br><div class="newfont">Estern Bank Ltd.</div></td>
    <td><strong>5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.05,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo1.gif" alt="" /></br><div class="newfont">The City Bank Ltd.</div></td>
    <td><strong>5.5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.055,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/tbl_logo.png" alt="" /></br><div class="newfont">Trust Bank Ltd.</div></td>
    <td><strong>6%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.06,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/prime_39.png" alt="" /></br><div class="newfont">Prime Bank Ltd.</div></td>
    <td><strong>5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.05,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/sjibl.gif" alt="" /></br><div class="newfont">Shahjalal Islami Bank.</div></td>
    <td><strong>7%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.07,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo-ab-bank.jpg" alt="" /></br><div class="newfont">AB Bank Ltd.</div></td>
    <td><strong>7.25%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.0725,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/mbl_logo.gif" alt="" /></br><div class="newfont">Mercantile Bank Ltd.</div></td>
    <td><strong>6%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.06,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/IBBL_LOGO.png" alt="" /></br><div class="newfont">Islami Bank Bangladesh Ltd.</div></td>
    <td><strong>6.6%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.066,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/logo4.gif" alt="" /></br><div class="newfont">Al-Arafah Islami Bank Ltd.</div></td>
    <td><strong>6.5%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.065,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>
  <tr>
    <td><img src="<?php echo base_url();?>image/bank_logo/nrbcb_logo.jpg" alt="" /></br><div class="newfont">NRB Commercial Bank</div></td>
    <td><strong>7%</strong></td>
    <?php
        $money=$_POST['money'];
        $month=$_POST['month'];
        $r=(pow(1.07,($month*1)));
        $i=($money*$r);
        $ti=($i-$money);
    ?>
    <td><strong><?php echo number_format("$i",2);?> BDT</strong></td>
    <td><strong><?php echo number_format("$ti",2);?> BDT</strong></td>
    <!-- <td><?php $ab=$row->bank_loan_id; ?><a href="#" class="detailForLoan" id="<?php echo $ab; ?>">
        <button class="btn btn-sm" >APPLY</button></a></td> -->
    <td><input type="checkbox" name="products[]" class="products" 
        id="<?php echo $default->bank_loan_id; ?>"><a href="javascript:void(0)" onClick="compare();" >
        <button class="btn btn-sm" style="background-color:#0591f2;">Compare</button></a></td>
  </tr>

  </table>
    </div>
      </div>
       </div>
        </div>
          </div>
            </div>
