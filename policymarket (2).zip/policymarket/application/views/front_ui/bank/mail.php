<?php error_reporting(0); ?>
<div class="col-md-12">
  <section class="services padding-bottom-70">
    <div class="container"> 
      <!-- Heading --> 
      
    </div>
    <div class="best-services"> 
    	<?php 
$to = "sahmed.emporium@gmail.com";
$subject = "This Mail from Policy Market";

$email= $_POST['email'];
$message ="Hi I am ".$_POST['name']. ". My email is ".$_POST['email']. ". My phone no is ".$_POST['phone'] .$_POST['profession']. ". I want a loan of ".$_POST['loan_expectation']. "Tk." ;
$from = "From: $email";

if(mail($to, $subject, $message, $from)){
	echo 'Your Application has been successfully sent to Policy Market';
}else{
	echo 'Something wrong........';
}

?>

<div class="page-header">
	<h5>Apply Loan Form</h5>
</div>

<form class="form-horizontal" role="form" action="?" method="post">
	

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Full Name <span class="text-danger">*</span></label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Full Name" class="col-xs-10 col-sm-5" name="name" required />
		</div>
	</div>
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email <span class="text-danger">*</span></label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Email" class="col-xs-10 col-sm-5" name="email" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Phone No <span class="text-danger">*</span></label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Phone No" class="col-xs-10 col-sm-5" name="phone" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Profession <span class="text-danger">*</span></label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Profession" class="col-xs-10 col-sm-5" name="profession" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Loan Expectation <span class="text-danger">*</span></label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Loan Expectation" class="col-xs-10 col-sm-5" name="loan_expectation" required />
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>

    </div>
  </section>
</div>
