<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once("header.php");
?>

<!-- Content -->

<?php
if($sidebar){
	
  echo $sidebar;
	}
 echo $maincontent;

?>
  <?php include_once("footer.php"); ?>
