<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once("header_index.php");
?>
  
  <!-- Content -->
  <div id="content"> 
    
    <!-- SERVICES -->
    <!-- <section class="services padding-top-70">
      <div class="container"> 
        
        <div class="heading text-center">
          <h4>Our Services</h4>
        </div>
      </div>
      <div class="best-services"> 
      
        <div class="container">
          <ul class="row list">
          

           <li class="col-md-4" data-content="#colio_c1">
              <article class="thumb"> <a href="<?php echo base_url();?>bank_ui/bank_show"> <i class="fa fa-university"></i>
                <h5>BANK</h5>
                </a> </article>
            </li>-
        
            <li class="col-md-4" data-content="#colio_c2">
              <article class="thumb"><a href="<?php echo base_url();?>insurance_ui/insurance_show"> <i class="fa fa-codepen"></i>
                <h5>INSURANCE</h5>
                </a> </article>
            </li>
            
           
           
            <li class="col-md-4" data-content="#colio_c4">
              <article class="thumb"><a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_show"> <i class="fa fa-home"></i>
                <h5>NON BANK FINANCE</h5>
                </a> </article>
            </li>

          
            <li class="col-md-4" data-content="#colio_c3">
              <article class="thumb"><a href="<?php echo base_url();?>bank_ui/remittance"> <i class="fa fa-bar-chart"></i>
                <h5>REMITTANCE</h5>
                </a> </article>
            </li>
            
            
            <li class="col-md-4" data-content="#colio_c5">
              <article class="thumb"><a href="<?php echo base_url();?>bank_ui/payment_getway"> <i class="fa fa-money"></i>
                <h5>PAYMENT GATEWAY</h5>
                </a> </article>
            </li>
            
         
            <li class="col-md-4" data-content="#colio_c6">
              <article class="thumb"><a href="<?php echo base_url();?>bank_ui/share_market"> <i class="fa fa-line-chart"></i>
                <h5>SHARE MARKET</h5>
                </a> </article>
            </li>
          </ul>
        </div>
      </div>
    </section> -->
     

     <!-- Why Policy Market -->
    <section class="blog padding-bottom-30 padding-top-70">
      <div class="container">
        <div class="heading text-center">
          <h4>Why Policy Market</h4>
          
          <div class="heading text-center">
          <p>We just help you to take a financial decisions by comparing a lot of financial products, which we are provide to you.</p>
          <p>Compare & select best finance product for your needs.</p>
          </div>
          </div>
          <img src="<?php echo base_url();?>/front_assets/images/loan.png">
          <img src="<?php echo base_url();?>/front_assets/images/economic.png">
          <img src="<?php echo base_url();?>/front_assets/images/f_information.png">
          <img src="<?php echo base_url();?>/front_assets/images/happy_customer.png">

      </div>
    </section>
    
    <!-- BLOG -->
    <section class="blog padding-bottom-30">
      <div class="container">
        <div class="heading text-center">
          <h4>Policy Market News</h4>
        </div>
        <div class="row blog-slide">
          
          <?php 
          foreach ($all_news as $news_info) { ?>
          <div class="col-md-12 no-padding">
            <article> <img class="news-image" src="<?php echo base_url().$news_info->news_logo; ?>" alt=""> 
              <!--<div class="date"> 19 <span>MAY</span> </div>-->
              <div class="post-detail"><a href="<?php echo base_url();?>bank_ui/news_details/<?php echo $news_info->news_id?>" target="_blank" class="post-tittle"><?php echo $news_info->news_title?></a>
                <p><?php echo $news_info->news_short_details?></p>
              </div>
            </article>
          </div> 
          <?php } ?>

        </div>
      </div>
    </section>

 <?php include_once("footer_index.php"); ?>     