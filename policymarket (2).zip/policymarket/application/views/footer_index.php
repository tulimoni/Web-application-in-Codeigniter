    <section class="clients padding-top-30 padding-bottom-30">
      <div class="container"> 
        
        <div class="heading text-center">
          <!-- <h4>Our Amazing Clients</h4> -->
          <span></span> </div>
        
        <div class="single-slide">
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/1.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/2.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/3.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/4.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/5.png" alt=""></a></li>
            </ul>
          </div>
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/1.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/2.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/3.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/4.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/5.png" alt=""></a></li>
            </ul>
          </div>
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/6.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/7.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/8.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/9.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/10.png" alt=""></a></li>
            </ul>
          </div>
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/6.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/7.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/8.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/9.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive" src="<?php echo base_url();?>front_assets/images/insurance/10.png" alt=""></a></li>
            </ul>
          </div>
          <div class="item">
            <ul class="row col-5">
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/11.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/12.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/13.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/14.png" alt=""></a></li>
              <li><a href="#."><img class="img-responsive img-hgt" src="<?php echo base_url();?>front_assets/images/bank/15.png" alt=""></a></li>
            </ul>
          </div>
        </div>
      </div>
    </section> 
  </div>
  
  <!-- FOOTER -->
  <footer>
    <div class="container">
      <div class="row"> 
        
        <!-- ABOUT -->
        <div class="col-md-3 footimg"> <a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>front_assets/images/logo-footer.png"alt=""></a>
          <div class="about-foot">
            <ul>
              <!--<li><p><i class="fa fa-map-marker"></i> House #67/B,Flat #4B,Road #26(old),15/A(New)Dhanmondi, Dhaka-1209,Bangladesh.</p></li>-->
              <li>
                <p><i class="fa fa-phone"></i> (+88 01842 POLICY)</p>
              </li>
              <li>
                <p><i class="fa fa-envelope"></i>info.policymarket@gmail.com</p>
              </li>
            </ul>
          </div>
        </div>
        
        <!-- Twitter Feed -->
        <div class="col-md-3">
          <h6>Twitter Feed</h6>
          <ul class="tweet">
            <li>
              <p>Choose the best insurance Policy <a href="https://twitter.com/policy_market/status/706444270819934208" target="_blank" class="primary-color">https://twitter.com/?lang=en</a></p>
            </li>  
            
            <li>
              <p>Choose the best bank Policy <a href="https://twitter.com/policy_market/status/706444906466676736" target="_blank" class="primary-color" >https://twitter.com/?lang=en</a></p>
            </li> 
            
            <li>
              <p>Find the bank atm/branch in your preferred area <a href="https://twitter.com/policy_market/status/706445139409915904" target="_blank" class="primary-color">https://twitter.com/?lang=en</a></p>
            </li> 
            
            <li>
              <p>Find all payment gateway provide <a href="https://twitter.com/policy_market/status/706446142729400321" target="_blank" class="primary-color" >https://twitter.com/?lang=en</a></p>
            </li> 
          </ul>
        </div>
        
        <!-- Photostream -->
        <div class="col-md-3">
        <h6>Policy News Gallery</h6>
        <ul class="photo-steam">
          <?php 
          foreach ($all_news as $news_info) { ?>
          <li><a href="<?php echo base_url();?>bank_ui/news_details/<?php echo $news_info->news_id?>" target="_blank"><img class="img-responsive" 
                         src="<?php echo base_url().$news_info->news_logo; ?>" alt=""></a></li>
        <?php } ?>

        </ul>
        </div>
        
        <!-- Categories -->
        <div class="col-md-3">
        <h6>Policy Market Services</h6>
        <ul class="xlink">
          <li><a href="<?php echo base_url();?>"> Home</a> </li>
          <li><a href="<?php echo base_url();?>bank_ui/bank_show"> Bank</a> </li>
          <li><a href="<?php echo base_url();?>insurance_ui/insurance_show">Insurance</a></li>
          <li> <a href="<?php echo base_url();?>non_bank_finance_ui/non_bank_finance_show">Non Bank Finance</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/remittance">Remittance </a> </li>
          <li><a href="<?php echo base_url();?>bank_ui/payment_getway">Payment Gateway</a></li>
          <li><a href="<?php echo base_url();?>bank_ui/share_market">Share Market</a></li>
          <li> <a href="<?php echo base_url();?>bank_ui/bank_atm_locator">ATM/Branch Locator</a> </li>
        </ul>
      </div>
      </div>
    </div>
  </footer>
  
  <!-- RIGHTS -->
  <div class="rights">
    <div class="container">
      <div class="row">
        <div class="col-md-6 customfoot">
          <p> © All Rights Reserved <?php echo date("Y");?><!--<a href="http://www.emporiumtechnologyltd.com">emporiumtechnologyltd.com </a>--></p>
        </div>
        <div class="col-md-6 text-right customfoot"> <a href="<?php echo base_url();?>bank_ui/privacy_policy" target="_blank">Privacy Policy</a> <a href="<?php echo base_url();?>bank_ui/terms_conditions" target="_blank">Terms & Conditions</a> </div>
      </div>
    </div>
  </div>
  
  <!--marguee  class="navbar-fixed-bottom"-->
  <footer class="ftr_msg_cont">
    <div id="massage-bar" class="navbar-fixed-bottom">
      <div class="container">
        <div style="overflow:hidden"> <strong style="display:inline-block; color:#1076BC; width:100px; float:left">Policy News:</strong>
          <div id="features">
            <ul>
              <?php 
          foreach ($all_news as $news_info) { ?>
              <li><a href="<?php echo base_url();?>bank_ui/news_details/<?php echo $news_info->news_id?>" target="_blank">
                           <?php echo $news_info->news_title?></a></li>
              <?php } ?>
            </ul>
          </div>
        </div>
        <!--<marquee  align='middle' behavior='scroll' direction='left' scrollamount='3' onmouseover='this.stop()' onmouseout='this.start();'>
        we provide an unbiased comparison between all the top bank service policy along with product reviews to help you decide
        </marquee>--> 
      </div>
    </div>
  </footer>
</div>
<script src="<?php echo base_url();?>front_assets/js/jquery-1.11.0.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/bootstrap.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/own-menu.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.isotope.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.flexslider-min.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/owl.carousel.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.cubeportfolio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/jquery.colio.js"></script> 
<script src="<?php echo base_url();?>front_assets/js/main.js"></script> 

<script src="<?php echo base_url();?>front_assets/js/featurify.js"></script> 
<script type="text/javascript">
	$("#features").featurify();
	
	//or if you want some options
	$("#sample3").featurify({
	 directionIn : -1, // left: -1 / right: 1. Direction from where will come the next slide 
	 directionOut: -1, // left: -1 / right: 1. Direction to where will go the current slide
	 pause:2000,       // time in milleseconds between each slide
	 transition:350    // time in milleseconds that will take the sliding effect
 });
</script>
</body>
</html>