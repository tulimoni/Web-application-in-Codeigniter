<?php
$result= array();
$result= $all_share_market;
echo  json_encode($result);
?>
