<?php
$result= array();
$result= $all_remittance;
echo  json_encode($result);
?>
