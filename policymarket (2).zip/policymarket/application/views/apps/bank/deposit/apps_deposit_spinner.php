<?php		
    /*?>$result = array();
	while($row = mysqli_fetch_array($res)){
	$rashid= array('user_id'=>$row['id'],'name'=>$row['name'],'email'=>$row['email']);
 
	array_push($result,$rashid);
    
	}
       
	$a= json_encode(array("banks"=>$result));

	echo urldecode(str_replace("\\","",$a));<?php */
	//$result= array();
	
	$result= $spinncontent['all_bank_deposit'];

	
	/*echo '<pre>';
	print_r($result);
	echo '</pre>';*/
	
	echo  json_encode($result);

	//print_r($all_test);
	//foreach ($all_test as $news_info) { ?> 
    
    <h4><?php //echo $news_info->diposit_name; ?></h4>
	
	<?php //} ?>