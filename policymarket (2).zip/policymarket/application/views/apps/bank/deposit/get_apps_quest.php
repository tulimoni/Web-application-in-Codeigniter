<?php		
	$result= $questResults;
	/*echo '<pre>';
	print_r($questResult);
	echo '</pre>';*/
	/*echo '<pre>';
	print_r($questResults);
	echo '</pre>';*/
	echo  json_encode($result);
	
?> 
