<?php		
	$result= $spinncontent['all_bank_deposit_duration'];
	/*echo '<pre>';
	print_r($result);
	echo '</pre>';*/
	echo  json_encode($result);
?>
