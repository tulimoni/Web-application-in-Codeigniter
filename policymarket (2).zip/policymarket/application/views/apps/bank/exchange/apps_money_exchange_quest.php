<?php
$result= array();
 
 $result= $exchangeResults;
 //$result= $all_bank_deposit;
 //$result= $all_bank_deposit_name;
 //$result= $all_bank_deposit_duration;
 
 //echo json_encode($all_test);
 //echo $default_deposit->bank_logo;
 
 //$default_deposit= array('bank_logo'=>'test');
 //foreach($default_deposit as $vx){ echo base_url().$vx->bank_logo.'<br>'; }
 /*echo '<pre>';
 print_r($default_deposit);
 echo '</pre>';*/
 echo  json_encode($result);
?>
