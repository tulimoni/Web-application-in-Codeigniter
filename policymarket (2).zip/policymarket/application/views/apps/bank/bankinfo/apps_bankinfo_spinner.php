<?php
$result= array();
$result= $all_cat;
echo  json_encode($result);
?>
