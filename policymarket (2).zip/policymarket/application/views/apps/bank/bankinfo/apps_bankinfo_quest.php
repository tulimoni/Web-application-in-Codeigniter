<?php
$result= array();
$result= $all_bank;
echo  json_encode($result);
?>
