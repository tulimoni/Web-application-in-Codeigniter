<?php		
	$result= $all_loan_cat;
	/*echo '<pre>';
	print_r($result);
	echo '</pre>';*/
	echo  json_encode($result);
 ?> 
