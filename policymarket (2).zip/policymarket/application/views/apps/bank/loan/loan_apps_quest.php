<?php		
	$result= $loanQuestResults;
	/*echo '<pre>';
	print_r($loanQuestResults);
	echo '</pre>';*/
	echo  json_encode($result);
	
?> 
