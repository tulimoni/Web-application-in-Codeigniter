<?php
$result= array();
$result= $all_payment_getway;
echo  json_encode($result);
?>
