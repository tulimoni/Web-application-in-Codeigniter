<div class="page-header">
	<h1>
		Add Bank Loan Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>bank_super_admin/save_bank_loan" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Name </label>

		<div class="col-sm-9">
		<select name="bank_id">
            <option>Select Bank Name-------</option>
            <?php
            foreach($all_published_bank_category_id as $v_bank_id)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_id->bank_id;?>"><?php echo $v_bank_id->bank_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Loan Category Name </label>

		<div class="col-sm-9">
		<select name="bank_loan_category_id">
            <option>Select Category-------</option>
            <?php
            foreach($all_published_bank_loan_category_id as $v_bank_loan_category)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_loan_category->bank_loan_category_id;?>"><?php echo $v_bank_loan_category->bank_loan_category_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Loan Name </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Loan Name" class="col-xs-10 col-sm-5" name="bank_loan_name" required />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Duration </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Bank Loan Duration" class="col-xs-10 col-sm-5" name="bank_loan_duration" required />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Interest Rate </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Bank Loan Interest Rate" class="col-xs-10 col-sm-5" name="bank_loan_interest_rate" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Range </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Bank Loan Range" class="col-xs-10 col-sm-5" name="bank_loan_range" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Monthly Installment </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Monthly Installment" class="col-xs-10 col-sm-5" name="monthly_installment" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Processing Fees </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Bank Loan Processing Fees" class="col-xs-10 col-sm-5" name="bank_loan_processing_fees" required />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Customer Segment</label>
		<div class="col-sm-9">
		<textarea id="form-field-1" placeholder="Customer Segment" class="col-xs-10 col-sm-5" name="customer_segment"> </textarea>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Maximum Term Bank Loan </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Maximum Term Bank Loan" class="col-xs-10 col-sm-5" name="maximum_term_bank_loan" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Eligibility </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Eligibility" class="col-xs-10 col-sm-5" name="eligibility"> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>