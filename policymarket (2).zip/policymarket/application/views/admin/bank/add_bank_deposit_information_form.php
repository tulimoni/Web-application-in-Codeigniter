<div class="page-header">
	<h1>
		Add Bank Deposit Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" action="<?php echo base_url();?>bank_super_admin/save_bank_deposit_information" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Name </label>

		<div class="col-sm-9">
		<select name="bank_id">
            <option>Select Bank Name-------</option>
            <?php
            foreach($all_published_bank_category_id as $v_bank_id)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_id->bank_id;?>"><?php echo $v_bank_id->bank_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Name" class="col-xs-10 col-sm-5" name="diposit_name" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Type </label>

		<div class="col-sm-9">
		<select name="diposit_type" required>
            <option>Select Deposit Type</option>
            <option>Monthly</option>
            <option>Yearly</option>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Duration </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Duration" class="col-xs-10 col-sm-5" name="diposit_duration" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Amount </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Amount" class="col-xs-10 col-sm-5" name="diposit_amount" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Interest Rate </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Deposit Interest Rate" class="col-xs-10 col-sm-5" name="diposit_interest_rate" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Monthly Benefit </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Deposit Monthly Benefit" class="col-xs-10 col-sm-5" name="diposit_monthy_benefit" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Final Amount </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Final Amount" class="col-xs-10 col-sm-5" name="final_amount" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Feature </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Deposit Feature" class="col-xs-10 col-sm-5" name="bank_feature"> </textarea>

		</div>
	</div>
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>							
</form>