<div class="page-header">
	<h1>
		Add Bank Triple Benefit Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>bank_super_admin/save_bank_triple_benefit" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Name </label>

		<div class="col-sm-9">
		<select name="bank_id">
            <option>Select Bank Name-------</option>
            <?php
            foreach($all_published_bank_category_id as $v_bank_id)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_id->bank_id;?>"><?php echo $v_bank_id->bank_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Interest Rate </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Interest Rate" class="col-xs-10 col-sm-5" name="bank_triple_benefit_i_r" required />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Minimum Deposit </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Minimum Deposit" class="col-xs-10 col-sm-5" name="bank_triple_benefit_m_d" required />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Duration of Double </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Duration of Double" class="col-xs-10 col-sm-5" name="bank_triple_benefit_duration" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Last Checked Date </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Last Checked Date" class="col-xs-10 col-sm-5" name="bank_triple_benefit_lcd" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>