<div class="page-header">
	<h1>
		Edit Bank Loan Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_bank_loan_information" class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>bank_super_admin/update_bank_loan_information" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Name </label>

		<div class="col-sm-9">
		<select name="bank_id">
            <option>Select Bank Name-------</option>
            <?php
            foreach($all_published_bank_category_id as $v_bank_id)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_id->bank_id;?>"><?php echo $v_bank_id->bank_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Loan Category Name </label>

		<div class="col-sm-9">
		<select name="bank_loan_category_id">
            <option>Select Category-------</option>
            <?php
            foreach($all_published_bank_loan_category_id as $v_bank_loan_category)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_loan_category->bank_loan_category_id;?>"><?php echo $v_bank_loan_category->bank_loan_category_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Loan Name </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Loan Name" class="col-xs-10 col-sm-5" name="bank_loan_name" required value="<?php echo$bank_loan_information_info->bank_loan_name?>" />
			<input type="hidden" id="form-field-1" placeholder="Bank Loan Id" class="col-xs-10 col-sm-5" name="bank_loan_id" required value="<?php echo$bank_loan_information_info->bank_loan_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Duration </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Bank Loan Duration" class="col-xs-10 col-sm-5" name="bank_loan_duration" required value="<?php echo$bank_loan_information_info->bank_loan_duration?>" />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Interest Rate </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Bank Loan Interest Rate" class="col-xs-10 col-sm-5" name="bank_loan_interest_rate" required value="<?php echo$bank_loan_information_info->bank_loan_interest_rate?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Range </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Bank Loan Range" class="col-xs-10 col-sm-5" name="bank_loan_range" required value="<?php echo$bank_loan_information_info->bank_loan_range?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Monthly Installment </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Monthly Installment" class="col-xs-10 col-sm-5" name="monthly_installment" required value="<?php echo$bank_loan_information_info->monthly_installment?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Bank Loan Processing Fees </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Bank Loan Processing Fees" class="col-xs-10 col-sm-5" name="bank_loan_processing_fees" required value="<?php echo$bank_loan_information_info->bank_loan_processing_fees?>" />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Customer Segment</label>
		<div class="col-sm-9">
		<textarea id="form-field-1" placeholder="Customer Segment" class="col-xs-10 col-sm-5" name="customer_segment"><?php echo$bank_loan_information_info->customer_segment?> </textarea>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Maximum Term Bank Loan </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Maximum Term Bank Loan" class="col-xs-10 col-sm-5" name="maximum_term_bank_loan" required value="<?php echo$bank_loan_information_info->maximum_term_bank_loan?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Eligibility </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Eligibility" class="col-xs-10 col-sm-5" name="eligibility"><?php echo$bank_loan_information_info->eligibility?> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>

<script type="text/javascript">
document.forms['edit_bank_loan_information'].elements['publication_status'].value='<?php echo $bank_loan_information_info->publication_status?>';
document.forms['edit_bank_loan_information'].elements['bank_id'].value='<?php echo $bank_loan_information_info->bank_id?>';
document.forms['edit_bank_loan_information'].elements['bank_loan_category_id'].value='<?php echo $bank_loan_information_info->bank_loan_category_id?>';
</script>