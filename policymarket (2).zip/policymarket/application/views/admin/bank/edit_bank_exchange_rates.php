<div class="page-header">
	<h1>
		Edit Bank Exchange Rates Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_bank_exchange_rates" class="form-horizontal" role="form" action="<?php echo base_url();?>bank_super_admin/update_bank_exchange_rates" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Bank Name </label>

		<div class="col-sm-9">
		<select name="bank_id">
            <option>Select Bank Name-------</option>
            <?php
            foreach($all_published_bank_category_id as $v_bank_id)
                {
                                    
                ?>
            <option value="<?php echo $v_bank_id->bank_id;?>"><?php echo $v_bank_id->bank_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Currency Type </label>

		<div class="col-sm-9">
		<select name="currency_type" required>
            <option>Select Currency Type</option>
            <option>USD</option>
            <option>EURO</option>
            <option>GBP</option>
            <option>QATARI RIYAL</option>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Selling [BDT] Rates </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Selling [BDT] Rates" class="col-xs-10 col-sm-5" name="selling" required value="<?php echo $bank_exchange_rates_info->selling?>" />
		<input type="hidden" id="form-field-1" placeholder="Bank Exchange Rates Id" class="col-xs-10 col-sm-5" name="bank_exchange_rates_id" required value="<?php echo$bank_exchange_rates_info->bank_exchange_rates_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Buying [BDT] Rates </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Buying [BDT] Rates" class="col-xs-10 col-sm-5" name="buying" required value="<?php echo $bank_exchange_rates_info->buying?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> BC [BDT] Rates </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="BC [BDT] Rates" class="col-xs-10 col-sm-5" name="bc" required value="<?php echo $bank_exchange_rates_info->bc?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> TT Clean [BDT] Rates </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="TT Clean [BDT] Rates" class="col-xs-10 col-sm-5" name="tt_clean" required value="<?php echo $bank_exchange_rates_info->tt_clean?>"/>
		</div>
	</div>
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>

<script type="text/javascript">
document.forms['edit_bank_exchange_rates'].elements['publication_status'].value='<?php echo $bank_exchange_rates_info->publication_status?>';
document.forms['edit_bank_exchange_rates'].elements['bank_id'].value='<?php echo $bank_exchange_rates_info->bank_id?>';
document.forms['edit_bank_exchange_rates'].elements['currency_type'].value='<?php echo $bank_exchange_rates_info->currency_type?>';
</script>