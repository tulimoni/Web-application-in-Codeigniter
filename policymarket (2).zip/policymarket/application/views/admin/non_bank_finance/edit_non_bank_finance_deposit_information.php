<div class="page-header">
	<h1>
		Edit Non Bank Finance Deposit Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_non_bank_finance_deposit_information" class="form-horizontal" role="form" action="<?php echo base_url();?>non_bank_finance_super_admin/update_non_bank_finance_deposit_information" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Non Bank Finance Name </label>

		<div class="col-sm-9">
		<select name="non_bank_finance_id">
            <option>Select Non Bank Finance Name-------</option>
            <?php
            foreach($all_published_non_bank_finance_category_id as $v_non_bank_finance_id)
                {
                                    
                ?>
            <option value="<?php echo $v_non_bank_finance_id->non_bank_finance_id;?>"><?php echo $v_non_bank_finance_id->non_bank_finance_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Name" class="col-xs-10 col-sm-5" name="diposit_name" required value="<?php echo $non_bank_finance_deposit_information_info->diposit_name?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Type </label>

		<div class="col-sm-9">
		<select name="diposit_type" required>
            <option>Select Deposit Type</option>
            <option>Monthly</option>
            <option>Yearly</option>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Duration </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Duration" class="col-xs-10 col-sm-5" name="diposit_duration" required value="<?php echo$non_bank_finance_deposit_information_info->diposit_duration?>" />
		<input type="hidden" id="form-field-1" placeholder="Non Bank Finance Deposit Id" class="col-xs-10 col-sm-5" name="non_bank_finance_diposit_id" required value="<?php echo$non_bank_finance_deposit_information_info->non_bank_finance_diposit_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Amount </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Deposit Amount" class="col-xs-10 col-sm-5" name="diposit_amount" required value="<?php echo$non_bank_finance_deposit_information_info->diposit_amount?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Interest Rate </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Deposit Interest Rate" class="col-xs-10 col-sm-5" name="diposit_interest_rate" required value="<?php echo$non_bank_finance_deposit_information_info->diposit_interest_rate?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Monthy Benefit </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Deposit Monthy Benefit" class="col-xs-10 col-sm-5" name="diposit_monthy_benefit" required value="<?php echo$non_bank_finance_deposit_information_info->diposit_monthy_benefit?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Final Amount </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Final Amount" class="col-xs-10 col-sm-5" name="final_amount" required value="<?php echo$non_bank_finance_deposit_information_info->final_amount?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Feature </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Deposit Feature" class="col-xs-10 col-sm-5" name="non_bank_finance_feature"> <?php echo$non_bank_finance_deposit_information_info->non_bank_finance_feature?> </textarea>

		</div>
	</div>
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>

<script type="text/javascript">
document.forms['edit_non_bank_finance_deposit_information'].elements['publication_status'].value='<?php echo $non_bank_finance_deposit_information_info->publication_status?>';
document.forms['edit_non_bank_finance_deposit_information'].elements['non_bank_finance_id'].value='<?php echo $non_bank_finance_deposit_information_info->non_bank_finance_id?>';
document.forms['edit_non_bank_finance_deposit_information'].elements['diposit_type'].value='<?php echo $non_bank_finance_deposit_information_info->diposit_type?>';
</script>