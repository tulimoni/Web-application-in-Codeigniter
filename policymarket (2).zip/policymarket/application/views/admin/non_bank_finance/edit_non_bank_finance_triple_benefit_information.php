<div class="page-header">
	<h1>
		Edit Non Bank Finance Triple Benefit Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_non_bank_finance_triple_benefit_information" class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>non_bank_finance_super_admin/update_non_bank_finance_triple_benefit_information" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Non Bank Finance Name </label>

		<div class="col-sm-9">
		<select name="non_bank_finance_id">
            <option>Select Non Bank Finance Name-------</option>
            <?php
            foreach($all_published_non_bank_finance_category_id as $v_non_bank_finance_id)
                {
                                    
                ?>
            <option value="<?php echo $v_non_bank_finance_id->non_bank_finance_id;?>"><?php echo $v_non_bank_finance_id->non_bank_finance_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Interest Rate </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Interest Rate" class="col-xs-10 col-sm-5" name="non_bank_finance_triple_benefit_i_r" required value="<?php echo$non_bank_finance_triple_benefit_information_info->non_bank_finance_triple_benefit_i_r?>" />
			<input type="hidden" id="form-field-1" placeholder="Non Bank Finance Triple Benefit Id" class="col-xs-10 col-sm-5" name="non_bank_finance_triple_benefit_id" required value="<?php echo$non_bank_finance_triple_benefit_information_info->non_bank_finance_triple_benefit_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Minimum Deposit </label>

		<div class="col-sm-9">
			<input type="tel" id="form-field-1" placeholder="Minimum Deposit" class="col-xs-10 col-sm-5" name="non_bank_finance_triple_benefit_m_d" required value="<?php echo$non_bank_finance_triple_benefit_information_info->non_bank_finance_triple_benefit_m_d?>" />

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Duration of Double </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Duration of Double" class="col-xs-10 col-sm-5" name="non_bank_finance_triple_benefit_duration" required value="<?php echo$non_bank_finance_triple_benefit_information_info->non_bank_finance_triple_benefit_duration?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Last Checked Date </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Last Checked Date" class="col-xs-10 col-sm-5" name="non_bank_finance_triple_benefit_lcd" required value="<?php echo$non_bank_finance_triple_benefit_information_info->non_bank_finance_triple_benefit_lcd?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>

<script type="text/javascript">
document.forms['edit_non_bank_finance_triple_benefit_information'].elements['publication_status'].value='<?php echo $non_bank_finance_triple_benefit_information_info->publication_status?>';
document.forms['edit_non_bank_finance_triple_benefit_information'].elements['non_bank_finance_id'].value='<?php echo $non_bank_finance_triple_benefit_information_info->non_bank_finance_id?>';
</script>