<div class="page-header">
	<h1>
		Add Insurance Loan Category Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" action="<?php echo base_url();?>insurance_super_admin/save_insurance_loan_category" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Insurance Loan Category Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Insurance Loan Category Name" class="col-xs-10 col-sm-5" name="insurance_loan_category_name" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Insurance Loan Category Description </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Insurance Loan Category Description" class="col-xs-10 col-sm-5" name="insurance_loan_category_description"> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>