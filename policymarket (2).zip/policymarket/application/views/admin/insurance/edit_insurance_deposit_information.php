<div class="page-header">
	<h1>
		Edit Insurance Deposit Information
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_insurance_deposit_information" class="form-horizontal" role="form" action="<?php echo base_url();?>insurance_super_admin/update_insurance_deposit_information" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Insurance Name </label>

		<div class="col-sm-9">
		<select name="insurance_id">
            <option>Select Insurance Name-------</option>
            <?php
            foreach($all_published_insurance_category_id as $v_insurance_id)
                {
                                    
                ?>
            <option value="<?php echo $v_insurance_id->insurance_id;?>"><?php echo $v_insurance_id->insurance_name;?></option>
            <?php } ?>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Diposit Name" class="col-xs-10 col-sm-5" name="diposit_name" required value="<?php echo $insurance_deposit_information_info->diposit_name?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Type </label>

		<div class="col-sm-9">
		<select name="diposit_type" required>
            <option>Select Diposit Type</option>
            <option>Monthly</option>
            <option>Yearly</option>
        </select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Duration </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Diposit Duration" class="col-xs-10 col-sm-5" name="diposit_duration" required value="<?php echo$insurance_deposit_information_info->diposit_duration?>" />
		<input type="hidden" id="form-field-1" placeholder="Insurance Deposit Id" class="col-xs-10 col-sm-5" name="insurance_diposit_id" required value="<?php echo$insurance_deposit_information_info->insurance_diposit_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Amount </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Diposit Amount" class="col-xs-10 col-sm-5" name="diposit_amount" required value="<?php echo$insurance_deposit_information_info->diposit_amount?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Interest Rate </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Diposit Interest Rate" class="col-xs-10 col-sm-5" name="diposit_interest_rate" required value="<?php echo$insurance_deposit_information_info->diposit_interest_rate?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Diposit Monthy Benefit </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Diposit Monthy Benefit" class="col-xs-10 col-sm-5" name="diposit_monthy_benefit" required value="<?php echo$insurance_deposit_information_info->diposit_monthy_benefit?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Final Amount </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Final Amount" class="col-xs-10 col-sm-5" name="final_amount" required value="<?php echo$insurance_deposit_information_info->final_amount?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Deposit Feature </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Deposit Feature" class="col-xs-10 col-sm-5" name="insurance_feature"> <?php echo$insurance_deposit_information_info->insurance_feature?> </textarea>

		</div>
	</div>
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>								
</form>

<script type="text/javascript">
document.forms['edit_insurance_deposit_information'].elements['publication_status'].value='<?php echo $insurance_deposit_information_info->publication_status?>';
document.forms['edit_insurance_deposit_information'].elements['insurance_id'].value='<?php echo $insurance_deposit_information_info->insurance_id?>';
document.forms['edit_insurance_deposit_information'].elements['diposit_type'].value='<?php echo $insurance_deposit_information_info->diposit_type?>';
</script>