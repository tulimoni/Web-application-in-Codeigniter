<div class="page-header">
	<h1>
		Edit Mobile Banking Company Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_mobile_banking_name" class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>mobile_banking_super_admin/update_mobile_banking_name" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Mobile Banking Company Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Mobile Banking Company Name" class="col-xs-10 col-sm-5" name="mobile_banking_name" required value="<?php echo$mobile_banking_name_info->mobile_banking_name?>" />
		<input type="hidden" id="form-field-1" placeholder="Mobile Banking Company Id" class="col-xs-10 col-sm-5" name="mobile_banking_id" required value="<?php echo$mobile_banking_name_info->mobile_banking_id?>" />
		</div>
	</div>


	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Mobile Banking Company Website Url </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Mobile Banking Company Website Url" class="col-xs-10 col-sm-5" name="mobile_banking_website_url" required value="<?php echo$mobile_banking_name_info->mobile_banking_website_url?>" />
		</div>
	</div>

	<?php 
    if($mobile_banking_name_info->mobile_banking_logo)
    {
    ?>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Mobile Banking Company Logo </label>

		<div class="col-sm-9">
		<img src='<?php echo base_url().$mobile_banking_name_info->mobile_banking_logo;?>'/>
		<a href="<?php echo base_url();?>mobile_banking_super_admin/delete_mobile_banking_logo/<?php echo $mobile_banking_name_info->mobile_banking_id?>">Delete Image</a>
		</div>

	<?php 
       }
    else
       {
       ?>
	<div class="form-group">
	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Mobile Banking Company Logo </label>
	<div class="col-sm-9">
		<input type="file" id="form-field-1" placeholder="Mobile Banking Company Logo" class="col-xs-10 col-sm-5" name="mobile_banking_logo" value="mobile_banking_logo" required />
		</div>
		<?php } ?>
	</div>

	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>
</div>

<script type="text/javascript">
document.forms['edit_mobile_banking_name'].elements['publication_status'].value='<?php echo $mobile_banking_name_info->publication_status;?>';
</script>

