<div class="page-header">
	<h1>
		Add Brokerage House Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>stock_exchange_super_admin/save_brokerage_house_name" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Brokerage House Name" class="col-xs-10 col-sm-5" name="brokerage_house_name" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Membership No </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Membership No" class="col-xs-10 col-sm-5" name="membership_no" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Brokerage House Office Address </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Brokerage House Office Address" class="col-xs-10 col-sm-5" name="brokerage_house_office_address"> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Website Url </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Brokerage House Website Url" class="col-xs-10 col-sm-5" name="brokerage_house_website_url" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Phone Number </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Brokerage House Phone Number" class="col-xs-10 col-sm-5" name="brokerage_house_phone_number" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Logo </label>

		<div class="col-sm-9">
		<input type="file" id="form-field-1" placeholder="Brokerage House Logo" class="col-xs-10 col-sm-5" name="brokerage_house_logo" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>