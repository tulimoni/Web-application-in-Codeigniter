<div class="page-header">
	<h1>
		Edit Brokerage House Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_brokerage_house_name" class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>stock_exchange_super_admin/update_brokerage_house_name" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Brokerage House Name" class="col-xs-10 col-sm-5" name="brokerage_house_name" required value="<?php echo$brokerage_house_name_info->brokerage_house_name?>" />
		<input type="hidden" id="form-field-1" placeholder="Brokerage House Id" class="col-xs-10 col-sm-5" name="brokerage_house_id" required value="<?php echo$brokerage_house_name_info->brokerage_house_id?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Membership No </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Membership No" class="col-xs-10 col-sm-5" name="membership_no" required value="<?php echo$brokerage_house_name_info->membership_no?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Office Address </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="Brokerage House Office Address" class="col-xs-10 col-sm-5" name="brokerage_house_office_address"> <?php echo$brokerage_house_name_info->brokerage_house_office_address?> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Brokerage House Website Url </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Brokerage House Website Url" class="col-xs-10 col-sm-5" name="brokerage_house_website_url" required value="<?php echo$brokerage_house_name_info->brokerage_house_website_url?>" />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Phone Number </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Brokerage House Phone Number" class="col-xs-10 col-sm-5" name="brokerage_house_phone_number" required value="<?php echo$brokerage_house_name_info->brokerage_house_phone_number?>" />
		</div>
	</div>

	<?php 
    if($brokerage_house_name_info->brokerage_house_logo)
    {
    ?>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Logo </label>

		<div class="col-sm-9">
		<img src='<?php echo base_url().$brokerage_house_name_info->brokerage_house_logo;?>'/>
		<a href="<?php echo base_url();?>stock_exchange_super_admin/delete_brokerage_house_logo/<?php echo $brokerage_house_name_info->brokerage_house_id?>">Delete Image</a>
		</div>

	<?php 
       }
    else
       {
       ?>
	<div class="form-group">
	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Brokerage House Logo </label>
	<div class="col-sm-9">
		<input type="file" id="form-field-1" placeholder="Brokerage House Logo" class="col-xs-10 col-sm-5" name="brokerage_house_logo" value="brokerage_house_logo" required />
		</div>
		<?php } ?>
	</div>

	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>
</div>

<script type="text/javascript">
document.forms['edit_brokerage_house_name'].elements['publication_status'].value='<?php echo $brokerage_house_name_info->publication_status;?>';
</script>

