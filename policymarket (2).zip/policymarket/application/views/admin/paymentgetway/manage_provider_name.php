<div class="page-header">
	<h1>
		Manage Providers Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		
		</small>
	</h1>
		</div><!-- /.page-header -->

			<div class="row">
			<div class="col-xs-12">

<div class="row">
	<div class="col-xs-12">
		<table id="simple-table" class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
				<th class="center">
				<label class="pos-rel">
					<input type="checkbox" class="ace" />
					<span class="lbl"></span>
				</label>
				</th>
				
				<th>Providers Id</th>
				<th>Providers Name</th>
				<th class="hidden-480">Publication Status</th>
				<th>Actions</th>
				</tr>
			</thead>

			<tbody>
				<?php
                foreach($all_provider_name as $v_provider_name)
                {
            	?>

				<tr>
				<td class="center">
				<label class="pos-rel">
				<input type="checkbox" class="ace" />
				<span class="lbl"></span>
				</label>
				</td>

				<td><?php echo $v_provider_name->provider_id?></td>
				<td><?php echo $v_provider_name->provider_name?></td>
				<td class="hidden-480"><span class="label label-sm label-warning"><?php  
                    if($v_provider_name->publication_status==1)
                    {
                        echo 'Published';
                    }
                    else{
                        echo 'Unpublished';
                    }
                ?>
            	</span></td>
				<td>
				<div class="hidden-sm hidden-xs btn-group">

					<?php
                        if($v_provider_name->publication_status==0)
                        {
                    ?>
					
					<a class="btn btn-xs btn-success" href="<?php echo base_url();?>provider_super_admin/published_provider_name/<?php echo $v_provider_name->provider_id?>" title="Published">
						<i class="ace-icon fa fa-arrow-up bigger-120"></i> 
					
					</a>

					<?php }
                        
                        else{
                        ?>

                    <a class="btn btn-xs btn-danger" href="<?php echo base_url();?>provider_super_admin/unpublished_provider_name/<?php echo $v_provider_name->provider_id?>" title="Unpublished">
						<i class="ace-icon fa fa-arrow-down bigger-120"></i>
					</a>

                        <?php } ?>

					<a class="btn btn-xs btn-info" href="<?php echo base_url();?>provider_super_admin/edit_provider_name/<?php echo $v_provider_name->provider_id?>" title="Edit">
						<i class="ace-icon fa fa-pencil bigger-120"></i>
					</a>

					<a class="btn btn-xs btn-danger" href="<?php echo base_url();?>provider_super_admin/delete_provider_name/<?php echo $v_provider_name->provider_id?>" title="Delete" onclick="return check_delete();">
						<i class="ace-icon fa fa-trash-o bigger-120"></i>
					</a>

					</div>

					<div class="hidden-md hidden-lg">
					<div class="inline pos-rel">
					<button class="btn btn-minier btn-primary dropdown-toggle" data-toggle="dropdown" data-position="auto">
						<i class="ace-icon fa fa-cog icon-only bigger-110"></i>
					</button>

					<ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
					<li>
					<a href="#" class="tooltip-info" data-rel="tooltip" title="View">
					<span class="blue">
					<i class="ace-icon fa fa-search-plus bigger-120"></i>
					</span>
					</a>
					</li>

					<li>
					<a href="#" class="tooltip-success" data-rel="tooltip" title="Edit">
						<span class="green">
							<i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
						</span>
					</a>
					</li>

					<li>
					<a href="#" class="tooltip-error" data-rel="tooltip" title="Delete">
					<span class="red">
						<i class="ace-icon fa fa-trash-o bigger-120"></i>
					</span>
					</a>
						</li>
							</ul>
								</div>
									</div>
									</td>

								<?php } ?>
										</tbody>
										

										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->