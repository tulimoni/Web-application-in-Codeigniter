<div class="page-header">
	<h1>
		Edit Providers Name
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form name="edit_provider_name" class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>provider_super_admin/update_provider_name" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Providers Name </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="Providers Name" class="col-xs-10 col-sm-5" name="provider_name" required value="<?php echo$provider_name_info->provider_name?>" />
		<input type="hidden" id="form-field-1" placeholder="Providers Id" class="col-xs-10 col-sm-5" name="provider_id" required value="<?php echo$provider_name_info->provider_id?>" />
		</div>
	</div>


	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">Providers Website Url </label>

		<div class="col-sm-9">
		<input type="tel" id="form-field-1" placeholder="Providers Website Url" class="col-xs-10 col-sm-5" name="provider_website_url" required value="<?php echo$provider_name_info->provider_website_url?>" />
		</div>
	</div>

	<?php 
    if($provider_name_info->provider_logo)
    {
    ?>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Providers Logo </label>

		<div class="col-sm-9">
		<img src='<?php echo base_url().$provider_name_info->provider_logo;?>'/>
		<a href="<?php echo base_url();?>provider_super_admin/delete_provider_logo/<?php echo $provider_name_info->provider_id?>">Delete Image</a>
		</div>

	<?php 
       }
    else
       {
       ?>
	<div class="form-group">
	<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Providers Logo </label>
	<div class="col-sm-9">
		<input type="file" id="form-field-1" placeholder="Providers Logo" class="col-xs-10 col-sm-5" name="provider_logo" value="provider_logo" required />
		</div>
		<?php } ?>
	</div>

	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Update
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>
</div>

<script type="text/javascript">
document.forms['edit_provider_name'].elements['publication_status'].value='<?php echo $provider_name_info->publication_status;?>';
</script>

