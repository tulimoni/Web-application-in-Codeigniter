<div class="page-header">
	<h1>
		Add News
		<small>
		<i class="ace-icon fa fa-angle-double-right"></i>
		<?php
            $msg=$this->session->userdata('message');
            if($msg)
            {
                echo $msg;
                $this->session->unset_userdata('message');
            }
        ?>
		</small>
		</h1>
</div>

<form class="form-horizontal" role="form" enctype="multipart/form-data" action="<?php echo base_url();?>news_super_admin/save_news_title" method="post">
	
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> News Title </label>

		<div class="col-sm-9">
		<input type="text" id="form-field-1" placeholder="News Title" class="col-xs-10 col-sm-5" name="news_title" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">News Short Description </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="News Short Description" class="col-xs-10 col-sm-5" name="news_short_details"> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1">News Details Description </label>

		<div class="col-sm-9">
			<textarea id="form-field-1" placeholder="News Details Description" class="col-xs-10 col-sm-5" name="news_details"> </textarea>

		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> News Image </label>

		<div class="col-sm-9">
		<input type="file" id="form-field-1" placeholder="News Image" class="col-xs-10 col-sm-5" name="news_logo" required />
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Publication Status </label>

		<div class="col-sm-9">
		<select name="publication_status">
            <option>Select Publication Status</option>
            <option value="1">Published</option>
            <option value="0">Un Published</option>
        </select>
		
		
		</div>
	</div>

	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		<button class="btn btn-info" type="submit">
		<i class="ace-icon fa fa-check bigger-110"></i>
			Submit
		</button>

		&nbsp; &nbsp; &nbsp;
		<button class="btn" type="reset">
		<i class="ace-icon fa fa-undo bigger-110"></i>
		Reset
		</button>
	</div>
	</div>

									
</form>