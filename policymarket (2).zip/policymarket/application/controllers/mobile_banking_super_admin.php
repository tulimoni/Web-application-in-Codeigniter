<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mobile_Banking_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_mobile_banking_name()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/mobile_banking/add_mobile_banking_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_mobile_banking_name()
    {
        $data=array();
        $data['mobile_banking_name']=$this->input->post('mobile_banking_name',true);
        $data['mobile_banking_website_url']=$this->input->post('mobile_banking_website_url',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/mobile_banking_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('mobile_banking_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['mobile_banking_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $this->mb_model->save_mobile_banking_name_info($data);
        $sdata=array();
        $sdata['message']='Save Provider Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('mobile_banking_super_admin/add_mobile_banking_name');
    }

    public function manage_mobile_banking_name()
    {
        $data=array();
        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $data['all_mobile_banking_name']=$this->mb_model->select_all_mobile_banking_name();
        $data['admin_main_content']=$this->load->view('admin/mobile_banking/manage_mobile_banking_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_mobile_banking_name($mobile_banking_id)
    {
        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $this->mb_model->update_publication_status_by_mobile_banking_id($mobile_banking_id);
        redirect('mobile_banking_super_admin/manage_mobile_banking_name');
    }
    public function unpublished_mobile_banking_name($mobile_banking_id)
    {
        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $this->mb_model->update_unpublication_status_by_mobile_banking_id($mobile_banking_id);
        redirect('mobile_banking_super_admin/manage_mobile_banking_name');
    }

    public function edit_mobile_banking_name($mobile_banking_id)
    {
        $data=array();
        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $data['mobile_banking_name_info']=$this->mobile_banking_super_admin_model->select_mobile_banking_name_info_by_id($mobile_banking_id);
        $data['admin_main_content']=$this->load->view('admin/mobile_banking/edit_mobile_banking_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_mobile_banking_logo($mobile_banking_id)
    {
        $data=array();
        $data['img']=$this->mobile_banking_super_admin_model->delete_mobile_banking_logo_by_id($mobile_banking_id);
        $data['mobile_banking_name_info']=$this->mobile_banking_super_admin_model->select_mobile_banking_name_info_by_id($mobile_banking_id);
        $data['admin_main_content']=$this->load->view('admin/mobile_banking/edit_mobile_banking_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_mobile_banking_name()
    {
        $data=array();
        $this->load->model('mobile_banking_super_admin_model', 'mb_model');
        $mobile_banking_id=$this->input->post('mobile_banking_id');
        $data['mobile_banking_name']=$this->input->post('mobile_banking_name');
        $data['mobile_banking_website_url']=$this->input->post('mobile_banking_website_url');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/mobile_banking_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('mobile_banking_logo'))
        {
                 $fdata = $this->upload->data();
                $data['mobile_banking_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->mobile_banking_super_admin_model->update_mobile_banking_name_info($data,$mobile_banking_id);
        redirect('mobile_banking_super_admin/manage_mobile_banking_name');
    }

    public function delete_mobile_banking_name($mobile_banking_id)
    {
        $this->mobile_banking_super_admin_model->delete_category_by_mobile_banking_id($mobile_banking_id);
        redirect('mobile_banking_super_admin/manage_mobile_banking_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
