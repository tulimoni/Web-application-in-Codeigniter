<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bank_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
	}

	public function index()
	{
	$data=array();
        $data['admin_main_content']=$this->load->view('admin/admin_dashboard','',true);
		$this->load->view('admin/admin_master',$data);
	}

    /*
        * ------- Add Bank Category All Information Start form Line 19 to 88--------- *
    */

    public function add_bank_category()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_category_form','',true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_category()
    {
        $data=array();
        $data['bank_category_name']=$this->input->post('bank_category_name',true);
        $data['bank_category_description']=$this->input->post('bank_category_description',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_category_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Category Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_category');
    }

    public function manage_bank_category()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_category']=$this->sa_model->select_all_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_category',$data,true);
        $this->load->view('admin/admin_master',$data);
       
    }

    public function published_bank_category($bank_category_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_id($bank_category_id);
        redirect('bank_super_admin/manage_bank_category');
    }
    public function unpublished_bank_category($bank_category_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_id($bank_category_id);
        redirect('bank_super_admin/manage_bank_category');
    }

    public function edit_bank_category($bank_category_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_category_info']=$this->super_admin_model->select_bank_category_info_by_id($bank_category_id);
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_category()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_category_id=$this->input->post('bank_category_id');
        $data['bank_category_name']=$this->input->post('bank_category_name');
        $data['bank_category_description']=$this->input->post('bank_category_description');
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_category_info($data,$bank_category_id);
        redirect('bank_super_admin/manage_bank_category');
    }

    public function delete_bank_category($bank_category_id)
    {
        $this->super_admin_model->delete_category_by_id($bank_category_id);
        redirect('bank_super_admin/manage_bank_category');
    }

    /*
        * ------- Add Bank Category All Information End --------- *
    */

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_bank_name()
    {
        $data=array();
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_name()
    {
        $data=array();
        $data['bank_name']=$this->input->post('bank_name',true);
        $data['bank_category_id']=$this->input->post('bank_category_id',true);
        $data['bank_office_address']=$this->input->post('bank_office_address',true);
        $data['bank_website_url']=$this->input->post('bank_website_url',true);
        $data['bank_atm_url']=$this->input->post('bank_atm_url',true);
        $data['bank_phone_number']=$this->input->post('bank_phone_number',true);
        $data['bank_hot_line_number']=$this->input->post('bank_hot_line_number',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/bank_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '100';
        $config['max_width']  = '1024';
        $config['max_height']  = '768';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('bank_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['bank_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_name_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_name');
    }

    public function manage_bank_name()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_name']=$this->sa_model->select_all_bank_name();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_name($bank_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_bank_id($bank_id);
        redirect('bank_super_admin/manage_bank_name');
    }
    public function unpublished_bank_name($bank_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_bank_id($bank_id);
        redirect('bank_super_admin/manage_bank_name');
    }

    public function edit_bank_name($bank_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_name_info']=$this->super_admin_model->select_bank_name_info_by_id($bank_id);
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_bank_logo($bank_id)
    {
        $data=array();
        $data['img']=$this->super_admin_model->delete_bank_logo_by_id($bank_id);
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['bank_name_info']=$this->super_admin_model->select_bank_name_info_by_id($bank_id);
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_name()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_id=$this->input->post('bank_id');
        $data['bank_name']=$this->input->post('bank_name');
        $data['bank_category_id']=$this->input->post('bank_category_id');
        $data['bank_office_address']=$this->input->post('bank_office_address');
        $data['bank_website_url']=$this->input->post('bank_website_url');
        $data['bank_atm_url']=$this->input->post('bank_atm_url');
        $data['bank_phone_number']=$this->input->post('bank_phone_number');
        $data['bank_hot_line_number']=$this->input->post('bank_hot_line_number');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/bank_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('bank_logo'))
        {
                 $fdata = $this->upload->data();
                $data['bank_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_name_info($data,$bank_id);
        redirect('bank_super_admin/manage_bank_name');
    }

    public function delete_bank_name($bank_id)
    {
        $this->super_admin_model->delete_category_by_bank_id($bank_id);
        redirect('bank_super_admin/manage_bank_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

    /*
        * ------- Add Bank Deposit Information All Information Start form Line 226 to 303 --------- *
    */

    public function add_bank_deposit_information()
    {
        $data=array();
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_deposit_information_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_deposit_information()
    {
        $data=array();
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration',true);
        $data['diposit_amount']=$this->input->post('diposit_amount',true);
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate',true);
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit',true);
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['bank_feature']=$this->input->post('bank_feature',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_deposit_information_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Deposit Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_deposit_information');
    }

    public function manage_bank_deposit_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_deposit_information']=$this->sa_model->select_all_bank_deposit_information();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_deposit_information($bank_diposit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_bank_deposit_information($bank_diposit_id);
        redirect('bank_super_admin/manage_bank_deposit_information');
    }
    public function unpublished_bank_deposit_information($bank_diposit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_bank_deposit_information($bank_diposit_id);
        redirect('bank_super_admin/manage_bank_deposit_information');
    }

    public function edit_bank_deposit_information($bank_diposit_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_deposit_information_info']=$this->super_admin_model->select_bank_deposit_information_info_by_id($bank_diposit_id);
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_deposit_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_diposit_id=$this->input->post('bank_diposit_id');
        $data['bank_id']=$this->input->post('bank_id');
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration');
        $data['diposit_amount']=$this->input->post('diposit_amount');
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate');
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit');
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['bank_feature']=$this->input->post('bank_feature',true);
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_deposit_information_info($data,$bank_diposit_id);
        redirect('bank_super_admin/manage_bank_deposit_information');
    }

    public function delete_bank_deposit_information($bank_diposit_id)
    {
        $this->super_admin_model->delete_category_by_bank_deposit_information($bank_diposit_id);
        redirect('bank_super_admin/manage_bank_deposit_information');
    }

    /*
        * ------- Add Bank Deposit Information All Information End --------- *
    */

    /*
        * ------- Add Bank Loan Category Information All Information Start --------- *
    */

    public function add_bank_loan_category()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_loan_category_form','',true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_loan_category()
    {
        $data=array();
        $data['bank_loan_category_name']=$this->input->post('bank_loan_category_name',true);
        $data['bank_loan_category_description']=$this->input->post('bank_loan_category_description',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_loan_category_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Loan Category Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_loan_category');
    }

    public function manage_bank_loan_category()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_loan_category']=$this->sa_model->select_all_bank_loan_category();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_loan_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_loan_category($bank_loan_category_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_loan_status_by_id($bank_loan_category_id);
        redirect('bank_super_admin/manage_bank_loan_category');
    }
    public function unpublished_bank_loan_category($bank_loan_category_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_loan_status_by_id($bank_loan_category_id);
        redirect('bank_super_admin/manage_bank_loan_category');
    }

    public function edit_bank_loan_category($bank_loan_category_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_loan_category_info']=$this->super_admin_model->select_bank_loan_category_info_by_id($bank_loan_category_id);
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_loan_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_loan_category()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_loan_category_id=$this->input->post('bank_loan_category_id');
        $data['bank_loan_category_name']=$this->input->post('bank_loan_category_name');
        $data['bank_loan_category_description']=$this->input->post('bank_loan_category_description');
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_loan_category_info($data,$bank_loan_category_id);
        redirect('bank_super_admin/manage_bank_loan_category');
    }

    public function delete_bank_loan_category($bank_loan_category_id)
    {
        $this->super_admin_model->delete_bank_loan_category_by_id($bank_loan_category_id);
        redirect('bank_super_admin/manage_bank_loan_category');
    }

    /*
        * ------- Add Bank Loan Category Information All Information End --------- *
    */

    /*
        * ------- Add Bank Loan Information All Information Start --------- *
    */

    public function add_bank_loan_information()
    {
        $data=array();
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_loan_category_id']=$this->super_admin_model->select_all_published_bank_loan_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_loan_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_loan()
    {
        $data=array();
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['bank_loan_category_id']=$this->input->post('bank_loan_category_id',true);
        $data['bank_loan_name']=$this->input->post('bank_loan_name',true);
        $data['bank_loan_duration']=$this->input->post('bank_loan_duration',true);
        $data['bank_loan_interest_rate']=$this->input->post('bank_loan_interest_rate',true);
        $data['bank_loan_range']=$this->input->post('bank_loan_range',true);
        $data['monthly_installment']=$this->input->post('monthly_installment',true);
        $data['bank_loan_processing_fees']=$this->input->post('bank_loan_processing_fees',true);
        $data['customer_segment']=$this->input->post('customer_segment',true);
        $data['maximum_term_bank_loan']=$this->input->post('maximum_term_bank_loan',true);
        $data['eligibility']=$this->input->post('eligibility',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_loan_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Loan Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_loan_information');
    }

    public function manage_bank_loan_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_loan_information']=$this->sa_model->select_all_bank_loan_information();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_loan_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_loan_information($bank_loan_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_loan_info_by_id($bank_loan_id);
        redirect('bank_super_admin/manage_bank_loan_information');
    }
    public function unpublished_bank_loan_information($bank_loan_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_loan_info_by_id($bank_loan_id);
        redirect('bank_super_admin/manage_bank_loan_information');
    }

    public function edit_bank_loan_information($bank_loan_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_loan_information_info']=$this->super_admin_model->select_bank_loan_info_by_id($bank_loan_id);
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_loan_category_id']=$this->super_admin_model->select_all_published_bank_loan_category_id();
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_loan_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_loan_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_loan_id=$this->input->post('bank_loan_id');
        $data['bank_id']=$this->input->post('bank_id');
        $data['bank_loan_category_id']=$this->input->post('bank_loan_category_id');
        $data['bank_loan_name']=$this->input->post('bank_loan_name');
        $data['bank_loan_duration']=$this->input->post('bank_loan_duration');
        $data['bank_loan_interest_rate']=$this->input->post('bank_loan_interest_rate');
        $data['bank_loan_range']=$this->input->post('bank_loan_range');
        $data['monthly_installment']=$this->input->post('monthly_installment');
        $data['bank_loan_processing_fees']=$this->input->post('bank_loan_processing_fees');
        $data['customer_segment']=$this->input->post('customer_segment');
        $data['maximum_term_bank_loan']=$this->input->post('maximum_term_bank_loan');
        $data['eligibility']=$this->input->post('eligibility');
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_loan_information_info($data,$bank_loan_id);
        redirect('bank_super_admin/manage_bank_loan_information');
    }

    public function delete_bank_loan_information($bank_loan_id)
    {
        $this->super_admin_model->delete_bank_loan_info_by_id($bank_loan_id);
        redirect('bank_super_admin/manage_bank_loan_information');
    }

    /*
        * ------- Add Bank Loan Information All Information End --------- *
    */

    public function add_bank_exchange_rates()
    {
        $data=array();
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_loan_category_id']=$this->super_admin_model->select_all_published_bank_loan_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_exchange_rates_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_exchange_rates()
    {
        $data=array();
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['currency_type']=$this->input->post('currency_type',true);
        $data['selling']=$this->input->post('selling',true);
        $data['buying']=$this->input->post('buying',true);
        $data['bc']=$this->input->post('bc',true);
        $data['tt_clean']=$this->input->post('tt_clean',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_exchange_rates_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Exchange Rates Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_exchange_rates');
    }

     public function manage_bank_exchange_rates()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_exchange_rates']=$this->sa_model->select_all_bank_exchange_rates_information();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_exchange_rates',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_exchange_rates($bank_exchange_rates_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_exchange_rates_info_by_id($bank_exchange_rates_id);
        redirect('bank_super_admin/manage_bank_exchange_rates');
    }
    public function unpublished_bank_exchange_rates($bank_exchange_rates_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_exchange_rates_info_by_id($bank_exchange_rates_id);
        redirect('bank_super_admin/manage_bank_exchange_rates');
    }

    public function edit_bank_exchange_rates($bank_exchange_rates_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_exchange_rates_info']=$this->super_admin_model->select_bank_exchange_rates_info_by_id($bank_exchange_rates_id);
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_loan_category_id']=$this->super_admin_model->select_all_published_bank_loan_category_id();
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_exchange_rates',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_exchange_rates()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_exchange_rates_id=$this->input->post('bank_exchange_rates_id');
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['currency_type']=$this->input->post('currency_type',true);
        $data['selling']=$this->input->post('selling',true);
        $data['buying']=$this->input->post('buying',true);
        $data['bc']=$this->input->post('bc',true);
        $data['tt_clean']=$this->input->post('tt_clean',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->super_admin_model->update_bank_exchange_rates_information_info($data,$bank_exchange_rates_id);
        redirect('bank_super_admin/manage_bank_exchange_rates');
    }

    public function delete_bank_exchange_rates($bank_exchange_rates_id)
    {
        $this->super_admin_model->delete_bank_exchange_rates_info_by_id($bank_exchange_rates_id);
        redirect('bank_super_admin/manage_bank_exchange_rates');
    }


     public function add_bank_double_benefit()
    {
        $data=array();
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_double_benefit_schemes_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_double_benefit()
    {
        $data=array();
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['bank_double_benefit_i_r']=$this->input->post('bank_double_benefit_i_r',true);
        $data['bank_double_benefit_m_d']=$this->input->post('bank_double_benefit_m_d',true);
        $data['bank_double_benefit_duration']=$this->input->post('bank_double_benefit_duration',true);
        $data['bank_double_benefit_lcd']=$this->input->post('bank_double_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_double_benefit_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Double Benefit Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_double_benefit');
    }

    public function manage_bank_double_benefit()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_double_benefit']=$this->sa_model->select_bank_double_benefit_info();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_double_benefit_schemes',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_double_benefit_information($bank_double_benefit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_double_benefit_info_by_id($bank_double_benefit_id);
        redirect('bank_super_admin/manage_bank_double_benefit');
    }
    public function unpublished_bank_double_benefit_information($bank_double_benefit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_double_benefit_info_by_id($bank_double_benefit_id);
        redirect('bank_super_admin/manage_bank_double_benefit');
    }

    public function edit_bank_double_benefit($bank_double_benefit_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_double_benefit_info']=$this->super_admin_model->select_bank_double_benefit_info_by_id($bank_double_benefit_id);
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_double_benefit_schemes',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_double_benefit()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_double_benefit_id=$this->input->post('bank_double_benefit_id');
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['bank_double_benefit_i_r']=$this->input->post('bank_double_benefit_i_r',true);
        $data['bank_double_benefit_m_d']=$this->input->post('bank_double_benefit_m_d',true);
        $data['bank_double_benefit_duration']=$this->input->post('bank_double_benefit_duration',true);
        $data['bank_double_benefit_lcd']=$this->input->post('bank_double_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->super_admin_model->update_bank_double_benefit_information_info($data,$bank_double_benefit_id);
        redirect('bank_super_admin/manage_bank_double_benefit');
    }

    public function delete_bank_double_benefit($bank_double_benefit_id)
    {
        $this->super_admin_model->delete_bank_double_benefit_info_by_id($bank_double_benefit_id);
        redirect('bank_super_admin/manage_bank_double_benefit');
    }


    /*
        * ------- Add Bank Triple All Information Start --------- *
    */


    public function add_bank_triple_benefit_information()
    {
        $data=array();
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['admin_main_content']=$this->load->view('admin/bank/add_bank_triple_benefit_schemes_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_bank_triple_benefit()
    {
        $data=array();
        $data['bank_id']=$this->input->post('bank_id',true);
        $data['bank_triple_benefit_i_r']=$this->input->post('bank_triple_benefit_i_r',true);
        $data['bank_triple_benefit_m_d']=$this->input->post('bank_triple_benefit_m_d',true);
        $data['bank_triple_benefit_duration']=$this->input->post('bank_triple_benefit_duration',true);
        $data['bank_triple_benefit_lcd']=$this->input->post('bank_triple_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->save_bank_triple_benefit_info($data);
        $sdata=array();
        $sdata['message']='Save Bank Triple Benefit Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('bank_super_admin/add_bank_triple_benefit_information');
    }

    
    public function manage_bank_triple_benefit_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['all_bank_triple_benefit_information']=$this->sa_model->select_all_bank_triple_benefit_information();
        $data['admin_main_content']=$this->load->view('admin/bank/manage_bank_triple_benefit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_bank_triple_benefit_information($bank_triple_benefit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_publication_triple_benefit_info_by_id($bank_triple_benefit_id);
        redirect('bank_super_admin/manage_bank_triple_benefit_information');
    }
    public function unpublished_bank_triple_benefit_information($bank_triple_benefit_id)
    {
        $this->load->model('super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_triple_benefit_info_by_id($bank_triple_benefit_id);
        redirect('bank_super_admin/manage_bank_triple_benefit_information');
    }

    public function edit_bank_triple_benefit_information($bank_triple_benefit_id)
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $data['bank_triple_benefit_information_info']=$this->super_admin_model->select_bank_triple_benefit_info_by_id($bank_triple_benefit_id);
        $data['all_published_bank_category_id']=$this->super_admin_model->select_all_published_bank_category_id();
        $data['all_published_bank_category']=$this->super_admin_model->select_all_published_bank_category();
        $data['admin_main_content']=$this->load->view('admin/bank/edit_bank_triple_benefit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_bank_triple_benefit_information()
    {
        $data=array();
        $this->load->model('super_admin_model', 'sa_model');
        $bank_triple_benefit_id=$this->input->post('bank_triple_benefit_id');
        $data['bank_id']=$this->input->post('bank_id');
        $data['bank_triple_benefit_i_r']=$this->input->post('bank_triple_benefit_i_r');
        $data['bank_triple_benefit_m_d']=$this->input->post('bank_triple_benefit_m_d');
        $data['bank_triple_benefit_duration']=$this->input->post('bank_triple_benefit_duration');
        $data['bank_triple_benefit_lcd']=$this->input->post('bank_triple_benefit_lcd');
        $data['publication_status']=$this->input->post('publication_status');
        $this->super_admin_model->update_bank_triple_benefit_information_info($data,$bank_triple_benefit_id);
        redirect('bank_super_admin/manage_bank_triple_benefit_information');
    }

    public function delete_bank_triple_benefit_information($bank_triple_benefit_id)
    {
        $this->super_admin_model->delete_bank_triple_benefit_info_by_id($bank_triple_benefit_id);
        redirect('bank_super_admin/manage_bank_triple_benefit_information');
    }


	public function logout()
    {
        $this->session->unset_userdata('user_name');
        $this->session->unset_userdata('admin_id');
        $sdata=array();
        $sdata['message']='You are Successfully Logout !';
        $this->session->set_userdata($sdata);
        redirect('security');
        
    }

}
