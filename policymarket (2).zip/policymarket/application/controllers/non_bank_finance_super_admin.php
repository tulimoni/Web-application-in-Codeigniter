<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Non_Bank_Finance_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Non Bank Finance Category All Information Start form Line 19 to 88--------- *
    */

    public function add_non_bank_finance_category()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_category_form','',true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_category()
    {
        $data=array();
        $data['non_bank_finance_category_name']=$this->input->post('non_bank_finance_category_name',true);
        $data['non_bank_finance_category_description']=$this->input->post('non_bank_finance_category_description',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_category_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Category Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_category');
    }

    public function manage_non_bank_finance_category()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_category']=$this->nbfsa_model->select_all_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_category',$data,true);
        $this->load->view('admin/admin_master',$data);
       
    }

    public function published_non_bank_finance_category($non_bank_finance_category_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_status_by_id($non_bank_finance_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_category');
    }
    public function unpublished_non_bank_finance_category($non_bank_finance_category_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_status_by_id($non_bank_finance_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_category');
    }

    public function edit_non_bank_finance_category($non_bank_finance_category_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_category_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_category_info_by_id($non_bank_finance_category_id);
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_category()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_category_id=$this->input->post('non_bank_finance_category_id');
        $data['non_bank_finance_category_name']=$this->input->post('non_bank_finance_category_name');
        $data['non_bank_finance_category_description']=$this->input->post('non_bank_finance_category_description');
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_category_info($data,$non_bank_finance_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_category');
    }

    public function delete_non_bank_finance_category($non_bank_finance_category_id)
    {
        $this->non_bank_finance_super_admin_model->delete_category_by_id($non_bank_finance_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_category');
    }

    /*
        * ------- Add Non Bank Finance Category All Information End --------- *
    */

    /*
        * ------- Add Non Bank Finance Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_non_bank_finance_name()
    {
        $data=array();
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_name()
    {
        $data=array();
        $data['non_bank_finance_name']=$this->input->post('non_bank_finance_name',true);
        $data['non_bank_finance_category_id']=$this->input->post('non_bank_finance_category_id',true);
        $data['non_bank_finance_office_address']=$this->input->post('non_bank_finance_office_address',true);
        $data['non_bank_finance_website_url']=$this->input->post('non_bank_finance_website_url',true);
        $data['non_bank_finance_atm_url']=$this->input->post('non_bank_finance_atm_url',true);
        $data['non_bank_finance_phone_number']=$this->input->post('non_bank_finance_phone_number',true);
        $data['non_bank_finance_hot_line_number']=$this->input->post('non_bank_finance_hot_line_number',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/non_bank_finance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('non_bank_finance_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['non_bank_finance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_name_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_name');
    }

    public function manage_non_bank_finance_name()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_name']=$this->nbfsa_model->select_all_non_bank_finance_name();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_name($non_bank_finance_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_status_by_non_bank_finance_id($non_bank_finance_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_name');
    }
    public function unpublished_non_bank_finance_name($non_bank_finance_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_status_by_non_bank_finance_id($non_bank_finance_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_name');
    }

    public function edit_non_bank_finance_name($non_bank_finance_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_name_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_name_info_by_id($non_bank_finance_id);
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_non_bank_finance_logo($non_bank_finance_id)
    {
        $data=array();
        $data['img']=$this->non_bank_finance_super_admin_model->delete_non_bank_finance_logo_by_id($non_bank_finance_id);
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['non_bank_finance_name_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_name_info_by_id($non_bank_finance_id);
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_name()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_id=$this->input->post('non_bank_finance_id');
        $data['non_bank_finance_name']=$this->input->post('non_bank_finance_name');
        $data['non_bank_finance_category_id']=$this->input->post('non_bank_finance_category_id');
        $data['non_bank_finance_office_address']=$this->input->post('non_bank_finance_office_address');
        $data['non_bank_finance_website_url']=$this->input->post('non_bank_finance_website_url');
        $data['non_bank_finance_atm_url']=$this->input->post('non_bank_finance_atm_url');
        $data['non_bank_finance_phone_number']=$this->input->post('non_bank_finance_phone_number');
        $data['non_bank_finance_hot_line_number']=$this->input->post('non_bank_finance_hot_line_number');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/non_bank_finance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('non_bank_finance_logo'))
        {
                 $fdata = $this->upload->data();
                $data['non_bank_finance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_name_info($data,$non_bank_finance_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_name');
    }

    public function delete_non_bank_finance_name($non_bank_finance_id)
    {
        $this->non_bank_finance_super_admin_model->delete_category_by_non_bank_finance_id($non_bank_finance_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_name');
    }

    /*
        * ------- Add Non Bank Finance Name All Information End --------- *
    */

    /*
        * ------- Add Non Bank Finance Deposit Information All Information Start form Line 226 to 303 --------- *
    */

    public function add_non_bank_finance_deposit_information()
    {
        $data=array();
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_deposit_information_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_deposit_information()
    {
        $data=array();
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id',true);
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration',true);
        $data['diposit_amount']=$this->input->post('diposit_amount',true);
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate',true);
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit',true);
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['non_bank_finance_feature']=$this->input->post('non_bank_finance_feature',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_deposit_information_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Deposit Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_deposit_information');
    }

    public function manage_non_bank_finance_deposit_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_deposit_information']=$this->nbfsa_model->select_all_non_bank_finance_deposit_information();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_status_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_deposit_information');
    }
    public function unpublished_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_status_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_deposit_information');
    }

    public function edit_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_deposit_information_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_deposit_information_info_by_id($non_bank_finance_diposit_id);
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_deposit_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_diposit_id=$this->input->post('non_bank_finance_diposit_id');
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id');
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration');
        $data['diposit_amount']=$this->input->post('diposit_amount');
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate');
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit');
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['non_bank_finance_feature']=$this->input->post('non_bank_finance_feature',true);
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_deposit_information_info($data,$non_bank_finance_diposit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_deposit_information');
    }

    public function delete_non_bank_finance_deposit_information($non_bank_finance_diposit_id)
    {
        $this->non_bank_finance_super_admin_model->delete_category_by_non_bank_finance_deposit_information($non_bank_finance_diposit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_deposit_information');
    }

    /*
        * ------- Add Non Bank Finance Deposit Information All Information End --------- *
    */

    /*
        * ------- Add Non Bank Finance Loan Category Information All Information Start --------- *
    */

    public function add_non_bank_finance_loan_category()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_loan_category_form','',true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_loan_category()
    {
        $data=array();
        $data['non_bank_finance_loan_category_name']=$this->input->post('non_bank_finance_loan_category_name',true);
        $data['non_bank_finance_loan_category_description']=$this->input->post('non_bank_finance_loan_category_description',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_loan_category_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Loan Category Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_loan_category');
    }

    public function manage_non_bank_finance_loan_category()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_loan_category']=$this->nbfsa_model->select_all_non_bank_finance_loan_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_loan_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_loan_category($non_bank_finance_loan_category_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_loan_status_by_id($non_bank_finance_loan_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_category');
    }
    public function unpublished_non_bank_finance_loan_category($non_bank_finance_loan_category_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_loan_status_by_id($non_bank_finance_loan_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_category');
    }

    public function edit_non_bank_finance_loan_category($non_bank_finance_loan_category_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_loan_category_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_loan_category_info_by_id($non_bank_finance_loan_category_id);
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_loan_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_loan_category()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_loan_category_id=$this->input->post('non_bank_finance_loan_category_id');
        $data['non_bank_finance_loan_category_name']=$this->input->post('non_bank_finance_loan_category_name');
        $data['non_bank_finance_loan_category_description']=$this->input->post('non_bank_finance_loan_category_description');
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_loan_category_info($data,$non_bank_finance_loan_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_category');
    }

    public function delete_non_bank_finance_loan_category($non_bank_finance_loan_category_id)
    {
        $this->non_bank_finance_super_admin_model->delete_non_bank_finance_loan_category_by_id($non_bank_finance_loan_category_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_category');
    }

    /*
        * ------- Add Non Bank Finance Loan Category Information All Information End --------- *
    */

    /*
        * ------- Add Non Bank Finance Loan Information All Information Start --------- *
    */

    public function add_non_bank_finance_loan_information()
    {
        $data=array();
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['all_published_non_bank_finance_loan_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_loan_category_id();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_loan_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_loan()
    {
        $data=array();
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id',true);
        $data['non_bank_finance_loan_category_id']=$this->input->post('non_bank_finance_loan_category_id',true);
        $data['non_bank_finance_loan_name']=$this->input->post('non_bank_finance_loan_name',true);
        $data['non_bank_finance_loan_duration']=$this->input->post('non_bank_finance_loan_duration',true);
        $data['non_bank_finance_loan_interest_rate']=$this->input->post('non_bank_finance_loan_interest_rate',true);
        $data['non_bank_finance_loan_range']=$this->input->post('non_bank_finance_loan_range',true);
        $data['monthly_installment']=$this->input->post('monthly_installment',true);
        $data['non_bank_finance_loan_processing_fees']=$this->input->post('non_bank_finance_loan_processing_fees',true);
        $data['customer_segment']=$this->input->post('customer_segment',true);
        $data['maximum_term_non_bank_finance_loan']=$this->input->post('maximum_term_non_bank_finance_loan',true);
        $data['eligibility']=$this->input->post('eligibility',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_loan_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Loan Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_loan_information');
    }

    public function manage_non_bank_finance_loan_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_loan_information']=$this->nbfsa_model->select_all_non_bank_finance_loan_information();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_loan_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_loan_information($non_bank_finance_loan_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_loan_info_by_id($non_bank_finance_loan_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_information');
    }
    public function unpublished_non_bank_finance_loan_information($non_bank_finance_loan_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_loan_info_by_id($non_bank_finance_loan_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_information');
    }

    public function edit_non_bank_finance_loan_information($non_bank_finance_loan_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_loan_information_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_loan_info_by_id($non_bank_finance_loan_id);
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['all_published_non_bank_finance_loan_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_loan_category_id();
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_loan_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_loan_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_loan_id=$this->input->post('non_bank_finance_loan_id');
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id');
        $data['non_bank_finance_loan_category_id']=$this->input->post('non_bank_finance_loan_category_id');
        $data['non_bank_finance_loan_name']=$this->input->post('non_bank_finance_loan_name');
        $data['non_bank_finance_loan_duration']=$this->input->post('non_bank_finance_loan_duration');
        $data['non_bank_finance_loan_interest_rate']=$this->input->post('non_bank_finance_loan_interest_rate');
        $data['non_bank_finance_loan_range']=$this->input->post('non_bank_finance_loan_range');
        $data['monthly_installment']=$this->input->post('monthly_installment');
        $data['non_bank_finance_loan_processing_fees']=$this->input->post('non_bank_finance_loan_processing_fees');
        $data['customer_segment']=$this->input->post('customer_segment');
        $data['maximum_term_non_bank_finance_loan']=$this->input->post('maximum_term_non_bank_finance_loan');
        $data['eligibility']=$this->input->post('eligibility');
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_loan_information_info($data,$non_bank_finance_loan_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_information');
    }

    public function delete_non_bank_finance_loan_information($non_bank_finance_loan_id)
    {
        $this->non_bank_finance_super_admin_model->delete_non_bank_finance_loan_info_by_id($non_bank_finance_loan_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_loan_information');
    }

    /*
        * ------- Add Bank Double All Information Start --------- *
    */


     public function add_non_bank_finance_double_benefit()
    {
        $data=array();
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_double_benefit_schemes_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_double_benefit()
    {
        $data=array();
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id',true);
        $data['non_bank_finance_double_benefit_i_r']=$this->input->post('non_bank_finance_double_benefit_i_r',true);
        $data['non_bank_finance_double_benefit_m_d']=$this->input->post('non_bank_finance_double_benefit_m_d',true);
        $data['non_bank_finance_double_benefit_duration']=$this->input->post('non_bank_finance_double_benefit_duration',true);
        $data['non_bank_finance_double_benefit_lcd']=$this->input->post('non_bank_finance_double_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_double_benefit_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Double Benefit Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_double_benefit');
    }

    public function manage_non_bank_finance_double_benefit()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_double_benefit']=$this->nbfsa_model->select_non_bank_finance_double_benefit_info();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_double_benefit_schemes',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_double_benefit_information($non_bank_finance_double_benefit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_double_benefit_info_by_id($non_bank_finance_double_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_double_benefit');
    }
    public function unpublished_non_bank_finance_double_benefit_information($non_bank_finance_double_benefit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_double_benefit_info_by_id($non_bank_finance_double_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_double_benefit');
    }

    public function edit_non_bank_finance_double_benefit($non_bank_finance_double_benefit_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_double_benefit_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_double_benefit_info_by_id($non_bank_finance_double_benefit_id);
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_double_benefit_schemes',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_double_benefit()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_double_benefit_id=$this->input->post('non_bank_finance_double_benefit_id');
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id',true);
        $data['non_bank_finance_double_benefit_i_r']=$this->input->post('non_bank_finance_double_benefit_i_r',true);
        $data['non_bank_finance_double_benefit_m_d']=$this->input->post('non_bank_finance_double_benefit_m_d',true);
        $data['non_bank_finance_double_benefit_duration']=$this->input->post('non_bank_finance_double_benefit_duration',true);
        $data['non_bank_finance_double_benefit_lcd']=$this->input->post('non_bank_finance_double_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_double_benefit_information_info($data,$non_bank_finance_double_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_double_benefit');
    }

    public function delete_non_bank_finance_double_benefit($non_bank_finance_double_benefit_id)
    {
        $this->non_bank_finance_super_admin_model->delete_non_bank_finance_double_benefit_info_by_id($non_bank_finance_double_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_double_benefit');
    }


    /*
        * ------- Add Bank Triple All Information Start --------- *
    */


    public function add_non_bank_finance_triple_benefit_information()
    {
        $data=array();
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/add_non_bank_finance_triple_benefit_schemes_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_non_bank_finance_triple_benefit()
    {
        $data=array();
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id',true);
        $data['non_bank_finance_triple_benefit_i_r']=$this->input->post('non_bank_finance_triple_benefit_i_r',true);
        $data['non_bank_finance_triple_benefit_m_d']=$this->input->post('non_bank_finance_triple_benefit_m_d',true);
        $data['non_bank_finance_triple_benefit_duration']=$this->input->post('non_bank_finance_triple_benefit_duration',true);
        $data['non_bank_finance_triple_benefit_lcd']=$this->input->post('non_bank_finance_triple_benefit_lcd',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->save_non_bank_finance_triple_benefit_info($data);
        $sdata=array();
        $sdata['message']='Save Non Bank Finance Triple Benefit Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('non_bank_finance_super_admin/add_non_bank_finance_triple_benefit_information');
    }

    
    public function manage_non_bank_finance_triple_benefit_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['all_non_bank_finance_triple_benefit_information']=$this->nbfsa_model->select_all_non_bank_finance_triple_benefit_information();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/manage_non_bank_finance_triple_benefit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_non_bank_finance_triple_benefit_information($non_bank_finance_triple_benefit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_publication_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_triple_benefit_information');
    }
    public function unpublished_non_bank_finance_triple_benefit_information($non_bank_finance_triple_benefit_id)
    {
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $this->nbfsa_model->update_unpublication_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_triple_benefit_information');
    }

    public function edit_non_bank_finance_triple_benefit_information($non_bank_finance_triple_benefit_id)
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $data['non_bank_finance_triple_benefit_information_info']=$this->non_bank_finance_super_admin_model->select_non_bank_finance_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id);
        $data['all_published_non_bank_finance_category_id']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category_id();
        $data['all_published_non_bank_finance_category']=$this->non_bank_finance_super_admin_model->select_all_published_non_bank_finance_category();
        $data['admin_main_content']=$this->load->view('admin/non_bank_finance/edit_non_bank_finance_triple_benefit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_non_bank_finance_triple_benefit_information()
    {
        $data=array();
        $this->load->model('non_bank_finance_super_admin_model', 'nbfsa_model');
        $non_bank_finance_triple_benefit_id=$this->input->post('non_bank_finance_triple_benefit_id');
        $data['non_bank_finance_id']=$this->input->post('non_bank_finance_id');
        $data['non_bank_finance_triple_benefit_i_r']=$this->input->post('non_bank_finance_triple_benefit_i_r');
        $data['non_bank_finance_triple_benefit_m_d']=$this->input->post('non_bank_finance_triple_benefit_m_d');
        $data['non_bank_finance_triple_benefit_duration']=$this->input->post('non_bank_finance_triple_benefit_duration');
        $data['non_bank_finance_triple_benefit_lcd']=$this->input->post('non_bank_finance_triple_benefit_lcd');
        $data['publication_status']=$this->input->post('publication_status');
        $this->non_bank_finance_super_admin_model->update_non_bank_finance_triple_benefit_information_info($data,$non_bank_finance_triple_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_triple_benefit_information');
    }

    public function delete_non_bank_finance_triple_benefit_information($non_bank_finance_triple_benefit_id)
    {
        $this->non_bank_finance_super_admin_model->delete_non_bank_finance_triple_benefit_info_by_id($non_bank_finance_triple_benefit_id);
        redirect('non_bank_finance_super_admin/manage_non_bank_finance_triple_benefit_information');
    }

}
