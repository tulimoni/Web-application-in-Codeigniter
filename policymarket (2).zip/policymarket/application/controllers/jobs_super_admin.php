<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobs_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_jobs_name()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/jobs/add_jobs_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_jobs_name()
    {
        $data=array();
        $data['jobs_name']=$this->input->post('jobs_name',true);
        $data['jobs_website_url']=$this->input->post('jobs_website_url',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/jobs_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('jobs_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['jobs_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('jobs_super_admin_model', 'ja_model');
        $this->ja_model->save_jobs_name_info($data);
        $sdata=array();
        $sdata['message']='Save Provider Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('jobs_super_admin/add_jobs_name');
    }

    public function manage_jobs_name()
    {
        $data=array();
        $this->load->model('jobs_super_admin_model', 'ja_model');
        $data['all_jobs_name']=$this->ja_model->select_all_jobs_name();
        $data['admin_main_content']=$this->load->view('admin/jobs/manage_jobs_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_jobs_name($jobs_id)
    {
        $this->load->model('jobs_super_admin_model', 'ja_model');
        $this->ja_model->update_publication_status_by_jobs_id($jobs_id);
        redirect('jobs_super_admin/manage_jobs_name');
    }
    public function unpublished_jobs_name($jobs_id)
    {
        $this->load->model('jobs_super_admin_model', 'ja_model');
        $this->ja_model->update_unpublication_status_by_jobs_id($jobs_id);
        redirect('jobs_super_admin/manage_jobs_name');
    }

    public function edit_jobs_name($jobs_id)
    {
        $data=array();
        $this->load->model('jobs_super_admin_model', 'ja_model');
        $data['jobs_name_info']=$this->jobs_super_admin_model->select_jobs_name_info_by_id($jobs_id);
        $data['admin_main_content']=$this->load->view('admin/jobs/edit_jobs_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_jobs_logo($jobs_id)
    {
        $data=array();
        $data['img']=$this->jobs_super_admin_model->delete_jobs_logo_by_id($jobs_id);
        $data['jobs_name_info']=$this->jobs_super_admin_model->select_jobs_name_info_by_id($jobs_id);
        $data['admin_main_content']=$this->load->view('admin/jobs/edit_jobs_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_jobs_name()
    {
        $data=array();
        $this->load->model('jobs_super_admin_model', 'ja_model');
        $jobs_id=$this->input->post('jobs_id');
        $data['jobs_name']=$this->input->post('jobs_name');
        $data['jobs_website_url']=$this->input->post('jobs_website_url');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/jobs_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('jobs_logo'))
        {
                 $fdata = $this->upload->data();
                $data['jobs_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->jobs_super_admin_model->update_jobs_name_info($data,$jobs_id);
        redirect('jobs_super_admin/manage_jobs_name');
    }

    public function delete_jobs_name($jobs_id)
    {
        $this->jobs_super_admin_model->delete_category_by_jobs_id($jobs_id);
        redirect('jobs_super_admin/manage_jobs_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
