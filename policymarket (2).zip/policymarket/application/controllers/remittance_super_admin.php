<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Remittance_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_remittance_name()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/remittance/add_remittance_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_remittance_name()
    {
        $data=array();
        $data['remittance_name']=$this->input->post('remittance_name',true);
        $data['remittance_website_url']=$this->input->post('remittance_website_url',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/remittance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('remittance_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['remittance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('remittance_super_admin_model', 'ra_model');
        $this->ra_model->save_remittance_name_info($data);
        $sdata=array();
        $sdata['message']='Save Provider Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('remittance_super_admin/add_remittance_name');
    }

    public function manage_remittance_name()
    {
        $data=array();
        $this->load->model('remittance_super_admin_model', 'ra_model');
        $data['all_remittance_name']=$this->ra_model->select_all_remittance_name();
        $data['admin_main_content']=$this->load->view('admin/remittance/manage_remittance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_remittance_name($remittance_id)
    {
        $this->load->model('remittance_super_admin_model', 'ra_model');
        $this->ra_model->update_publication_status_by_remittance_id($remittance_id);
        redirect('remittance_super_admin/manage_remittance_name');
    }
    public function unpublished_remittance_name($remittance_id)
    {
        $this->load->model('remittance_super_admin_model', 'ra_model');
        $this->ra_model->update_unpublication_status_by_remittance_id($remittance_id);
        redirect('remittance_super_admin/manage_remittance_name');
    }

    public function edit_remittance_name($remittance_id)
    {
        $data=array();
        $this->load->model('remittance_super_admin_model', 'ra_model');
        $data['remittance_name_info']=$this->remittance_super_admin_model->select_remittance_name_info_by_id($remittance_id);
        $data['admin_main_content']=$this->load->view('admin/remittance/edit_remittance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_remittance_logo($remittance_id)
    {
        $data=array();
        $data['img']=$this->remittance_super_admin_model->delete_remittance_logo_by_id($remittance_id);
        $data['remittance_name_info']=$this->remittance_super_admin_model->select_remittance_name_info_by_id($remittance_id);
        $data['admin_main_content']=$this->load->view('admin/remittance/edit_remittance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_remittance_name()
    {
        $data=array();
        $this->load->model('remittance_super_admin_model', 'ra_model');
        $remittance_id=$this->input->post('remittance_id');
        $data['remittance_name']=$this->input->post('remittance_name');
        $data['remittance_website_url']=$this->input->post('remittance_website_url');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/remittance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('remittance_logo'))
        {
                 $fdata = $this->upload->data();
                $data['remittance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->remittance_super_admin_model->update_remittance_name_info($data,$remittance_id);
        redirect('remittance_super_admin/manage_remittance_name');
    }

    public function delete_remittance_name($remittance_id)
    {
        $this->remittance_super_admin_model->delete_category_by_remittance_id($remittance_id);
        redirect('remittance_super_admin/manage_remittance_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
