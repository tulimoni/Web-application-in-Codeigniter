<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Provider_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
	}

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_provider_name()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/paymentgetway/add_provider_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_provider_name()
    {
        $data=array();
        $data['provider_name']=$this->input->post('provider_name',true);
        $data['provider_website_url']=$this->input->post('provider_website_url',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/provider_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('provider_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['provider_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('provider_super_admin_model', 'pa_model');
        $this->pa_model->save_provider_name_info($data);
        $sdata=array();
        $sdata['message']='Save Provider Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('provider_super_admin/add_provider_name');
    }

    public function manage_provider_name()
    {
        $data=array();
        $this->load->model('provider_super_admin_model', 'pa_model');
        $data['all_provider_name']=$this->pa_model->select_all_provider_name();
        $data['admin_main_content']=$this->load->view('admin/paymentgetway/manage_provider_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_provider_name($provider_id)
    {
        $this->load->model('provider_super_admin_model', 'pa_model');
        $this->pa_model->update_publication_status_by_provider_id($provider_id);
        redirect('provider_super_admin/manage_provider_name');
    }
    public function unpublished_provider_name($provider_id)
    {
        $this->load->model('provider_super_admin_model', 'pa_model');
        $this->pa_model->update_unpublication_status_by_provider_id($provider_id);
        redirect('provider_super_admin/manage_provider_name');
    }

    public function edit_provider_name($provider_id)
    {
        $data=array();
        $this->load->model('provider_super_admin_model', 'pa_model');
        $data['provider_name_info']=$this->provider_super_admin_model->select_provider_name_info_by_id($provider_id);
        $data['admin_main_content']=$this->load->view('admin/paymentgetway/edit_provider_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_provider_logo($provider_id)
    {
        $data=array();
        $data['img']=$this->provider_super_admin_model->delete_provider_logo_by_id($provider_id);
        $data['provider_name_info']=$this->provider_super_admin_model->select_provider_name_info_by_id($provider_id);
        $data['admin_main_content']=$this->load->view('admin/paymentgetway/edit_provider_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_provider_name()
    {
        $data=array();
        $this->load->model('provider_super_admin_model', 'pa_model');
        $provider_id=$this->input->post('provider_id');
        $data['provider_name']=$this->input->post('provider_name');
        $data['provider_website_url']=$this->input->post('provider_website_url');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/provider_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('provider_logo'))
        {
                 $fdata = $this->upload->data();
                $data['provider_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->provider_super_admin_model->update_provider_name_info($data,$provider_id);
        redirect('provider_super_admin/manage_provider_name');
    }

    public function delete_provider_name($provider_id)
    {
        $this->provider_super_admin_model->delete_category_by_provider_id($provider_id);
        redirect('provider_super_admin/manage_provider_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
