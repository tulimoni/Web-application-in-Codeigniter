<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Stock_Exchange_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_stock_exchange_name()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/share_market/add_stock_exchange_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_stock_exchange_name()
    {
        $data=array();
        $data['stock_exchange_name']=$this->input->post('stock_exchange_name',true);
        $data['stock_exchange_website_url']=$this->input->post('stock_exchange_website_url',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/stock_exchange_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('stock_exchange_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['stock_exchange_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $this->sm_model->save_stock_exchange_name_info($data);
        $sdata=array();
        $sdata['message']='Save Provider Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('stock_exchange_super_admin/add_stock_exchange_name');
    }

    public function manage_stock_exchange_name()
    {
        $data=array();
        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $data['all_stock_exchange_name']=$this->sm_model->select_all_stock_exchange_name();
        $data['admin_main_content']=$this->load->view('admin/share_market/manage_stock_exchange_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_stock_exchange_name($stock_exchange_id)
    {
        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $this->sm_model->update_publication_status_by_stock_exchange_id($stock_exchange_id);
        redirect('stock_exchange_super_admin/manage_stock_exchange_name');
    }
    public function unpublished_stock_exchange_name($stock_exchange_id)
    {
        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $this->sm_model->update_unpublication_status_by_stock_exchange_id($stock_exchange_id);
        redirect('stock_exchange_super_admin/manage_stock_exchange_name');
    }

    public function edit_stock_exchange_name($stock_exchange_id)
    {
        $data=array();
        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $data['stock_exchange_name_info']=$this->stock_exchange_super_admin_model->select_stock_exchange_name_info_by_id($stock_exchange_id);
        $data['admin_main_content']=$this->load->view('admin/share_market/edit_stock_exchange_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_stock_exchange_logo($stock_exchange_id)
    {
        $data=array();
        $data['img']=$this->stock_exchange_super_admin_model->delete_stock_exchange_logo_by_id($stock_exchange_id);
        $data['stock_exchange_name_info']=$this->stock_exchange_super_admin_model->select_stock_exchange_name_info_by_id($stock_exchange_id);
        $data['admin_main_content']=$this->load->view('admin/share_market/edit_stock_exchange_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_stock_exchange_name()
    {
        $data=array();
        $this->load->model('stock_exchange_super_admin_model', 'sm_model');
        $stock_exchange_id=$this->input->post('stock_exchange_id');
        $data['stock_exchange_name']=$this->input->post('stock_exchange_name');
        $data['stock_exchange_website_url']=$this->input->post('stock_exchange_website_url');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/stock_exchange_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('stock_exchange_logo'))
        {
                 $fdata = $this->upload->data();
                $data['stock_exchange_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->stock_exchange_super_admin_model->update_stock_exchange_name_info($data,$stock_exchange_id);
        redirect('stock_exchange_super_admin/manage_stock_exchange_name');
    }

    public function delete_stock_exchange_name($stock_exchange_id)
    {
        $this->stock_exchange_super_admin_model->delete_category_by_stock_exchange_id($stock_exchange_id);
        redirect('stock_exchange_super_admin/manage_stock_exchange_name');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
