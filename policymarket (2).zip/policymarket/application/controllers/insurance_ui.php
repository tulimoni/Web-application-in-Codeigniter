<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurance_Ui extends CI_Controller {
	
	public function index()
	{
		$data=array();
		$this->load->model('insurance_front_ui_model','i_model');
	  	$data['all_news']= $this->i_model->select_all_news();
		$this->load->view('index',$data);
		$this->load->library('session');
		$this->session->sess_destroy();	
	}


	/**************For Insurance Home Page*****************/
	
	public function insurance_show()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/insurance/insurance_page','',true);
		$data['title']='Insurance';
		$data['sidebar']=1;
		$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	

	/********Diposit Part***************/
	
	public function diposit_search()
	{
		$data=array();
	 	$this->load->model('insurance_front_ui_model','i_model');
		$a['default_deposit']=$this->i_model->default_deposit_select();
		$a['all_insurance_deposit']=$this->i_model->select_all_insurance_deposit();
		$a['all_insurance_deposit_name']=$this->i_model->select_all_insurance_deposit_name();
		$a['all_insurance_deposit_duration']=$this->i_model->select_all_insurance_deposit_duration();  
		$data['maincontent']=$this->load->view('front_ui/insurance/form_diposit',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
	
	/*******************Search All Diposit Data*********************Different Mastering*/
	 
	public function check_diposit_info()
    { 
		$installment_amount=$this->input->post('installment_amount'); 
		$installment_name=$this->input->post('installment_name');
		$year=$this->input->post('deposit_year'); 
		$this->load->model('insurance_front_ui_model','i_model');
                $a['results']= $this->i_model->search_diposit_info($installment_amount,$installment_name,$year);
      	        $a['default_deposit']=$this->i_model->default_deposit_select();  //default depisit data select
			 
		if($a['results'])
		{
		$data=array();
		$this->load->model('insurance_front_ui_model','i_model');
		$a['all_insurance_deposit']=$this->i_model->select_all_insurance_deposit();
		$a['all_insurance_deposit_name']=$this->i_model->select_all_insurance_deposit_name();
		$a['all_insurance_deposit_duration']=$this->i_model->select_all_insurance_deposit_duration();
                $data['maincontent']=$this->load->view('front_ui/insurance/table_show_deposit1',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		}
		   else
		   
		   	{
		        $data=array();
			$a['message']='We are not found anything from your criteria!';
			$this->load->model('insurance_front_ui_model','i_model');
			$a['all_insurance_deposit']=$this->i_model->select_all_insurance_deposit();
			$a['all_insurance_deposit_name']=$this->i_model->select_all_insurance_deposit_name();
			$a['all_insurance_deposit_duration']=$this->i_model->select_all_insurance_deposit_duration(); 
		 	$data['maincontent']=$this->load->view('front_ui/insurance/table_show_deposit1',$a,true);
			$data['title']='Deposit Form';
			//$data['sidebar']=1;
			//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
			}
    }
 

/*************************Diposit Compare.three insurance compare.Show in header named "Diposit Compare" *********************/
  	
  	public function diposit_compare()
	{
		$data=array();
	 	$this->load->model('insurance_front_ui_model','i_model');
                $a['insurance_name']= $this->i_model->search_all_insurance();
                $data['maincontent']=$this->load->view('front_ui/insurance/compare',$a,true);
		$data['title']='Deposit Compare';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	

	/*************part of Deiposit Compare. Individual Insurance Data Search**********************/
	
	public function compare()
	{
		$installment_amount=$this->input->post('installment_amount',true);
                $installment_name=$this->input->post('installment_name',true);
		$deposit_year=$this->input->post('deposit_year',true);
		$insurance_name1=$this->input->post('insurance_name1');
		$insurance_name2=$this->input->post('insurance_name2');
		$insurance_name3=$this->input->post('insurance_name3');
				
		if($insurance_name1)
		{
		
      	$this->load->model('insurance_front_ui_model','com_model');
        $results= $this->com_model->compare1($installment_amount,$installment_name,$deposit_year,$insurance_name1);
      
 		if($results)
       {
	    	foreach($results as $post)
	   	{
	   		$sdata['insurance_logo1']=$post->insurance_logo;
       		        $sdata['insurance_name1']=$post->insurance_name;
	    	        $sdata['insurance_id1']=$post->insurance_id;
	    	        $sdata['diposit_name1']=$post->diposit_name;
		 	$sdata['diposit_type1']=$post->diposit_type;
		  	$sdata['diposit_duration1']=$post->diposit_duration;
		   	$sdata['diposit_amount1']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate1']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit1']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount1']=$post->final_amount;
  		}
  	}
  	else
  	{
 		$this->session->unset_userdata('insurance_logo1');  
	 	$this->session->unset_userdata('insurance_name1');
 	 	$this->session->unset_userdata('insurance_id1');
  	 	$this->session->unset_userdata('diposit_name1');
   	 	$this->session->unset_userdata('diposit_type1');
	 	$this->session->unset_userdata('diposit_amount1');
	 	$this->session->unset_userdata('diposit_interest_rate1');
	        $this->session->unset_userdata('diposit_monthy_benefit1');
	        $this->session->unset_userdata('final_amount1');
		$this->session->unset_userdata('diposit_duration1');
	}
	  
	}
	 
	if($insurance_name2)
	{
      	$this->load->model('insurance_front_ui_model','com_model');
        $results= $this->com_model->compare2($installment_amount,$installment_name,$deposit_year,$insurance_name2);
		if($results)
       {
	    foreach($results as $post)
	   	{
	   		$sdata['insurance_logo2']=$post->insurance_logo;
       		        $sdata['insurance_name2']=$post->insurance_name;
	    	        $sdata['diposit_name2']=$post->diposit_name;
		 	$sdata['diposit_type2']=$post->diposit_type;
		  	$sdata['diposit_duration2']=$post->diposit_duration;
		   	$sdata['diposit_amount2']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate2']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit2']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount2']=$post->final_amount;
 		}
 	}
	 
	 else
  	{
		$this->session->unset_userdata('insurance_logo2');  
		$this->session->unset_userdata('insurance_name2');
 	 	$this->session->unset_userdata('insurance_id2');
  	 	$this->session->unset_userdata('diposit_name2');
   	 	$this->session->unset_userdata('diposit_type2');
	 	$this->session->unset_userdata('diposit_amount2');
	 	$this->session->unset_userdata('diposit_interest_rate2');
	        $this->session->unset_userdata('diposit_monthy_benefit2');
	        $this->session->unset_userdata('final_amount2');
		$this->session->unset_userdata('diposit_duration2');
	}
	
	}
	   
	 if($insurance_name3)
		{
			$this->load->model('insurance_front_ui_model','com_model');
         	        $results= $this->com_model->compare3($installment_amount,$installment_name,$deposit_year,$insurance_name3);

		if($results)
       	{
	    	foreach($results as $post)
	   	{
	   		$sdata['insurance_logo3']=$post->insurance_logo;
       		        $sdata['insurance_name3']=$post->insurance_name;
	    	        $sdata['diposit_name3']=$post->diposit_name;
		 	$sdata['diposit_type3']=$post->diposit_type;
		  	$sdata['diposit_duration3']=$post->diposit_duration;
		   	$sdata['diposit_amount3']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate3']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit3']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount3']=$post->final_amount;
		}
  	}
	
	else
  	{
		$this->session->unset_userdata('insurance_logo3');  
	 	$this->session->unset_userdata('insurance_name3');
 	 	$this->session->unset_userdata('insurance_id3');
  	 	$this->session->unset_userdata('diposit_name3');
   	 	$this->session->unset_userdata('diposit_type3');
	 	$this->session->unset_userdata('diposit_amount3');
	 	$this->session->unset_userdata('diposit_interest_rate3');
	   	$this->session->unset_userdata('diposit_monthy_benefit3');
	        $this->session->unset_userdata('final_amount3');
		$this->session->unset_userdata('diposit_duration3');
	}
	  
   	}
	
		$sdata['installment_amount']=$installment_amount;
    	        $sdata['installment_name']=$installment_name;
	  	$sdata['deposit_year']=$deposit_year;
      	        $this->session->set_userdata($sdata);
	        $data=array();
		$this->load->model('insurance_front_ui_model','i_model');
                $a['insurance_name']= $this->i_model->search_all_insurance();
		$data['maincontent']=$this->load->view('front_ui/insurance/compare',$a,true);
		$data['title']='Compare Deposit';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);		
	}

 /*****************Show All Insurance List in Form************Different Mastering*******/
 	
 	public function insurance_search()
	{
		$data=array();
		$this->load->model('insurance_front_ui_model','i_model');
                $a['all_insurance']= $this->i_model->select_all_insurance();
		$a['all_cat']= $this->i_model->cat();
                $data['maincontent']=$this->load->view('front_ui/insurance/show_all_insurance',$a,true);
		$data['title']='Insurance Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
/**********************Show All Insurance Category In Form****Different Mastering*****************/	
	
	public function insurance_search_by_cat()
	{
		$cat=$this->input->post('insurance_cat');
		$data=array();
		$this->load->model('insurance_front_ui_model','i_model');
                $a['all_insurance']= $this->i_model->select_insurance_by_cat($cat);
		$a['all_cat']= $this->i_model->cat();
                $data['maincontent']=$this->load->view('front_ui/insurance/show_all_insurance',$a,true);
		$data['title']='Insurance Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);	
	}


/*************************Show Comparison Data For Diposit Table****************/	

	public function check_compaire()
	{     
		$p_id = $this->input->post('p_id');
		$type = $this->input->post('type');
		$pids[]=$this->input->post('pids');
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/insurance/compare_two_data');
	}

        
    public function insurance_atm_locator() 
    {        
		$data=array();
		$a['all_insurance_branch']= $this->insurance_front_ui_model->select_all_insurance();
                $data['maincontent']=$this->load->view('front_ui/insurance/insurance_atm_locator',$a,true);
		$data['title']='Insurance Branch Locator';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

   


}
