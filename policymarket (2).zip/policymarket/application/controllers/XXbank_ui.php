<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bank_Ui extends CI_Controller {
	
	public function index()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
	  	$data['all_news']= $this->b_model->select_all_news();
	  	$data['all_bank']= $this->front_ui_model->select_bank();
		$this->load->view('index',$data);
		$this->load->library('session');
		$this->session->sess_destroy();	
	}

    public function news_details($news_id) 
    {        
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$data['all_news_info']= $this->b_model->select_all_news_id($news_id);
                $data['maincontent']=$this->load->view('front_ui/bank/policy_news_details',$data,true);
		$data['title']='News Details';
		$data['sidebar']=1;
		$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
    }

	/**************For Bank Home Page*****************/
	
	public function bank_show()
	{
		$data=array();
        $data['maincontent']=$this->load->view('front_ui/bank/bank_page','',true);
		$data['title']='Bank';
		$data['sidebar']=1;
		$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	

	/********Diposit Part***************/
	
	public function diposit_search()
	{
		$data=array();
	 	$this->load->model('front_ui_model','b_model');
		$a['default_deposit']=$this->b_model->default_deposit_select();
		$a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();  
		$data['maincontent']=$this->load->view('front_ui/bank/form_diposit',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
	
	/*******************Search All Diposit Data*********************Different Mastering*/
	 
	public function check_diposit_info()
    { 
		$installment_amount=$this->input->post('installment_amount'); 
		$installment_name=$this->input->post('installment_name');
		$year=$this->input->post('deposit_year'); 
		$this->load->model('front_ui_model','b_model');
        $a['results']= $this->b_model->search_diposit_info($installment_amount,$installment_name,$year);
      	$a['default_deposit']=$this->b_model->default_deposit_select();  //default depisit data select
			 
		if($a['results'])
		{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();
        $data['maincontent']=$this->load->view('front_ui/bank/table_show_deposit1',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		}
		   else
		   
		   	{
		    $data=array();
			$a['message']='We are not found anything from your criteria!';
                        $this->load->model('front_ui_model','b_model');
		        $a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		        $a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		        $a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();
		 	$data['maincontent']=$this->load->view('front_ui/bank/table_show_deposit1',$a,true);
			$data['title']='Deposit Form';
			//$data['sidebar']=1;
			//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
			}
    }
 

/*************************Diposit Compare.three bank compare.Show in header named "Diposit Compare" *********************/
  	
  	public function diposit_compare()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();
        $a['bank_name']= $this->b_model->search_all_bank();
        $data['maincontent']=$this->load->view('front_ui/bank/compare',$a,true);
		$data['title']='Deposit Compare';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	

	/*************part of Deposit Compare. Individual Bank Data Search**********************/
	
	public function compare()
	{
		$installment_amount=$this->input->post('installment_amount',true);
                $installment_name=$this->input->post('installment_name',true);
		$deposit_year=$this->input->post('deposit_year',true);
		$bank_name1=$this->input->post('bank_name1');
		$bank_name2=$this->input->post('bank_name2');
		$bank_name3=$this->input->post('bank_name3');
				
		if($bank_name1)
		{
		
      	$this->load->model('front_ui_model','com_model');
        $results= $this->com_model->compare1($installment_amount,$installment_name,$deposit_year,$bank_name1);
      
 		if($results)
       {
	    	foreach($results as $post)
	   	{
	   		$sdata['bank_logo1']=$post->bank_logo;
       		$sdata['bank_name1']=$post->bank_name;
	    	$sdata['bank_id1']=$post->bank_id;
	    	$sdata['diposit_name1']=$post->diposit_name;
		 	$sdata['diposit_type1']=$post->diposit_type;
		  	$sdata['diposit_duration1']=$post->diposit_duration;
		   	$sdata['diposit_amount1']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate1']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit1']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount1']=$post->final_amount;
  		}
  	}
  	else
  	{
 		$this->session->unset_userdata('bank_logo1');  
	 	$this->session->unset_userdata('bank_name1');
 	 	$this->session->unset_userdata('bank_id1');
  	 	$this->session->unset_userdata('diposit_name1');
   	 	$this->session->unset_userdata('diposit_type1');
	 	$this->session->unset_userdata('diposit_amount1');
	 	$this->session->unset_userdata('diposit_interest_rate1');
	    $this->session->unset_userdata('diposit_monthy_benefit1');
	    $this->session->unset_userdata('final_amount1');
		$this->session->unset_userdata('diposit_duration1');
	}
	  
	}
	 
	if($bank_name2)
	{
      	$this->load->model('front_ui_model','com_model');
        $results= $this->com_model->compare2($installment_amount,$installment_name,$deposit_year,$bank_name2);
		if($results)
       {
	    foreach($results as $post)
	   	{
	   		$sdata['bank_logo2']=$post->bank_logo;
       		$sdata['bank_name2']=$post->bank_name;
	    	$sdata['diposit_name2']=$post->diposit_name;
		 	$sdata['diposit_type2']=$post->diposit_type;
		  	$sdata['diposit_duration2']=$post->diposit_duration;
		   	$sdata['diposit_amount2']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate2']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit2']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount2']=$post->final_amount;
 		}
 	}
	 
	 else
  	{
		$this->session->unset_userdata('bank_logo2');  
		$this->session->unset_userdata('bank_name2');
 	 	$this->session->unset_userdata('bank_id2');
  	 	$this->session->unset_userdata('diposit_name2');
   	 	$this->session->unset_userdata('diposit_type2');
	 	$this->session->unset_userdata('diposit_amount2');
	 	$this->session->unset_userdata('diposit_interest_rate2');
	    $this->session->unset_userdata('diposit_monthy_benefit2');
	    $this->session->unset_userdata('final_amount2');
		$this->session->unset_userdata('diposit_duration2');
	}
	
	}
	   
	 if($bank_name3)
		{
			$this->load->model('front_ui_model','com_model');
         	$results= $this->com_model->compare3($installment_amount,$installment_name,$deposit_year,$bank_name3);

		if($results)
       	{
	    	foreach($results as $post)
	   	{
	   		$sdata['bank_logo3']=$post->bank_logo;
       		$sdata['bank_name3']=$post->bank_name;
	    	$sdata['diposit_name3']=$post->diposit_name;
		 	$sdata['diposit_type3']=$post->diposit_type;
		  	$sdata['diposit_duration3']=$post->diposit_duration;
		   	$sdata['diposit_amount3']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate3']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit3']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount3']=$post->final_amount;
		}
  	}
	
	else
  	{
		$this->session->unset_userdata('bank_logo3');  
	 	$this->session->unset_userdata('bank_name3');
 	 	$this->session->unset_userdata('bank_id3');
  	 	$this->session->unset_userdata('diposit_name3');
   	 	$this->session->unset_userdata('diposit_type3');
	 	$this->session->unset_userdata('diposit_amount3');
	 	$this->session->unset_userdata('diposit_interest_rate3');
	   	$this->session->unset_userdata('diposit_monthy_benefit3');
	    $this->session->unset_userdata('final_amount3');
		$this->session->unset_userdata('diposit_duration3');
	}
	  
   	}
	
		$sdata['installment_amount']=$installment_amount;
    	$sdata['installment_name']=$installment_name;
	  	$sdata['deposit_year']=$deposit_year;
      	$this->session->set_userdata($sdata);
	    $data=array();
		$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();
        $a['bank_name']= $this->b_model->search_all_bank();
		$data['maincontent']=$this->load->view('front_ui/bank/compare',$a,true);
		$data['title']='Compare Deposit';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);		
	}


/***************************Loan Search main form*******************/

 	public function loan_search()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$a['default_loan_deposit']=$this->b_model->default_loan_select(); 
        $a['all_loan']= $this->b_model->select_all_published_loan_category();
        $data['maincontent']=$this->load->view('front_ui/bank/form_loan',$a,true);
		$data['title']='Loan Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);	
	}
	

/*********************data search for loan search form********************/	
 	
 	public function check_loan()
   	{

    	$bank_loan_id=$this->input->post('bank_loan_id'); 
		$this->load->model('front_ui_model','b_model');
        $a['results']= $this->b_model->search_loan_info($bank_loan_id);
        $a['all_loan']= $this->b_model->select_all_published_loan_category();
			 
		if($a['results'])
		{
		  	$data=array();
			$data['maincontent']= $this->load->view('front_ui/bank/table_show_loan1',$a,true); 
			$data['title']='Bank Loan';
			//$data['sidebar']=1;
		  	//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
		}
		   	else
		   	{
		  		$data=array();
				$a['message']='We are not found anything from your criteria!';
		 		$data['maincontent']=$this->load->view('front_ui/bank/form_loan',$a,true);
				$data['title']='Deposit Form';
				//$data['sidebar']=1;
				//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
				$this->load->view('front_ui/main_content',$data);
			}   
	}
 
 /*****************Show All Bank List in Form************Different Mastering*******/
 	
 	public function bank_search()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $a['all_bank']= $this->b_model->select_bank();
		$a['all_cat']= $this->b_model->cat();
        $data['maincontent']=$this->load->view('front_ui/bank/show_all_bank',$a,true);
		$data['title']='Bank Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
/**********************Show All Bank Category In Form****Different Mastering*****************/	
	
	public function bank_search_by_cat()
	{
		$cat=$this->input->post('bank_cat');
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $a['all_bank']= $this->b_model->select_bank_by_cat($cat);
		$a['all_cat']= $this->b_model->cat();
        $data['maincontent']=$this->load->view('front_ui/bank/show_all_bank',$a,true);
		$data['title']='Bank Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);	
	}

/****************************Bank Foreign Money Exchange Rate*****************************/
	
	public function money_exchange()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $a['exchange_rate']= $this->b_model->select_exchange_type();
		$a['default']=$this->b_model->default_usd_select();
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
        $data['maincontent']=$this->load->view('front_ui/bank/bank_exchange_rates',$a,true);
		$data['title']='Bank Exchange Rate';
		$this->load->view('front_ui/main_content',$data);
	}
	
	
	/***************************bank foreign Exchange rate by currency type wise**********************/
	
	public function exchange_rate_currency_wise()
	{
		$currency_type=$this->input->post('currency_type',true);
		$this->load->model('front_ui_model','b_model');
	  	$a['exchange_rate']= $this->b_model->select_exchange_type();
        $a['currency_wise_rate']= $this->b_model->currency_type($currency_type);	 
		if($a['currency_wise_rate'])
		{
		$data=array();
        $data['maincontent']=$this->load->view('front_ui/bank/bank_exchange_rates',$a,true);
		$data['title']='Bank Exchange Rate';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		}
		   
		else
		{
			$data=array();
			$a['message']='No Result Found!';
		 	$a['default']=$this->b_model->default_usd_select();
        	$data['maincontent']=$this->load->view('front_ui/bank/bank_exchange_rates',$a,true);
			$data['title']='Bank Exchange Rate';
			//$data['sidebar']=1;
			//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
		}
    }

/*************************Show Comparison Data For Diposit Table****************/	

	public function check_compaire()
	{     
		$p_id = $this->input->post('p_id');
		$type = $this->input->post('type');
		$pids[]=$this->input->post('pids');
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/bank/compare_two_data');
	}

	public function check_compaire_bank_loan()
	{     
		$p_id = $this->input->post('p_id');
		$type = $this->input->post('type');
		$pids[]=$this->input->post('pids');
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/bank/compare_two_data_bank_loan');
    }
        
    public function bank_atm_locator() 
    {        
		$data=array();
		$a['all_bank']= $this->front_ui_model->select_bank();
        $data['maincontent']=$this->load->view('front_ui/bank/bank_atm_locator',$a,true);
		$data['title']='Bank ATM Locator';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

    public function payment_getway() 
    {        
		$data=array();
		$a['all_payment_getway']= $this->front_ui_model->select_all_payment_getway();
        $data['maincontent']=$this->load->view('front_ui/bank/payment_getway',$a,true);
		$data['title']='Payment Getway';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

    public function remittance() 
    {        
		$data=array();
		$a['all_remittance']= $this->front_ui_model->select_all_remittance();
        $data['maincontent']=$this->load->view('front_ui/bank/remittance',$a,true);
		$data['title']='Remittance';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

    public function share_market()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/bank/share_market_page','',true);
		$data['title']='Share Market';
		$data['sidebar']=1;
		$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}

    public function b_share_market() 
    {        
		$data=array();
		$a['all_share_market']= $this->front_ui_model->select_all_share_market();
        $data['maincontent']=$this->load->view('front_ui/bank/share_market',$a,true);
		$data['title']='Share Market';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

    public function i_share_market() 
    {        
		$data=array();
		$a['all_share_market']= $this->front_ui_model->select_all_share_market();
        $data['maincontent']=$this->load->view('front_ui/bank/i_share_market',$a,true);
		$data['title']='Share Market';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
    }

    public function privacy_policy()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/bank/privacy_policy','',true);
		$data['title']='Privacy Policy';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
        public function mail_p()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/bank/mail','',true);
		$data['title']='Mail';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}

	public function terms_conditions()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/bank/terms_conditions','',true);
		$data['title']='Terms & Conditions';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}


}




/*================== Mobile Apps Part Start =================*/

	/*===bank deposit===*/
	public function get_apps_deposit()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$data['default_deposit']=$this->b_model->default_deposit_select();
		$this->load->view('apps/bank/deposit/get_apps_deposit',$data);
	}
	
	public function apps_deposit_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit']=$this->b_model->select_all_bank_deposit();
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();  
		$data['spinncontent']= $a;
		$this->load->view('apps/bank/deposit/apps_deposit_spinner',$data);
	}
	
	public function apps_deposit_name_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit_name']=$this->b_model->select_all_bank_deposit_name();
		$data['spinncontent']= $a;
		$this->load->view('apps/bank/deposit/bank_deposit_name_spinner',$data);
	}
	
	public function apps_deposit_year_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();  
		$data['spinncontent']= $a;
		$this->load->view('apps/bank/deposit/bank_deposit_year',$data);
	}
	
	public function apps_bank_deposit_quest(){
		$data= array();		
		$this->load->model('front_ui_model','b_model');
		$installment_amount= $this->input->post('installamount'); 
		$installment_name= $this->input->post('depositname');
		$year= $this->input->post('depositYear'); 
        $data['questResults']= $this->b_model->search_diposit_info($installment_amount,$installment_name,$year);
		$this->load->view('apps/bank/deposit/get_apps_quest',$data);	
	}
	
	/*=== Bank Loan ===*/
	public function get_apps_loan()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$data['default_loan_deposit']=$this->b_model->default_loan_select(); 
		$this->load->view('apps/bank/loan/get_apps_loan',$data);
	}
	
	public function apps_loan_spinner()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $data['all_loan_cat']= $this->b_model->select_all_published_loan_category();
		$this->load->view('apps/bank/loan/apps_loan_spinner',$data);	
	}
	
	public function apps_bank_loan_quest(){
		$data= array();		
		$bank_loan_id=$this->input->post('bank_loan_id'); 
		$this->load->model('front_ui_model','b_model');
		$data['loanQuestResults']= $this->b_model->search_loan_info($bank_loan_id);		
		$this->load->view('apps/bank/loan/loan_apps_quest',$data);		
	}
	
	
	/*=== Money Exchange ===*/
	public function get_apps_exchange()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		$data['default_exchange']=$this->b_model->default_usd_select();
		$this->load->view('apps/bank/exchange/get_apps_exchange',$data);
	}
	
	public function apps_exchange_spinner()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $data['exchange_rate']= $this->b_model->select_exchange_type();
		$this->load->view('apps/bank/exchange/apps_exchange_spinner',$data);	
	}
	
	public function apps_money_exchange_quest(){
		$data= array();		
		$currency=$this->input->post('currency_type'); 
		$this->load->model('front_ui_model','b_model');
		$data['exchangeResults']= $this->b_model->currency_type($currency);		
		$this->load->view('apps/bank/exchange/apps_money_exchange_quest',$data);		
	}
	
	
	/*=== Bank Information ===*/
	public function get_apps_bankinfo()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
		//$data['default_exchange']=$this->b_model->default_usd_select();
		$data['all_bank']= $this->b_model->select_bank();
		$this->load->view('apps/bank/bankinfo/get_apps_bankinfo',$data);
	}
	
	public function apps_bankinfo_spinner()
	{
		$data=array();
		$this->load->model('front_ui_model','b_model');
        $data['all_cat']= $this->b_model->cat();
		$this->load->view('apps/bank/bankinfo/apps_bankinfo_spinner',$data);	
	}
	
	public function apps_bankinfo_quest(){
		$data= array();		
		$cat=$this->input->post('bank_cat');
		$this->load->model('front_ui_model','b_model');
		//$data['all_bank']= array('rsd', 'mst');
        $data['all_bank']= $this->b_model->select_bank_by_cat($cat);
		$this->load->view('apps/bank/bankinfo/apps_bankinfo_quest',$data);		
	}
	
	
	
	
	
	/*=== Payment Getway Part ===*/
	public function apps_payment_getway() 
    {        
		$data=array();
		$data['all_payment_getway']= $this->front_ui_model->select_all_payment_getway();
		$this->load->view('apps/payment/apps_payment_getway',$data);
    }
	
	/*=== Remittance Part ===*/
	public function apps_remittance() 
    {        
		$data=array();
		$data['all_remittance']= $this->front_ui_model->select_all_remittance();
		$this->load->view('apps/remittance/apps_remittance',$data);
    }
	
	/*=== Share Market Part ===*/
	public function apps_isharemarket() 
    {        
		$data=array();
		$data['all_share_market']= $this->front_ui_model->select_all_share_market();
		$this->load->view('apps/sharemarket/apps_isharemarket',$data);
    }
/*================== Mobile Apps Part End =================*/	