<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurance_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    public function index()
    {
    $data=array();
        $data['admin_main_content']=$this->load->view('admin/admin_dashboard','',true);
        $this->load->view('admin/admin_master',$data);
    }

    /*
        * ------- Add Insurance Category All Information Start form Line 19 to 88--------- *
    */

    public function add_insurance_category()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/insurance/add_insurance_category_form','',true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_insurance_category()
    {
        $data=array();
        $data['insurance_category_name']=$this->input->post('insurance_category_name',true);
        $data['insurance_category_description']=$this->input->post('insurance_category_description',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->save_insurance_category_info($data);
        $sdata=array();
        $sdata['message']='Save Insurance Category Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('insurance_super_admin/add_insurance_category');
    }

    public function manage_insurance_category()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['all_insurance_category']=$this->sa_model->select_all_insurance_category();
        $data['admin_main_content']=$this->load->view('admin/insurance/manage_insurance_category',$data,true);
        $this->load->view('admin/admin_master',$data);
       
    }

    public function published_insurance_category($insurance_category_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_id($insurance_category_id);
        redirect('insurance_super_admin/manage_insurance_category');
    }
    public function unpublished_insurance_category($insurance_category_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_id($insurance_category_id);
        redirect('insurance_super_admin/manage_insurance_category');
    }

    public function edit_insurance_category($insurance_category_id)
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['insurance_category_info']=$this->insurance_super_admin_model->select_insurance_category_info_by_id($insurance_category_id);
        $data['admin_main_content']=$this->load->view('admin/insurance/edit_insurance_category',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_insurance_category()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $insurance_category_id=$this->input->post('insurance_category_id');
        $data['insurance_category_name']=$this->input->post('insurance_category_name');
        $data['insurance_category_description']=$this->input->post('insurance_category_description');
        $data['publication_status']=$this->input->post('publication_status');
        $this->insurance_super_admin_model->update_insurance_category_info($data,$insurance_category_id);
        redirect('insurance_super_admin/manage_insurance_category');
    }

    public function delete_insurance_category($insurance_category_id)
    {
        $this->insurance_super_admin_model->delete_category_by_id($insurance_category_id);
        redirect('insurance_super_admin/manage_insurance_category');
    }

    /*
        * ------- Add Insurance Category All Information End --------- *
    */

    /*
        * ------- Add Insurance Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_insurance_name()
    {
        $data=array();
        $data['all_published_insurance_category']=$this->insurance_super_admin_model->select_all_published_insurance_category();
        $data['admin_main_content']=$this->load->view('admin/insurance/add_insurance_name_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_insurance_name()
    {
        $data=array();
        $data['insurance_name']=$this->input->post('insurance_name',true);
        $data['insurance_category_id']=$this->input->post('insurance_category_id',true);
        $data['insurance_office_address']=$this->input->post('insurance_office_address',true);
        $data['insurance_website_url']=$this->input->post('insurance_website_url',true);
        $data['insurance_atm_url']=$this->input->post('insurance_atm_url',true);
        $data['insurance_phone_number']=$this->input->post('insurance_phone_number',true);
        $data['insurance_hot_line_number']=$this->input->post('insurance_hot_line_number',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/insurance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '100';
        $config['max_width']  = '1024';
        $config['max_height']  = '768';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('insurance_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['insurance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->save_insurance_name_info($data);
        $sdata=array();
        $sdata['message']='Save Insurance Name Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('insurance_super_admin/add_insurance_name');
    }

    public function manage_insurance_name()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['all_insurance_name']=$this->sa_model->select_all_insurance_name();
        $data['admin_main_content']=$this->load->view('admin/insurance/manage_insurance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_insurance_name($insurance_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_insurance_id($insurance_id);
        redirect('insurance_super_admin/manage_insurance_name');
    }
    public function unpublished_insurance_name($insurance_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_insurance_id($insurance_id);
        redirect('insurance_super_admin/manage_insurance_name');
    }

    public function edit_insurance_name($insurance_id)
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['insurance_name_info']=$this->insurance_super_admin_model->select_insurance_name_info_by_id($insurance_id);
        $data['all_published_insurance_category']=$this->insurance_super_admin_model->select_all_published_insurance_category();
        $data['admin_main_content']=$this->load->view('admin/insurance/edit_insurance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_insurance_logo($insurance_id)
    {
        $data=array();
        $data['img']=$this->insurance_super_admin_model->delete_insurance_logo_by_id($insurance_id);
        $data['all_published_insurance_category']=$this->insurance_super_admin_model->select_all_published_insurance_category();
        $data['insurance_name_info']=$this->insurance_super_admin_model->select_insurance_name_info_by_id($insurance_id);
        $data['admin_main_content']=$this->load->view('admin/insurance/edit_insurance_name',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_insurance_name()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $insurance_id=$this->input->post('insurance_id');
        $data['insurance_name']=$this->input->post('insurance_name');
        $data['insurance_category_id']=$this->input->post('insurance_category_id');
        $data['insurance_office_address']=$this->input->post('insurance_office_address');
        $data['insurance_website_url']=$this->input->post('insurance_website_url');
        $data['insurance_atm_url']=$this->input->post('insurance_atm_url');
        $data['insurance_phone_number']=$this->input->post('insurance_phone_number');
        $data['insurance_hot_line_number']=$this->input->post('insurance_hot_line_number');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/insurance_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('insurance_logo'))
        {
                 $fdata = $this->upload->data();
                $data['insurance_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->insurance_super_admin_model->update_insurance_name_info($data,$insurance_id);
        redirect('insurance_super_admin/manage_insurance_name');
    }

    public function delete_insurance_name($insurance_id)
    {
        $this->insurance_super_admin_model->delete_category_by_insurance_id($insurance_id);
        redirect('insurance_super_admin/manage_insurance_name');
    }

    /*
        * ------- Add Insurance Name All Information End --------- *
    */

    /*
        * ------- Add Insurance Deposit Information All Information Start form Line 226 to 303 --------- *
    */

    public function add_insurance_deposit_information()
    {
        $data=array();
        $data['all_published_insurance_category_id']=$this->insurance_super_admin_model->select_all_published_insurance_category_id();
        $data['admin_main_content']=$this->load->view('admin/insurance/add_insurance_deposit_information_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_insurance_deposit_information()
    {
        $data=array();
        $data['insurance_id']=$this->input->post('insurance_id',true);
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration',true);
        $data['diposit_amount']=$this->input->post('diposit_amount',true);
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate',true);
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit',true);
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['insurance_feature']=$this->input->post('insurance_feature',true);
        $data['publication_status']=$this->input->post('publication_status',true);
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->save_insurance_deposit_information_info($data);
        $sdata=array();
        $sdata['message']='Save Insurance Deposit Information Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('insurance_super_admin/add_insurance_deposit_information');
    }

    public function manage_insurance_deposit_information()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['all_insurance_deposit_information']=$this->sa_model->select_all_insurance_deposit_information();
        $data['admin_main_content']=$this->load->view('admin/insurance/manage_insurance_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_insurance_deposit_information($insurance_diposit_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_publication_status_by_insurance_deposit_information($insurance_diposit_id);
        redirect('insurance_super_admin/manage_insurance_deposit_information');
    }
    public function unpublished_insurance_deposit_information($insurance_diposit_id)
    {
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $this->sa_model->update_unpublication_status_by_insurance_deposit_information($insurance_diposit_id);
        redirect('insurance_super_admin/manage_insurance_deposit_information');
    }

    public function edit_insurance_deposit_information($insurance_diposit_id)
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $data['insurance_deposit_information_info']=$this->insurance_super_admin_model->select_insurance_deposit_information_info_by_id($insurance_diposit_id);
        $data['all_published_insurance_category_id']=$this->insurance_super_admin_model->select_all_published_insurance_category_id();
        $data['admin_main_content']=$this->load->view('admin/insurance/edit_insurance_deposit_information',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_insurance_deposit_information()
    {
        $data=array();
        $this->load->model('insurance_super_admin_model', 'sa_model');
        $insurance_diposit_id=$this->input->post('insurance_diposit_id');
        $data['insurance_id']=$this->input->post('insurance_id');
        $data['diposit_name']=$this->input->post('diposit_name',true);
        $data['diposit_type']=$this->input->post('diposit_type',true);
        $data['diposit_duration']=$this->input->post('diposit_duration');
        $data['diposit_amount']=$this->input->post('diposit_amount');
        $data['diposit_interest_rate']=$this->input->post('diposit_interest_rate');
        $data['diposit_monthy_benefit']=$this->input->post('diposit_monthy_benefit');
        $data['final_amount']=$this->input->post('final_amount',true);
        $data['insurance_feature']=$this->input->post('insurance_feature',true);
        $data['publication_status']=$this->input->post('publication_status');
        $this->insurance_super_admin_model->update_insurance_deposit_information_info($data,$insurance_diposit_id);
        redirect('insurance_super_admin/manage_insurance_deposit_information');
    }

    public function delete_insurance_deposit_information($insurance_diposit_id)
    {
        $this->insurance_super_admin_model->delete_category_by_insurance_deposit_information($insurance_diposit_id);
        redirect('insurance_super_admin/manage_insurance_deposit_information');
    }

    /*
        * ------- Add Insurance Deposit Information All Information End --------- *
    */
    
    public function logout()
    {
        $this->session->unset_userdata('user_name');
        $this->session->unset_userdata('admin_id');
        $sdata=array();
        $sdata['message']='You are Successfully Logout !';
        $this->session->set_userdata($sdata);
        redirect('admin');
        
    }

}
