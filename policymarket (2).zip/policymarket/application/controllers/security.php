<?php
class Security extends CI_Controller{
    public function __construct() {
        parent::__construct();
    }
    
    public function index()
    {
        $this->load->view('admin/admin_login');
    }

    public function check_admin_login()
    {

    	$admin_user_name=$this->input->post('admin_user_name',true);
        $admin_password=$this->input->post('admin_password',true);
        $this->load->model('admin_model','a_model');
        $result= $this->a_model->check_admin_login_info($admin_user_name,$admin_password);
        $sdata=array();

    	if($result)
       {
           $sdata['user_name']=$result->admin_user_name;
           $sdata['admin_id']=$result->admin_id;
           $this->session->set_userdata($sdata);
           redirect('bank_super_admin');
       }
       else{
           $sdata['message']='Your User Name or Password Invalide !';
           $this->session->set_userdata($sdata);
           $this->load->view('admin/admin_login');
       }
    
}
}