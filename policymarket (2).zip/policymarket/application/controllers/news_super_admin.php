<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News_Super_Admin extends CI_Controller{
    public function __construct() 
    {
        parent::__construct();
    }

    /*
        * ------- Add Bank Name All Information Start form Line 98 to 216 --------- *
    */

    public function add_news_title()
    {
        $data=array();
        $data['admin_main_content']=$this->load->view('admin/news/add_news_title_form',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function save_news_title()
    {
        $data=array();
        $data['news_title']=$this->input->post('news_title',true);
        $data['news_short_details']=$this->input->post('news_short_details',true);
        $data['news_details']=$this->input->post('news_details',true);
        $data['publication_status']=$this->input->post('publication_status',true);

        /*
         * ------- Start Image Upload--------- *
         */
        $config['upload_path'] = 'image/news_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ( ! $this->upload->do_upload('news_logo'))
        {
                $error =  $this->upload->display_errors();
                echo $error;
                exit();
        }
        else
        {
                $fdata = $this->upload->data();
                $data['news_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        /*
         * --------End Image Upload--------- *
         */

        $this->load->model('news_super_admin_model', 'ns_model');
        $this->ns_model->save_news_title_info($data);
        $sdata=array();
        $sdata['message']='Save News Title Successfully !';
        $this->session->set_userdata($sdata);
        
        redirect('news_super_admin/add_news_title');
    }

    public function manage_news_title()
    {
        $data=array();
        $this->load->model('news_super_admin_model', 'ns_model');
        $data['all_news_title']=$this->ns_model->select_all_news_title();
        $data['admin_main_content']=$this->load->view('admin/news/manage_news_title',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function published_news_title($news_id)
    {
        $this->load->model('news_super_admin_model', 'ns_model');
        $this->ns_model->update_publication_status_by_news_id($news_id);
        redirect('news_super_admin/manage_news_title');
    }
    public function unpublished_news_title($news_id)
    {
        $this->load->model('news_super_admin_model', 'ns_model');
        $this->ns_model->update_unpublication_status_by_news_id($news_id);
        redirect('news_super_admin/manage_news_title');
    }

    public function edit_news_title($news_id)
    {
        $data=array();
        $this->load->model('news_super_admin_model', 'ns_model');
        $data['news_title_info']=$this->news_super_admin_model->select_news_title_info_by_id($news_id);
        $data['admin_main_content']=$this->load->view('admin/news/edit_news_title',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function delete_news_logo($news_id)
    {
        $data=array();
        $data['img']=$this->news_super_admin_model->delete_news_logo_by_id($news_id);
        $data['news_title_info']=$this->news_super_admin_model->select_news_title_info_by_id($news_id);
        $data['admin_main_content']=$this->load->view('admin/news/edit_news_title',$data,true);
        $this->load->view('admin/admin_master',$data);
    }

    public function update_news_title()
    {
        $data=array();
        $this->load->model('news_super_admin_model', 'ns_model');
        $news_id=$this->input->post('news_id');
        $data['news_title']=$this->input->post('news_title');
        $data['news_short_details']=$this->input->post('news_short_details');
        $data['news_details']=$this->input->post('news_details');
        /*
         * ------- Start Image Upload---------
        */
        $config['upload_path'] = 'image/news_logo/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = '';
        $config['max_width']  = '';
        $config['max_height']  = '';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        $error='';
        $fdata=array();
        if ($this->upload->do_upload('news_logo'))
        {
         $fdata = $this->upload->data();
         $data['news_logo']=$config['upload_path'] .$fdata['file_name'];
        }
        
        
        /*
         * --------End Image Upload---------
        */
        
        
        $data['publication_status']=$this->input->post('publication_status');
        $this->news_super_admin_model->update_news_title_info($data,$news_id);
        redirect('news_super_admin/manage_news_title');
    }

    public function delete_news_title($news_id)
    {
        $this->news_super_admin_model->delete_category_by_news_id($news_id);
        redirect('news_super_admin/manage_news_title');
    }

    /*
        * ------- Add Bank Name All Information End --------- *
    */

}
