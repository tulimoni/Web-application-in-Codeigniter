<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Non_Bank_Finance_Ui extends CI_Controller {
	
	/**************For Non Bank Finance Home Page*****************/
	
	public function non_bank_finance_show()
	{
		$data=array();
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/non_bank_finance_page','',true);
		$data['title']='Non Bank Finance';
		$data['sidebar']=1;
		$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
	}
	

	/********Deposit Part***************/
	
	public function diposit_search()
	{
		$data=array();
	 	$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$a['default_deposit']=$this->nbf_model->default_deposit_select();
		$a['all_non_bank_finance_deposit']=$this->nbf_model->select_all_non_bank_finance_deposit();
		$a['all_non_bank_finance_deposit_name']=$this->nbf_model->select_all_non_bank_finance_deposit_name();
		$a['all_non_bank_finance_deposit_duration']=$this->nbf_model->select_all_non_bank_finance_deposit_duration();   
		$data['maincontent']=$this->load->view('front_ui/non_bank_finance/form_diposit',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
	
	/*******************Search All Diposit Data*********************Different Mastering*/
	 
	public function check_diposit_info()
    {
		$year=$this->input->post('deposit_year'); 
		$installment_amount=$this->input->post('installment_amount'); 
		$installment_type=$this->input->post('installment_type'); 
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
                $a['results']= $this->nbf_model->search_diposit_info($installment_amount,$installment_type,$year);
      	        $a['default_deposit']=$this->nbf_model->default_deposit_select();  //default depisit data select
			 
		if($a['results'])
		{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$a['all_non_bank_finance_deposit']=$this->nbf_model->select_all_non_bank_finance_deposit();
		$a['all_non_bank_finance_deposit_name']=$this->nbf_model->select_all_non_bank_finance_deposit_name();
		$a['all_non_bank_finance_deposit_duration']=$this->nbf_model->select_all_non_bank_finance_deposit_duration(); 
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/table_show_deposit1',$a,true);
		$data['title']='Deposit Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		}
		   else
		   
		   	{
		        $data=array();
			$a['message']='We are not found anything from your criteria!';
                        $a['all_non_bank_finance_deposit']=$this->nbf_model->select_all_non_bank_finance_deposit();
		        $a['all_non_bank_finance_deposit_name']=$this->nbf_model->select_all_non_bank_finance_deposit_name();
		        $a['all_non_bank_finance_deposit_duration']=$this->nbf_model->select_all_non_bank_finance_deposit_duration();
		 	$data['maincontent']=$this->load->view('front_ui/non_bank_finance/form_diposit',$a,true);
			$data['title']='Deposit Form';
			//$data['sidebar']=1;
			//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
			}
    }
 

/*************************Diposit Compare.three non_bank_finance compare.Show in header named "Diposit Compare" *********************/
  	
  	public function diposit_compare()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
                $a['non_bank_finance_name']= $this->nbf_model->search_all_non_bank_finance();
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/compare',$a,true);
		$data['title']='Deposit Compare';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	

	/*************part of Deposit Compare. Individual Non Bank Finance Data Search**********************/
	
	public function compare()
	{
		$installment_amount=$this->input->post('installment_amount',true);
        $installment_type=$this->input->post('installment_type',true);
		$deposit_year=$this->input->post('deposit_year',true);
		$non_bank_finance_name1=$this->input->post('non_bank_finance_name1');
		$non_bank_finance_name2=$this->input->post('non_bank_finance_name2');
		$non_bank_finance_name3=$this->input->post('non_bank_finance_name3');
				
		if($non_bank_finance_name1)
		{
		
      	$this->load->model('non_bank_finance_front_ui_model','com_model');
        $results= $this->com_model->compare1($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name1);
      
 		if($results)
       {
	    	foreach($results as $post)
	   	{
	   		$sdata['non_bank_finance_logo1']=$post->non_bank_finance_logo;
       		        $sdata['non_bank_finance_name1']=$post->non_bank_finance_name;
	    	        $sdata['non_bank_finance_id1']=$post->non_bank_finance_id;
	    	        $sdata['diposit_name1']=$post->diposit_name;
		 	$sdata['diposit_type1']=$post->diposit_type;
		  	$sdata['diposit_duration1']=$post->diposit_duration;
		   	$sdata['diposit_amount1']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate1']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit1']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount1']=$post->final_amount;
  		}
  	}
  	else
  	{
 		$this->session->unset_userdata('non_bank_finance_logo1');  
	 	$this->session->unset_userdata('non_bank_finance_name1');
 	 	$this->session->unset_userdata('non_bank_finance_id1');
  	 	$this->session->unset_userdata('diposit_name1');
   	 	$this->session->unset_userdata('diposit_type1');
	 	$this->session->unset_userdata('diposit_amount1');
	 	$this->session->unset_userdata('diposit_interest_rate1');
	        $this->session->unset_userdata('diposit_monthy_benefit1');
	        $this->session->unset_userdata('final_amount1');
		$this->session->unset_userdata('diposit_duration1');
	}
	  
	}
	 
	if($non_bank_finance_name2)
	{
      	$this->load->model('non_bank_finance_front_ui_model','com_model');
        $results= $this->com_model->compare2($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name2);
		if($results)
       {
	    foreach($results as $post)
	   	{
	   		$sdata['non_bank_finance_logo2']=$post->non_bank_finance_logo;
       		        $sdata['non_bank_finance_name2']=$post->non_bank_finance_name;
	    	        $sdata['diposit_name2']=$post->diposit_name;
		 	$sdata['diposit_type2']=$post->diposit_type;
		  	$sdata['diposit_duration2']=$post->diposit_duration;
		   	$sdata['diposit_amount2']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate2']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit2']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount2']=$post->final_amount;
 		}
 	}
	 
	 else
  	{
		$this->session->unset_userdata('non_bank_finance_logo2');  
		$this->session->unset_userdata('non_bank_finance_name2');
 	 	$this->session->unset_userdata('non_bank_finance_id2');
  	 	$this->session->unset_userdata('diposit_name2');
   	 	$this->session->unset_userdata('diposit_type2');
	 	$this->session->unset_userdata('diposit_amount2');
	 	$this->session->unset_userdata('diposit_interest_rate2');
	        $this->session->unset_userdata('diposit_monthy_benefit2');
	        $this->session->unset_userdata('final_amount2');
		$this->session->unset_userdata('diposit_duration2');
	}
	
	}
	   
	 if($non_bank_finance_name3)
		{
	         $this->load->model('non_bank_finance_front_ui_model','com_model');
         	 $results= $this->com_model->compare3($installment_amount,$installment_type,$deposit_year,$non_bank_finance_name3);

		 if($results)
       	{
	    	 foreach($results as $post)
	   	{
	   		$sdata['non_bank_finance_logo3']=$post->non_bank_finance_logo;
       		        $sdata['non_bank_finance_name3']=$post->non_bank_finance_name;
	    	        $sdata['diposit_name3']=$post->diposit_name;
		 	$sdata['diposit_type3']=$post->diposit_type;
		  	$sdata['diposit_duration3']=$post->diposit_duration;
		   	$sdata['diposit_amount3']=$post->diposit_amount;
		   	$sdata['diposit_interest_rate3']=$post->diposit_interest_rate;
		   	$sdata['diposit_monthy_benefit3']=$post->diposit_monthy_benefit;
		   	$sdata['final_amount3']=$post->final_amount;
		}
  	}
	
	else
  	{
		$this->session->unset_userdata('non_bank_finance_logo3');  
	 	$this->session->unset_userdata('non_bank_finance_name3');
 	 	$this->session->unset_userdata('non_bank_finance_id3');
  	 	$this->session->unset_userdata('diposit_name3');
   	 	$this->session->unset_userdata('diposit_type3');
	 	$this->session->unset_userdata('diposit_amount3');
	 	$this->session->unset_userdata('diposit_interest_rate3');
	   	$this->session->unset_userdata('diposit_monthy_benefit3');
	        $this->session->unset_userdata('final_amount3');
		$this->session->unset_userdata('diposit_duration3');
	}
	  
   	}
	
		$sdata['installment_amount']=$installment_amount;
    	        $sdata['installment_type']=$installment_type;
	  	$sdata['deposit_year']=$deposit_year;

      	    $this->session->set_userdata($sdata);
	    $data=array();
		
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
                $a['non_bank_finance_name']= $this->nbf_model->search_all_non_bank_finance();
		$data['maincontent']=$this->load->view('front_ui/non_bank_finance/compare',$a,true);
		$data['title']='Compare Deposit';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);		
	}


/***************************Loan Search main form*******************/

 	public function loan_search()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$a['default_loan_deposit']=$this->nbf_model->default_loan_select(); 
                $a['all_loan']= $this->nbf_model->select_all_published_loan_category();
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/form_loan',$a,true);
		$data['title']='Loan Form';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);	
	}
	

/*********************data search for loan search form********************/	
 	
 	public function check_loan()
   	{

    	$non_bank_finance_loan_id=$this->input->post('non_bank_finance_loan_id'); 
	$this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $a['results']= $this->nbf_model->search_loan_info($non_bank_finance_loan_id);
        $a['all_loan']= $this->nbf_model->select_all_published_loan_category();
			 
		if($a['results'])
		{
		  	$data=array();
			$data['maincontent']= $this->load->view('front_ui/non_bank_finance/table_show_loan1',$a,true); 
			$data['title']='Non Bank Finance Loan';
			//$data['sidebar']=1;
		  	//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
			$this->load->view('front_ui/main_content',$data);
		}
		   	else
		   	{
		  		$data=array();
				$a['message']='No Result Found!';
		 		$data['maincontent']=$this->load->view('front_ui/non_bank_finance/form_loan',$a,true);
				$data['title']='Loan Search';
				//$data['sidebar']=1;
				//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
				$this->load->view('front_ui/main_content',$data);
			}   
	}
 
 /*****************Show All Non Bank Finance List in Form************Different Mastering*******/
 	
 	public function non_bank_finance_search()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
                $a['all_non_bank_finance']= $this->nbf_model->select_non_bank_finance();
		$a['all_cat']= $this->nbf_model->cat();
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/show_all_non_bank_finance',$a,true);
		$data['title']='Non Bank Finance Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
	}
	
/**********************Show All Non Bank Finance Category In Form****Different Mastering*****************/	
	
	public function non_bank_finance_search_by_cat()
	{
		$cat=$this->input->post('non_bank_finance_cat');
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $a['all_non_bank_finance']= $this->nbf_model->select_non_bank_finance_by_cat($cat);
		$a['all_cat']= $this->nbf_model->cat();
        $data['maincontent']=$this->load->view('front_ui/non_bank_finance/show_all_non_bank_finance',$a,true);
		$data['title']='Non Bank Finance Search';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content.php',$data);	
	}



/*************************Show Comparison Data For Diposit Table****************/	

	public function check_compaire()
	{     
		$p_id = $this->input->post('p_id');
		$type = $this->input->post('type');
		$pids[]=$this->input->post('pids');
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/non_bank_finance/compare_two_data');
	}

	public function check_compaire_non_bank_finance_loan()
	{     
		$p_id = $this->input->post('p_id');
		$type = $this->input->post('type');
		$pids[]=$this->input->post('pids');
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/non_bank_finance/compare_two_data_non_bank_finance_loan');
        }

       public function non_bank_finance_atm_locator() 
       {        
		$data=array();
		$a['all_non_bank_finance_branch']= $this->non_bank_finance_front_ui_model->select_non_bank_finance();
                $data['maincontent']=$this->load->view('front_ui/non_bank_finance/non_bank_finance_atm_locator',$a,true);
		$data['title']='Non Bank Finance Branch Locator';
		//$data['sidebar']=1;
		//$data['sidebar']=$this->load->view('front_ui/sidebar','',true);
		$this->load->view('front_ui/main_content',$data);
		$this->load->library('session');
		$this->session->sess_destroy();
      }    
      
      
      /*================== Mobile Apps Part Start =================*/	  

/*================== NonBank Deposit =================*/	  
public function get_apps_deposit()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$data['default_deposit']=$this->nbf_model->default_deposit_select();
		$this->load->view('apps/nonbank/deposit/get_apps_deposit',$data);
	}


	  	public function apps_deposit_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$a['all_bank_deposit']=$this->nbf_model->select_all_non_bank_finance_deposit();
		//$a['all_bank_deposit_name']=$this->nbf_model->select_all_non_bank_finance_deposit_name();
		//$a['all_bank_deposit_duration']=$this->nbf_model->select_all_non_bank_finance_deposit_duration();  
		$data['spinncontent']= $a;
		$this->load->view('apps/nonbank/deposit/apps_deposit_spinner',$data);
	}
	
	public function apps_deposit_name_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$a['all_bank_deposit_name']=$this->nbf_model->select_all_non_bank_finance_deposit_name();
		$data['spinncontent']= $a;
		$this->load->view('apps/nonbank/deposit/bank_deposit_name_spinner',$data);
	}
	
	public function apps_deposit_year_spinner()
	{
		$data=array();
		$a=array();
	 	$this->load->model('front_ui_model','b_model');
		$a['all_bank_deposit_duration']=$this->b_model->select_all_bank_deposit_duration();  
		$data['spinncontent']= $a;
		$this->load->view('apps/bank/deposit/bank_deposit_year',$data);
	}
	
	public function apps_nonbank_deposit_quest(){
		$data= array();		
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		$year=$this->input->post('deposit_year'); 
		$installment_amount=$this->input->post('installment_amount'); 
		$installment_type=$this->input->post('installment_type');
		$data['questResults']= $this->nbf_model->search_diposit_info($installment_amount,$installment_type,$year);
		$this->load->view('apps/nonbank/deposit/get_apps_quest',$data);	
		
		 
		
	}
	
	/**********Non Bank Loan Part***************/
 public function get_apps_loan()
 {
  $data=array();
  $this->load->model('non_bank_finance_front_ui_model','nbf_model');
  $data['default_loan_deposit']=$this->nbf_model->default_loan_select(); 
  $this->load->view('apps/nonbank/loan/get_apps_loan',$data);
 }
 /**********Non Bank Loan Spinner Part***************/
 public function apps_loan_spinner()
 {
  $data=array();
  $this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $data['all_loan_cat']= $this->nbf_model->select_all_published_loan_category();
  $this->load->view('apps/nonbank/loan/apps_loan_spinner',$data); 
 }
 /**********Non Bank Loan Quest Part***************/
 public function apps_nonbank_loan_quest(){
  $data= array(); 
     $non_bank_finance_loan_id=$this->input->post('non_bank_finance_loan_id'); 
  $this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $data['loanQuestResults']= $this->nbf_model->search_loan_info($non_bank_finance_loan_id);
        $data['all_loan']= $this->nbf_model->select_all_published_loan_category();
  $this->load->view('apps/nonbank/loan/loan_apps_quest',$data);  
  
  
 }
 /**********Non Bank Information Part***************/
 
 public function get_apps_bankinfo()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
		//$data['default_exchange']=$this->b_model->default_usd_select();
		$data['all_bank']= $this->nbf_model->select_non_bank_finance();
		$this->load->view('apps/nonbank/bankinfo/get_apps_bankinfo',$data);
	}
	
	public function apps_bankinfo_spinner()
	{
		$data=array();
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $data['all_cat']= $this->nbf_model->cat();
		$this->load->view('apps/nonbank/bankinfo/apps_bankinfo_spinner',$data);	
	}
	
	public function apps_bankinfo_quest(){
		$data= array();		
		$cat=$this->input->post('non_bank_finance_cat');
		$this->load->model('non_bank_finance_front_ui_model','nbf_model');
        $data['all_bank']= $this->nbf_model->select_non_bank_finance_by_cat($cat);
		$this->load->view('apps/nonbank/bankinfo/apps_bankinfo_quest',$data);		
	}
	
	/*================== Mobile Apps Part End =================*/	

}